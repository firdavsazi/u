"""Калькулятор из Excel или текста: разбор файла и строк в список работ (без Телеграма и базы).

Работа = (название, единица, количество, цена). Строки, которые не получилось разобрать, не теряются:
возвращаются отдельным списком, чтобы бот показал их человеку и попросил поправить.
"""
import io
import re

import pool

MAX_BYTES = 1_000_000
MAX_ROWS = 300

UNITS = ("м²", "шт", "пог.м", "помещ.", "компл.", "точка")
UNIT_ALIASES = {
    "м2": "м²", "м²": "м²", "кв.м": "м²", "кв. м": "м²", "кв м": "м²", "квм": "м²", "кв.м.": "м²",
    "шт": "шт", "шт.": "шт", "штука": "шт", "штук": "шт",
    "пм": "пог.м", "пог.м": "пог.м", "пог. м": "пог.м", "пог м": "пог.м", "п.м": "пог.м", "п.м.": "пог.м",
    "м.п": "пог.м", "м.п.": "пог.м", "мп": "пог.м", "м": "пог.м",
    "помещ.": "помещ.", "помещ": "помещ.", "помещение": "помещ.", "комната": "помещ.",
    "компл.": "компл.", "компл": "компл.", "комплект": "компл.",
    "точка": "точка", "точки": "точка", "т.": "точка", "точек": "точка",
}
_NUM = r"\d+(?:[.,]\d+)?"
# единицы в строке текста: длинные раньше коротких («пог.м» раньше «м»)
_UNIT_RE = "|".join(re.escape(u) for u in sorted(
    ["м²", "м2", "кв.м.", "кв.м", "кв. м", "кв м", "пог.м", "пог. м", "пог м", "п.м.", "п.м", "м.п.", "м.п", "пм",
     "шт.", "шт", "штук", "точки", "точка", "точек", "помещ.", "помещ", "компл.", "компл", "м"], key=len, reverse=True))
_CUR = r"(?:₽|руб(?:лей|\.)?|р\.?|тенге|тг|₸|сомони|сом)"
_LINE_RE = re.compile(
    rf"^(?P<title>.+?)[\s:;,\-–—]+(?P<qty>{_NUM})(?=[\s×*xх])\s*(?P<unit>(?:{_UNIT_RE})(?![\w²]))?"
    rf"\s*(?:[×*xх]|по|@|за|-)?\s*(?P<price>{_NUM})\s*(?:{_CUR})?"
    rf"(?:\s*(?:/|за)\s*(?:{_UNIT_RE})(?![\w²]))?\s*[.;]?$",
    re.I)


def norm_unit(raw) -> str:
    u = str(raw).strip().lower() if raw not in (None, "") else ""
    return UNIT_ALIASES.get(u, u[:12])


def _to_float(x):
    """Число из ячейки или текста: 1 500,5 → 1500.5; не число — None."""
    if isinstance(x, bool):
        return None
    if isinstance(x, (int, float)):
        return float(x)
    if isinstance(x, str):
        t = x.strip().lower().replace(" ", "").replace(" ", "").replace(",", ".")
        t = re.sub(rf"{_CUR}$", "", t).strip()
        try:
            v = float(t)
        except ValueError:
            return None
        return v if v == v and abs(v) != float("inf") else None
    return None


def _has_letters(s: str) -> bool:
    return len(re.findall(r"[^\W\d_]", s)) >= 2


# --- Текст ---------------------------------------------------------------------------
def parse_text(text: str):
    """Строки вида «плитка 18 м² 3000» → (работы, непонятые строки).

    Работа — словарь {'title','unit','qty','price'}. Единицу можно не писать: возьмётся от похожей работы каталога или «шт»."""
    items, bad = [], []
    for raw in (text or "").splitlines():
        line = raw.replace(" ", " ").strip()
        line = re.sub(r"^[•\-–—*]+\s*", "", line)
        line = re.sub(r"^\d+[.)]\s+(?=\D)", "", line)       # нумерация «1. », «2) »
        if not line:
            continue
        line = re.sub(rf"\s*=\s*{_NUM}(?:\s\d{{3}})*\s*(?:{_CUR})?\s*$", "", line, flags=re.I)  # итог строки «= 54000» отбрасываем
        m = _LINE_RE.match(line)
        qty = price = None
        if m:
            qty, price = _to_float(m["qty"]), _to_float(m["price"])
        title = (m["title"].strip(" -–—:;,.") if m else "")
        if not m or not qty or not price or qty <= 0 or price <= 0 or not _has_letters(title):
            bad.append(raw.strip())
            continue
        unit = norm_unit(m["unit"]) if m["unit"] else pool.default_unit(title)
        items.append({"title": title[:80][0].upper() + title[:80][1:], "unit": unit, "qty": qty, "price": price})
    return items, bad


# --- Excel ---------------------------------------------------------------------------
def build_template() -> bytes:
    """Шаблон Excel: название работы, единица, количество, цена. Пример — на втором листе, чтобы он не попал в расчёт."""
    from openpyxl import Workbook
    from openpyxl.styles import Font
    from openpyxl.worksheet.datavalidation import DataValidation

    wb = Workbook()
    ws = wb.active
    ws.title = "Расчёт"
    ws.append(["Название работы", "Единица", "Количество", "Цена"])
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for col, w in zip("ABCD", (46, 12, 13, 12)):
        ws.column_dimensions[col].width = w
    dv = DataValidation(type="list", formula1='"' + ",".join(UNITS) + '"', allow_blank=True)
    ws.add_data_validation(dv)
    dv.add("B2:B300")
    hint = wb.create_sheet("Подсказка")
    for row in ("Заполните лист «Расчёт»: одна работа в строке.",
                "Название работы — любой текст (например: Укладка плитки).",
                "Единица — м², шт, пог.м (можно выбрать из списка).",
                "Количество и цена — числа (запятая или точка), цена в вашей валюте.",
                "Пример строки: Укладка плитки | м² | 18 | 3000",
                "Сохраните файл и пришлите его боту в чат."):
        hint.append([row])
    hint.column_dimensions["A"].width = 72
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def parse_file(data: bytes):
    """Читает заполненный шаблон: (работы, непонятые строки). Непонятая строка — «строка 7: причина»."""
    from openpyxl import load_workbook

    wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    ws = wb["Расчёт"] if "Расчёт" in wb.sheetnames else wb.worksheets[0]
    items, bad = [], []
    for n, row in enumerate(ws.iter_rows(values_only=True, max_col=4), 1):
        if n > MAX_ROWS + 1:
            bad.append(f"строки после {MAX_ROWS + 1}-й не читал: слишком много")
            break
        row = (list(row) + [None] * 4)[:4]
        title, unit, qty, price = row
        if n == 1 and isinstance(title, str) and "назв" in title.lower():
            continue                                         # строка заголовков
        if all(c in (None, "") for c in row):
            continue
        t = str(title).strip() if title not in (None, "") else ""
        q, p = _to_float(qty), _to_float(price)
        problems = []
        if not t or not _has_letters(t):
            problems.append("нет названия")
        if q is None or q <= 0:
            problems.append("количество не число больше нуля")
        if p is None or p <= 0:
            problems.append("цена не число больше нуля")
        if problems:
            shown = t[:40] or "—"
            bad.append(f"строка {n} («{shown}»): " + ", ".join(problems))
            continue
        u = norm_unit(unit) if unit not in (None, "") else pool.default_unit(t)
        items.append({"title": t[:80], "unit": u, "qty": q, "price": p})
    return items, bad
