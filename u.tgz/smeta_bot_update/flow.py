"""Цепочка вопросов для одной комнаты (ванная / туалет).

Все вопросы описаны одним упорядоченным списком STEPS. У каждого есть
условие when(ответы, контекст): вопрос задаётся, только если оно истинно.
Поэтому «следующий вопрос» — это первый подходящий вопрос без ответа
(см. next_step). Благодаря этому кнопка «Назад» просто удаляет последний
ответ, а вопросы-подсказки (гидроизоляция, углы, люки и т.д.) вставляются
в нужное место без хитрой логики.

Контекст c = {'stage': 'rough'|'finish'|'all', 'kind': 'bath_full'|'bath_only'|'wc',
              'cur': код валюты (для подсказок с ценами)}.
Виды ответов: 'num' — число текстом, 'yn' — да/нет ('y'/'n'),
'choice' — один вариант кнопкой, 'multi' — несколько вариантов, 'text' — короткий текст.
"""
from dataclasses import dataclass
from typing import Callable, Optional, Union

import calc
import catalog
from calc import fnum


@dataclass
class Step:
    key: str
    kind: str                                  # num | yn | choice | multi | text
    text: Union[str, Callable]                 # текст вопроса (или функция (a, c) -> str)
    when: Callable = lambda a, c: True         # когда задавать
    options: Union[list, Callable, None] = None  # [(значение, подпись)] для choice/multi
    quick: Union[list, Callable, None] = None  # быстрые кнопки для num: [(подпись, число)]
    positive: bool = False                     # для num: строго больше нуля (размеры)
    maxval: float = 1000                       # для num: верхний предел (защита от опечаток)
    default: Union[list, Callable, None] = None  # для multi: что отмечено сразу (список или функция (a, c))
    limit: Optional[Callable] = None           # для num: предел, зависящий от ответов (a, c) -> число
    auto: Optional[Callable] = None            # ответ, который бот подставляет сам (a, c) -> число, без вопроса
    auto_note: Optional[Callable] = None       # что написать человеку, когда ответ подставлен (a, c, значение)


# --- Условия -----------------------------------------------------------------
def rough(c): return c["stage"] in ("rough", "all")
def finish(c): return c["stage"] in ("finish", "all")
def has_tub(c): return c["kind"] in ("bath_full", "bath_only")
def has_toilet(c): return c["kind"] in ("bath_full", "wc")
def is_bath_room(c): return c["kind"] in ("bath_full", "bath_only", "wc")
def yes(a, key): return a.get(key) == "y"


def _g(a): return calc.geometry(a)


def _left_walls(a):
    """Стены, которые остаются под плитку: общая площадь минус шпаклёвка и покраска."""
    g = _g(a)
    return round(g["walls"] - calc.finish_areas(a, g)["untiled"], 2)


def _tile_zone_text(a, c):
    g = _g(a)
    fa = calc.finish_areas(a, g)
    text = "⬜ Где кладём плитку?"
    if fa["untiled"] > 0:
        text += (f"\n<i>Стены {fnum(g['walls'])} м², из них под шпаклёвку и покраску {fnum(fa['untiled'])} м². "
                 f"Под плитку остаётся {fnum(_left_walls(a))} м².</i>")
    return text


def _tile_zone_options(a, c):
    g = _g(a)
    left = _left_walls(a)
    return [
        ("fw", f"Пол и стены ({fnum(g['floor'] + left)} м²)"),
        ("floor", f"Только пол ({fnum(g['floor'])} м²)"),
        ("walls", f"Только стены ({fnum(left)} м²)"),
        ("own", "Ввести свою площадь"),
    ]


# --- «Плитка по типу»: всего / разнесено / осталось -------------------------------
TILE_TYPE_KEYS = ("tile_a60", "tile_alarge", "tile_akab")


def tile_total(a): return calc.tile_area(a, _g(a))


def tile_left(a, upto: int) -> float:
    """Сколько м² плитки ещё не разнесено по типам, если учесть первые upto типов."""
    spread = sum(a.get(k, 0) for k in TILE_TYPE_KEYS[:upto])
    return max(round(tile_total(a) - spread, 2), 0)


def _tile_type_text(upto: int, question: str):
    def text(a, c):
        total, spread = tile_total(a), round(sum(a.get(k, 0) for k in TILE_TYPE_KEYS[:upto]), 2)
        last = "\n<i>Последний тип, «кабанчик», заполню остатком сам.</i>" if upto <= 1 else ""
        return (f"⬜ Всего {fnum(total)} м², разнесено {fnum(spread)}, осталось {fnum(tile_left(a, upto))}.\n"
                f"{question}{last}")
    return text


def _tile_type_quick(upto: int):
    def quick(a, c):
        left = tile_left(a, upto)
        return [("0", 0)] + ([(f"все {fnum(left)}", left)] if left > 0 else [])
    return quick


def _akab_auto(a, c): return tile_left(a, 2)


def _akab_note(a, c, value):
    return (f"⬜ Плитку «кабанчик» заполнил остатком: {fnum(value)} м² "
            f"(всего {fnum(tile_total(a))} м², разнесено {fnum(tile_total(a) - value)}, осталось 0).\n\n")


def _cut_quick(a, c):
    return [(f"= периметр {fnum(_g(a)['perim'])} м", _g(a)["perim"]), ("0", 0)]


def _count_quick(a, c):
    return [("0", 0), ("1", 1), ("2", 2), ("4", 4)]


def _epoxy_hint(a, c):
    """Подсказка про цену эпоксидной затирки: диапазон 1500–2000 ₽, пересчитанный в валюту человека."""
    cur = catalog.CURRENCIES[c.get("cur", "rub")]
    lo, hi = (catalog.scale_value(v, cur["factor"]) for v in (1500, 2000))
    return (f"▦ Какая затирка?\n<i>Цементная — обычная. Эпоксидная дороже: обычно {fnum(lo)}–{fnum(hi)} "
            f"{cur['symbol']} за м². Точную цену укажите в «Мои цены».</i>")


def _points_default(a, c):
    """Точки воды по умолчанию: что обычно подключается в этом помещении."""
    if c["kind"] == "bath_full":
        return ["tub", "toilet", "sink", "washer"]
    if c["kind"] == "bath_only":
        return ["tub", "sink", "washer"]
    return ["toilet"]


HATCH_QUICK = [("1", 1), ("2", 2), ("3", 3)]
ZERO_QUICK = [("0", 0)]
WALLS_QUICK = [("1", 1), ("2", 2), ("3", 3), ("4 (все)", 4)]

# Ревизионные люки: пока два вида (остальные виды и размеры добавим, когда будут цены)
HATCH_KINDS = [("none", "Люк не нужен"), ("magnet", "Под плитку, на магнитах"), ("hidden", "Скрытого монтажа"),
               ("custom", "Свой вариант")]

# Плинтус: потолочный или напольный (в ванной и туалете только потолочный), затем материал
PLINTH_PLACES = [("ceil", "Потолочный"), ("floor", "Напольный")]
PLINTH_MATERIALS = [("ready", "Готовый, без покраски"), ("paint", "Под покраску"),
                    ("plastic", "Пластиковый"), ("tile", "Из плитки")]

# Углы плитки: три способа оформления
CORNER_KINDS = [("miter", "Запил под 45°"), ("tile", "Уголок в плитку"),
                ("deco", "Декоративный уголок (ставится в последнюю очередь)")]


def hatch_steps(src: str, where: str, cond: Callable) -> list:
    """Вопросы про люк: вид → (для «своего варианта» название и цена) → количество. cond(a, c) — когда люк возможен."""
    asked = lambda a, c: cond(a, c) and a.get(f"hk_{src}") not in (None, "none")
    own = lambda a, c: cond(a, c) and a.get(f"hk_{src}") == "custom"

    def price_text(a, c):
        sym = catalog.CURRENCIES[c.get("cur", "rub")]["symbol"]
        return (f"🪟 Цена одного люка «{a.get(f'hname_{src}', '')}» ({where}), {sym}:\n"
                "<i>Она попадёт в смету и в «Мои цены».</i>")

    return [
        Step(f"hk_{src}", "choice", f"🪟 Ревизионный люк ({where}): какой нужен?", when=cond, options=HATCH_KINDS),
        Step(f"hname_{src}", "text", f"🪟 Что за люк ({where})? Напишите вид, например «Люк сантехнический 30×40»:",
             when=own),
        Step(f"hprice_{src}", "num", price_text, when=own, positive=True, maxval=1_000_000),
        Step(f"hn_{src}", "num", f"🪟 Сколько люков ({where})?", when=asked, quick=HATCH_QUICK,
             positive=True, maxval=20),
    ]


def corner_steps(src: str, where: str, cond: Callable) -> list:
    """Два вопроса про угол плитки: какой угол → длина в погонных метрах."""
    return [
        Step(f"cor_{src}", "choice", f"📐 Какой угол сделать ({where})?", when=cond, options=CORNER_KINDS),
        Step(f"cor_{src}_len", "num", f"📐 Длина угла ({where}), погонных метров:", when=cond, maxval=100),
    ]


# Когда у помещения есть то, что надо оформлять углом / закрывать люком
def _tiled(a, c): return finish(c) and yes(a, "tile")
def _box_tiled(a, c): return _tiled(a, c) and yes(a, "box")
def _niche_tiled(a, c): return _tiled(a, c) and yes(a, "niche")
def _slopes_tiled(a, c): return _tiled(a, c) and yes(a, "slopes")
def _inst(a, c): return finish(c) and has_toilet(c) and yes(a, "toilet") and a.get("toilet_type") == "install"
def _inst_tiled(a, c): return _inst(a, c) and yes(a, "tile")
def _box(a, c): return finish(c) and yes(a, "box")
def _screen(a, c): return (finish(c) and has_tub(c) and yes(a, "tub")
                           and a.get("tub_screen") in ("tile", "plastic"))


STEPS: list[Step] = [
    # --- Замеры ---------------------------------------------------------------
    # Размеры комнаты не ограничиваем: слишком большое число бот переспрашивает (main.dim_level), а не запрещает
    Step("len", "num", "📏 Длина помещения, м (например 1,53):", positive=True),
    Step("wid", "num", "📏 Ширина помещения, м:", positive=True),
    Step("hei", "num", "📏 Высота потолка, м:", quick=[("2,5", 2.5), ("2,7", 2.7)], positive=True),
    Step("door", "choice", "🚪 Вычитать дверной проём из площади стен?",
         options=[("std", f"Да, стандартный {fnum(calc.DOOR_STD_W)}×{fnum(calc.DOOR_STD_H)} м"),
                  ("own", "Да, свой размер"), ("no", "Нет, не вычитать")]),
    Step("door_w", "num", "🚪 Ширина проёма, м:", when=lambda a, c: a.get("door") == "own", positive=True, maxval=5),
    Step("door_h", "num", "🚪 Высота проёма, м:", when=lambda a, c: a.get("door") == "own", positive=True, maxval=5),

    # --- Черновые работы -------------------------------------------------------
    Step("demolition", "yn", "🔨 Демонтаж (старая плитка, покрытия) нужен?", when=lambda a, c: rough(c)),
    Step("wall_clean", "yn", "🧹 Очистка стен нужна?", when=lambda a, c: rough(c)),
    Step("primer_plaster", "yn", "🧴 Грунтовка под штукатурку нужна?", when=lambda a, c: rough(c)),
    Step("plaster", "yn", "🧱 Штукатурка стен нужна?", when=lambda a, c: rough(c)),
    Step("plaster_net", "yn", "🕸 Нужно ли армирование сеткой?", when=lambda a, c: rough(c) and yes(a, "plaster")),
    # Вода: разводка → счётчик → фильтры → точки
    Step("plumbing", "yn", "🚿 Разводка труб нужна?", when=lambda a, c: rough(c)),
    Step("meter", "choice",
         "🔢 Счётчик воды меняем?\n<i>Если не меняем, старый всё равно снимается и ставится заново — "
         "это отдельная оплачиваемая работа.</i>",
         when=lambda a, c: rough(c) and yes(a, "plumbing"),
         options=[("replace", "Меняем на новый"), ("reinstall", "Не меняем: снять и поставить заново"),
                  ("none", "Счётчиков нет")]),
    Step("meter_n", "num", "🔢 Сколько счётчиков? (обычно 2: на горячую и на холодную воду)",
         when=lambda a, c: rough(c) and yes(a, "plumbing") and a.get("meter") in ("replace", "reinstall"),
         quick=[("1", 1), ("2", 2)], positive=True, maxval=10),
    Step("filter_cold", "yn", "🚰 Фильтр грубой очистки на холодную воду нужен?\n<i>Фильтр ставится раньше счётчика.</i>",
         when=lambda a, c: rough(c) and yes(a, "plumbing")),
    Step("filter_hot", "yn", "🚰 Фильтр грубой очистки на горячую воду нужен?",
         when=lambda a, c: rough(c) and yes(a, "plumbing")),
    Step("points", "multi",
         "📍 Точки воды. Я отметил то, что обычно есть в таком санузле. Уберите лишнее или добавьте нужное, "
         "потом нажмите «Готово»:",
         when=lambda a, c: rough(c) and yes(a, "plumbing"),
         options=[("tub", "Ванна со смесителем (горячая и холодная)"), ("toilet", "Инсталляция унитаза"),
                  ("sink", "Раковина (горячая и холодная)"), ("washer", "Стиральная машина")],
         default=_points_default),
    Step("pt_extra", "num", "📍 Нужны ещё точки воды, кроме отмеченных? Сколько?",
         when=lambda a, c: rough(c) and yes(a, "plumbing"), quick=[("0", 0), ("1", 1), ("2", 2)], maxval=20),
    Step("electric", "yn", "💡 Электрика нужна?", when=lambda a, c: rough(c)),
    Step("waterproof", "yn", "💧 Гидроизоляция нужна? (по умолчанию — да)", when=lambda a, c: rough(c)),
    Step("screed", "yn", "🏗 Стяжка пола нужна?", when=lambda a, c: rough(c)),
    Step("primer_floor", "yn", "🧴 Грунтовка под наливной пол нужна?", when=lambda a, c: rough(c)),
    Step("self_level", "yn", "🌊 Наливной пол нужен?", when=lambda a, c: rough(c)),

    # --- Чистовые работы -------------------------------------------------------
    # Шпаклёвка и покраска идут раньше плитки: их площадь вычитается из стен, остальное — под плитку
    Step("putty", "yn", "🪣 Шпаклёвка стен нужна?", when=lambda a, c: finish(c)),
    Step("putty_glass", "yn", "🧻 Под шпаклёвку клеим стеклохолст?",
         when=lambda a, c: finish(c) and yes(a, "putty")),
    Step("putty_scope", "choice", "🪣 Шпаклюем стену целиком или только верх?",
         when=lambda a, c: finish(c) and yes(a, "putty"),
         options=[("full", "Всю стену"), ("top", "Только верх (ниже плитка)")]),
    Step("putty_h", "num", "🪣 С какой высоты от пола начинается шпаклёвка, м?\n<i>Ниже этой отметки плитка, "
                           "выше — шпаклёвка до потолка.</i>",
         when=lambda a, c: finish(c) and yes(a, "putty") and a.get("putty_scope") == "top",
         quick=[("1,2", 1.2), ("1,5", 1.5), ("2", 2)], positive=True, maxval=10),
    Step("putty_walls", "num", "🪣 Сколько стен шпаклюем? (всего их четыре)",
         when=lambda a, c: finish(c) and yes(a, "putty"), quick=WALLS_QUICK, positive=True, maxval=4),
    Step("paint", "yn", "🖌 Покраска стен нужна?", when=lambda a, c: finish(c)),
    # Стеклохолст под покраску: если он уже наклеен под шпаклёвку, второй раз не спрашиваем
    Step("paint_glass", "yn", "🧻 Под покраску клеим стеклохолст?",
         when=lambda a, c: finish(c) and yes(a, "paint") and not (yes(a, "putty") and yes(a, "putty_glass"))),
    Step("paint_walls", "num", "🖌 Сколько стен красим? (всего их четыре)",
         when=lambda a, c: finish(c) and yes(a, "paint"), quick=WALLS_QUICK, positive=True, maxval=4),
    Step("primer_tile", "yn", "🧴 Грунтовка под плитку нужна?", when=lambda a, c: finish(c)),
    # Плитка
    Step("tile", "yn", "⬜ Укладка плитки нужна?", when=lambda a, c: finish(c)),
    Step("tile_zone", "choice", _tile_zone_text, when=lambda a, c: finish(c) and yes(a, "tile"),
         options=_tile_zone_options),
    Step("tile_area", "num", "⬜ Площадь плитки, м²:",
         when=lambda a, c: finish(c) and yes(a, "tile") and a.get("tile_zone") == "own", positive=True, maxval=500),
    Step("tile_mode", "choice", "⬜ Плитка: считаем одной ценой или по типу?",
         when=lambda a, c: finish(c) and yes(a, "tile"),
         options=[("single", "Одна цена"), ("types", "По типу (60×60, крупная, кабанчик)")]),
    # Типы плитки: сумма всегда равна общей площади, последний тип (кабанчик) бот заполняет остатком
    Step("tile_a60", "num", _tile_type_text(0, "Сколько м² плитки 60×60? (0 — нет)"),
         when=lambda a, c: finish(c) and yes(a, "tile") and a.get("tile_mode") == "types",
         quick=_tile_type_quick(0), limit=lambda a, c: tile_left(a, 0), maxval=500),
    Step("tile_alarge", "num", _tile_type_text(1, "Сколько м² крупной плитки? (0 — нет)"),
         when=lambda a, c: finish(c) and yes(a, "tile") and a.get("tile_mode") == "types",
         quick=_tile_type_quick(1), limit=lambda a, c: tile_left(a, 1), maxval=500),
    Step("tile_akab", "num", "⬜ Плитка «кабанчик» — остаток.",
         when=lambda a, c: finish(c) and yes(a, "tile") and a.get("tile_mode") == "types",
         auto=_akab_auto, auto_note=_akab_note, maxval=500),
    # Подсказка про гидроизоляцию: только если этап чистовой (на черновом она уже спрошена)
    Step("waterproof", "yn", "💧 Под плитку нужна гидроизоляция? (по умолчанию — да)",
         when=lambda a, c: finish(c) and not rough(c) and yes(a, "tile")),
    Step("tile_cut", "num", "🪚 Обрезка плитки, погонных метров:",
         when=lambda a, c: finish(c) and yes(a, "tile"), quick=_cut_quick, maxval=500),
    # Короб: угол плитки и люк
    Step("box", "yn", "🔧 Короб для труб нужен?", when=lambda a, c: finish(c)),
    Step("box_len", "num", "🔧 Длина короба, пог. м:", when=_box, positive=True, maxval=50),
    *corner_steps("box", "короб", _box_tiled),
    *hatch_steps("box", "в коробе", _box),
    # Ниши и откосы: спрашиваем угол, только если они оформлены плиткой
    Step("niche", "yn", "⬜ Есть ниша (полка в стене), которую оформляем плиткой?", when=_tiled),
    *corner_steps("niche", "ниша", _niche_tiled),
    Step("slopes", "yn", "⬜ Откосы (окно или проём) оформляем плиткой?\n"
                         "<i>Если проём прямой и без оформления — ответьте «Нет».</i>", when=_tiled),
    *corner_steps("slopes", "откосы", _slopes_tiled),
    # Ванна и экран
    Step("tub", "yn", "🛁 Установка ванны нужна?", when=lambda a, c: finish(c) and has_tub(c)),
    Step("tub_screen", "choice", "🛁 Экран под ванной:", when=lambda a, c: finish(c) and has_tub(c) and yes(a, "tub"),
         options=[("tile", "Плитка"), ("plastic", "Пластик"), ("none", "Без экрана")]),
    *hatch_steps("screen", "в экране под ванной", _screen),
    # Раковина и мебель
    Step("sink", "yn", "🚰 Установка раковины нужна?", when=lambda a, c: finish(c)),
    Step("furn", "multi", "🪑 Собирать мебель? Отметьте нужное и нажмите «Готово» (без отметок — мебель не собираем):",
         when=lambda a, c: finish(c) and yes(a, "sink"),
         options=[("tumba", "Тумба"), ("shkaf", "Шкаф"), ("penal", "Пенал")]),
    # Унитаз
    Step("toilet", "yn", "🚽 Установка унитаза нужна?", when=lambda a, c: finish(c) and has_toilet(c)),
    Step("toilet_type", "choice", "🚽 Какой унитаз?", when=lambda a, c: finish(c) and has_toilet(c) and yes(a, "toilet"),
         options=[("floor", "Напольный"), ("install", "Подвесной, с инсталляцией")]),
    *corner_steps("inst", "инсталляция", _inst_tiled),
    *hatch_steps("inst", "у инсталляции", _inst),
    # Затирка (после углов и люков), сверление, покраска, плинтус
    Step("grout", "yn", "▦ Затирка швов нужна?", when=lambda a, c: finish(c)),
    Step("grout_type", "choice", _epoxy_hint, when=lambda a, c: finish(c) and yes(a, "grout"),
         options=[("cement", "Цементная"), ("epoxy", "Эпоксидная")]),
    Step("drill", "choice", "🔲🔧 Сверление отверстий в плитке: как считаем?", when=lambda a, c: finish(c),
         options=[("none", "Не нужно"), ("one", "Одна цена за отверстие"), ("diam", "По диаметрам")]),
    Step("drill_n", "num", "🔲🔧 Сколько отверстий всего, шт?",
         when=lambda a, c: finish(c) and a.get("drill") == "one", quick=_count_quick, maxval=500),
    Step("dr_normal", "num", "🔲🔧 Обычных отверстий, шт?",
         when=lambda a, c: finish(c) and a.get("drill") == "diam", quick=_count_quick, maxval=500),
    Step("dr_socket", "num", "🔲🔧 Отверстий под подрозетник, шт?",
         when=lambda a, c: finish(c) and a.get("drill") == "diam", quick=_count_quick, maxval=500),
    Step("dr_big", "num", "🔲🔧 Больших отверстий под инсталляцию, шт?",
         when=lambda a, c: finish(c) and a.get("drill") == "diam", quick=_count_quick, maxval=500),
    Step("dr_small", "num", "🔲🔧 Маленьких отверстий, шт?",
         when=lambda a, c: finish(c) and a.get("drill") == "diam", quick=_count_quick, maxval=500),
    # Плинтус сам по себе (потолок с ним не связан): потолочный или напольный, затем материал.
    # В ванной и туалете он только потолочный: бот ставит это сам и не спрашивает.
    Step("plinth", "yn", "▬ Плинтус нужен?", when=lambda a, c: finish(c)),
    # (в старых сметах материал плинтуса уже есть, а места нет: их не переспрашиваем, считаются как раньше)
    Step("plinth_place", "choice", "▬ Плинтус потолочный или напольный?",
         when=lambda a, c: finish(c) and yes(a, "plinth") and not is_bath_room(c) and "plinth_type" not in a,
         options=PLINTH_PLACES),
    Step("plinth_place", "choice", "▬ Потолочный плинтус", auto=lambda a, c: "ceil",
         when=lambda a, c: finish(c) and yes(a, "plinth") and is_bath_room(c) and "plinth_type" not in a,
         options=PLINTH_PLACES),
    Step("plinth_type", "choice",
         "▬ Из чего плинтус?\n<i>«Под покраску» — две строки в смете: установка и покраска плинтуса. "
         "Длина берётся по периметру (у потолочного — целиком, у напольного без дверного проёма).</i>",
         when=lambda a, c: finish(c) and yes(a, "plinth"), options=PLINTH_MATERIALS),
]

STEP_BY_KEY: dict[str, list[Step]] = {}
for _s in STEPS:
    STEP_BY_KEY.setdefault(_s.key, []).append(_s)


def next_step(a: dict, c: dict) -> Optional[Step]:
    """Первый применимый вопрос, на который ещё нет ответа (или None — всё спрошено)."""
    for s in STEPS:
        if s.key not in a and s.when(a, c):
            return s
    return None


def resolve(value, a: dict, c: dict):
    """Если значение — функция, вызывает её; иначе возвращает как есть."""
    return value(a, c) if callable(value) else value


def migrate_answers(a: dict) -> dict:
    """Приводит ответы из старых сохранённых смет к текущим вопросам.

    Раньше про люк спрашивали «нужна ревизия?» (да/нет + количество), теперь — вид, размер и количество.
    Старое «да» становится люком на магнитах (размер бот спросит заново). Старый общий вопрос про запил
    и клей со стеклохолстом под штукатурку больше не используются."""
    a = dict(a)
    for src, old in (("box", "rev_box"), ("screen", "rev_screen"), ("inst", "rev_inst")):
        if old in a:
            if a.pop(old) == "y":
                a[f"hk_{src}"] = "magnet"
                a[f"hn_{src}"] = a.pop(f"{old}_n", 1)
            else:
                a[f"hk_{src}"] = "none"
                a.pop(f"{old}_n", None)
    for gone in ("miter", "plaster_mesh"):
        a.pop(gone, None)
    return a


def clean_answers(a: dict, c: dict) -> dict:
    """Оставляет только ответы на вопросы, которые действительно актуальны.

    После правок в смете могут остаться «хвосты» (например, зона плитки, когда
    плитку потом отключили) — их в расчёт брать нельзя.
    """
    out: dict = {}
    for s in STEPS:
        if s.key in a and s.key not in out and s.when(out, c):
            out[s.key] = a[s.key]
    return out


def active_step(key: str, a: dict, c: dict) -> Optional[Step]:
    """Вопрос по ключу, который сейчас применим (у «waterproof» их два)."""
    for s in STEP_BY_KEY.get(key, []):
        if s.when(a, c):
            return s
    return None


# Короткие названия для экрана «Что поправить?» и для меню («шаг: плитка»)
SHORT = {
    "len": "Длина", "wid": "Ширина", "hei": "Высота", "door": "Проём", "door_w": "Ширина проёма",
    "door_h": "Высота проёма", "demolition": "Демонтаж", "wall_clean": "Очистка стен",
    "primer_plaster": "Грунт под штукатурку", "plaster": "Штукатурка", "plaster_net": "Армирование сеткой",
    "plumbing": "Разводка труб", "meter": "Счётчик воды", "meter_n": "Счётчиков",
    "filter_cold": "Фильтр холодной", "filter_hot": "Фильтр горячей", "points": "Точки воды",
    "pt_extra": "Ещё точки", "electric": "Электрика", "waterproof": "Гидроизоляция",
    "screed": "Стяжка", "primer_floor": "Грунт под пол", "self_level": "Наливной пол",
    "putty": "Шпаклёвка", "putty_glass": "Стеклохолст под шпаклёвку", "primer_tile": "Грунт под плитку",
    "tile": "Плитка", "tile_zone": "Зона плитки", "tile_area": "Площадь плитки", "tile_mode": "Цена плитки",
    "tile_a60": "Плитка 60×60 м²", "tile_alarge": "Крупная м²", "tile_akab": "Кабанчик м²",
    "tile_cut": "Обрезка, пог.м",
    "box": "Короб", "box_len": "Длина короба", "cor_box": "Угол короба", "cor_box_len": "Длина угла короба",
    "hk_box": "Люк в коробе", "hn_box": "Люков в коробе",
    "niche": "Ниша", "cor_niche": "Угол ниши", "cor_niche_len": "Длина угла ниши",
    "slopes": "Откосы", "cor_slopes": "Угол откосов", "cor_slopes_len": "Длина угла откосов",
    "tub": "Ванна", "tub_screen": "Экран", "hk_screen": "Люк в экране",
    "hn_screen": "Люков в экране", "sink": "Раковина", "furn": "Мебель", "toilet": "Унитаз",
    "toilet_type": "Тип унитаза", "cor_inst": "Угол инсталляции", "cor_inst_len": "Длина угла инсталляции",
    "hk_inst": "Люк у инсталляции", "hn_inst": "Люков инсталляции",
    "grout": "Затирка", "grout_type": "Вид затирки",
    "drill": "Сверление", "drill_n": "Число отверстий", "dr_normal": "Обычных", "dr_socket": "Подрозетник",
    "dr_big": "Больших", "dr_small": "Маленьких", "paint": "Покраска", "paint_glass": "Стеклохолст под покраску",
    "plinth": "Плинтус", "plinth_place": "Плинтус: где", "plinth_type": "Материал плинтуса",
    "putty_scope": "Шпаклёвка: где", "putty_h": "Шпаклёвка от высоты", "putty_walls": "Стен шпаклюем",
    "paint_walls": "Стен красим",
    "hname_box": "Свой люк в коробе", "hprice_box": "Цена люка в коробе",
    "hname_screen": "Свой люк в экране", "hprice_screen": "Цена люка в экране",
    "hname_inst": "Свой люк инсталляции", "hprice_inst": "Цена люка инсталляции",
}

# Если поменяли один из этих ответов, распределение плитки по типам нужно ввести заново: площадь стала другой
_TILE_RESET = list(TILE_TYPE_KEYS)
RESET_ON_EDIT = {k: _TILE_RESET for k in (
    "len", "wid", "hei", "door", "door_w", "door_h", "putty", "putty_scope", "putty_h", "putty_walls",
    "paint", "paint_walls", "tile", "tile_zone", "tile_area", "tile_mode")}
RESET_ON_EDIT["tile_a60"] = ["tile_alarge", "tile_akab"]
RESET_ON_EDIT["tile_alarge"] = ["tile_akab"]


def step_max(step: Step, a: dict, c: dict) -> float:
    """Верхний предел числа для вопроса (у типов плитки он зависит от того, сколько уже разнесено)."""
    return step.limit(a, c) if step.limit else step.maxval


def answer_label(step: Step, a: dict, c: dict) -> str:
    """Человеческая запись ответа: «да», «1,53», «Плитка»…"""
    v = a.get(step.key)
    if step.kind == "yn":
        return "да" if v == "y" else "нет"
    if step.kind == "num":
        return fnum(v)
    if step.kind == "text":
        return str(v)
    names = dict(resolve(step.options, a, c) or [])
    if step.kind == "multi":
        return ", ".join(names.get(x, x) for x in v) if v else "нет"
    return names.get(v, str(v))


def edit_items(a: dict, c: dict) -> list:
    """Список (ключ, короткое название, ответ) для экрана правок."""
    items = []
    seen = set()
    for s in STEPS:
        if s.key in seen or s.key not in a or not s.when(a, c) or s.auto:  # подставленное ботом не правят
            continue
        seen.add(s.key)
        items.append((s.key, SHORT.get(s.key, s.key), answer_label(s, a, c)))
    return items
