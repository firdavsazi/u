"""Общий анонимный прайс из загруженных смет (калькулятор из Excel или текста).

Что попадает в общую базу, и только после согласия человека («Добавить услуги и цены в общий прайс, анонимно?»):
название услуги, единица и цена (плюс страна, город и валюта, чтобы рубли не смешивались с тенге). Метраж, сумма
по строке, имя, адрес, клиент и номер человека не сохраняются нигде в этих таблицах.

Правила:
- название чистится от метража, сумм и скобок («Плитка 18 м² (ванная) 54 000 ₽» → «Плитка»);
- название сверяется с каталогом бота и с уже одобренными названиями, подставляется похожее, дубли не создаются;
- названия, которых нет в каталоге, в общий прайс не попадают: они лежат в списке на проверку (pool_pending),
  владелец командой «новые названия» объединяет их с существующими или одобряет;
- цена, которая в разы (OUTLIER_FACTOR) выше или ниже обычной, отбрасывается;
- цены сравниваются только по одинаковой единице;
- диапазон и среднее показываются, только когда набралось не меньше MIN_UPLOADS загрузок.
"""
import re
from difflib import SequenceMatcher
from statistics import median

import catalog
import db

MIN_UPLOADS = 5          # меньше загрузок — диапазон и среднюю цену не показываем
OUTLIER_FACTOR = 4       # цена больше чем в 4 раза выше или ниже обычной — отбрасываем
MATCH_SCORE = 0.79       # насколько название должно быть похоже на каталожное, чтобы подставить его

_UNIT_WORDS = r"(?:м²|м2|кв\.?\s*м|пог\.?\s*м|п\.?\s*м|м\.п\.?|шт\.?|точк\w*|компл\w*|помещ\w*|м)"
_CUR = r"(?:₽|руб(?:л\w*|\.)?|р\.?|тенге|тг|₸|сомони|сом)"
_NUM = r"\d+(?:[.,]\d+)?"
_STOP = {"для", "под", "из", "на", "и", "в", "во", "по", "с", "со", "к", "от", "до", "за", "работы", "работа", "услуга"}


def clean_title(raw: str) -> str:
    """Название работы без метража, сумм, скобок и лишней пунктуации. Пусто, если названия не осталось."""
    s = str(raw or "").replace(" ", " ")
    for _ in range(3):                                   # скобки любой вложенности: (…) […] {…}
        s = re.sub(r"\([^()]*\)|\[[^\[\]]*\]|\{[^{}]*\}", " ", s)
    s = re.sub(r"[()\[\]{}]", " ", s)                    # оставшиеся незакрытые скобки
    s = re.sub(r"=.*$", " ", s)                          # «= 54 000» и всё после знака равенства
    s = re.sub(rf"(?<![\w×]){_NUM}(?:\s\d{{3}})*\s*{_CUR}(?!\w)", " ", s, flags=re.I)        # суммы и цены: 3 000 ₽, 500р
    s = re.sub(rf"(?<![\w×]){_NUM}\s*{_UNIT_WORDS}(?![\w×])", " ", s, flags=re.I)   # метраж: 18 м², 5 шт
    s = re.sub(rf"({_NUM})\s*[xх×*]\s*(?={_NUM})", r"\1×", s, flags=re.I)         # размеры 60 х 60 → 60×60 (остаются в названии)
    s = re.sub(rf"(?<![\w×.,]){_NUM}(?![\w×.,])", " ", s)                           # одинокие числа (количество, цена)
    s = re.sub(rf"(?<![\w]){_UNIT_WORDS}(?![\w])", " ", s, flags=re.I)             # единицы, оставшиеся без числа
    s = re.sub(rf"(?<!\w){_CUR}(?!\w)", " ", s, flags=re.I)
    s = re.sub(r"[₽₸%№#*=:;|/\\\"«»]", " ", s)
    s = re.sub(r"\s+", " ", s).strip(" -—–,.;:")
    if len(re.findall(r"[^\W\d_]", s)) < 3:
        return ""
    return s[:80][0].upper() + s[:80][1:]


def _stem(w: str) -> str:
    if len(w) > 5:
        return w[:-2]
    if len(w) > 3:
        return w[:-1]
    return w


def _tokens(title: str) -> list:
    s = title.lower().replace("ё", "е")
    s = re.sub(r"\([^()]*\)", " ", s)                       # пояснение в скобках («(одна цена)») не в счёт
    s = re.sub(rf"({_NUM})\s*[xх×*]\s*(?={_NUM})", r"\1×", s)   # 60х60 = 60 х 60 = 60×60
    words = re.findall(r"\d+(?:[.,]\d+)?×\d+(?:[.,]\d+)?|[^\W_]+", s)
    return [_stem(w) for w in words if w not in _STOP and len(w) > 1]


def norm_key(title: str) -> str:
    """Ключ для сравнения названий: без регистра и окончаний, слова по алфавиту («Укладка плитки» = «плитки укладка»)."""
    return " ".join(sorted(set(_tokens(title))))


def similarity(a: str, b: str) -> float:
    """Похожесть названий от 0 до 1."""
    ta, tb = set(_tokens(a)), set(_tokens(b))
    if not ta or not tb:
        return 0.0
    jac = len(ta & tb) / len(ta | tb)
    ratio = SequenceMatcher(None, " ".join(sorted(ta)), " ".join(sorted(tb))).ratio()
    return max(jac, ratio if jac >= 0.5 else ratio * 0.9)


def known_names() -> list:
    """Названия, с которыми сверяем: [(ссылка, название)]. Ссылка — ключ каталога или a<номер> одобренного названия."""
    names = [(k, it["title"]) for k, it in catalog.ITEM_BY_KEY.items() if k not in catalog.HIDDEN_DUPLICATES]
    return names + [(f"a{r['id']}", r["title"]) for r in db.pool_names()]


def suggest(title: str, n: int = 8) -> list:
    """Самые похожие известные названия: [(ссылка, название, похожесть)], лучшие первыми."""
    scored = [(ref, t, similarity(title, t)) for ref, t in known_names()]
    scored.sort(key=lambda x: -x[2])
    return scored[:n]


def match(title: str):
    """Подставляет похожее известное название: (ссылка, название) или None, если такого нет в каталоге и среди одобренных."""
    best = suggest(title, 1)
    if best and best[0][2] >= MATCH_SCORE:
        return best[0][0], best[0][1]
    return None


def default_unit(title: str) -> str:
    """Единица для строки без единицы: как у похожей работы каталога, иначе «шт»."""
    m = match(clean_title(title) or title)
    if m and m[0] in catalog.ITEM_BY_KEY:
        return catalog.ITEM_BY_KEY[m[0]]["unit"]
    return "шт"


def reference_price(title: str, unit: str, currency: str, ref: str | None):
    """Обычная цена этой работы в этой единице: медиана общего прайса (от 3 цен) или образец каталога; нет данных — None."""
    prices = db.pool_prices(title, unit, currency)
    if len(prices) >= 3:
        return median(prices)
    if ref in catalog.ITEM_BY_KEY and catalog.ITEM_BY_KEY[ref]["unit"] == unit:
        sample = catalog.sample_price(ref, currency)
        if sample > 0:
            return sample
    return None


def is_outlier(price: float, reference) -> bool:
    if price is None or price <= 0 or price > 10_000_000:
        return True
    return bool(reference) and (price > reference * OUTLIER_FACTOR or price < reference / OUTLIER_FACTOR)


def submit(lines: list, user) -> dict:
    """Кладёт услуги из загруженной сметы в общий прайс. lines — [(название, единица, цена)]; больше ничего не принимаем.

    Возвращает счётчики: added (в общий прайс), pending (на проверку владельцу), dropped (цена в разы от обычной
    или название не разобрать)."""
    country, city, cur = user["country"], user["city"] or "", user["currency"]
    stat = {"added": 0, "pending": 0, "dropped": 0}
    merged: dict = {}                       # одна услуга в одной смете = одна загрузка (цены усредняем)
    for title, unit, price in lines:
        t = clean_title(title)
        unit = (unit or "").strip()[:12]
        if not t or not unit or not price or price <= 0:
            stat["dropped"] += 1
            continue
        m = match(t)
        std, ref = (m[1], m[0]) if m else (t, None)
        merged.setdefault((std, ref, unit), []).append(float(price))
    for (std, ref, unit), prices in merged.items():
        price = round(sum(prices) / len(prices), 2)
        if ref is None:                      # такого названия нет в каталоге: только в список на проверку
            if is_outlier(price, None):
                stat["dropped"] += 1
            else:
                db.pending_add(std, norm_key(std), unit, price, country, city, cur)
                stat["pending"] += 1
        elif is_outlier(price, reference_price(std, unit, cur, ref)):
            stat["dropped"] += 1
        else:
            db.pool_add_price(std, unit, price, country, city, cur)
            stat["added"] += 1
    return stat


def stats_for(title: str, unit: str, currency: str):
    """Цена работы по общему прайсу: {'n', 'min', 'max', 'avg'} или None, пока загрузок меньше MIN_UPLOADS."""
    prices = db.pool_prices(title, unit, currency)
    if len(prices) < MIN_UPLOADS:
        return None
    return {"n": len(prices), "min": min(prices), "max": max(prices), "avg": sum(prices) / len(prices)}


def hint(title: str, unit: str, currency: str) -> str:
    """Подсказка «в общем прайсе от 300 до 500, ср. 400 (загрузок: 7)» или пустая строка."""
    s = stats_for(title, unit, currency)
    if not s:
        return ""
    sym = catalog.CURRENCIES[currency]["symbol"]
    n = lambda x: f"{round(x):,}".replace(",", " ")
    return f"в общем прайсе от {n(s['min'])} до {n(s['max'])} {sym}, ср. {n(s['avg'])} {sym} (загрузок: {s['n']})"


# --- Проверка названий владельцем -----------------------------------------------------
def resolve_ref(ref: str):
    """Ссылка → название: ключ каталога или a<номер> одобренного названия. Нет такого — None."""
    if ref in catalog.ITEM_BY_KEY:
        return catalog.ITEM_BY_KEY[ref]["title"]
    if re.fullmatch(r"a\d+", ref):
        row = next((r for r in db.pool_names() if r["id"] == int(ref[1:])), None)
        return row["title"] if row else None
    return None


def _move_group(rows, title: str, ref: str | None) -> dict:
    """Переносит загрузки группы в общий прайс под названием title; цены в разы от обычной отбрасывает."""
    stat = {"added": 0, "dropped": 0}
    ok = []
    for r in rows:
        if is_outlier(r["price"], reference_price(title, r["unit"], r["currency"], ref)):
            stat["dropped"] += 1
            continue
        ok.append(r)
    # у нового названия обычной цены ещё нет: отсеиваем то, что в разы далеко от середины самой группы
    if ref is None and len(ok) >= 3:
        mid = median(r["price"] for r in ok)
        keep = [r for r in ok if not is_outlier(r["price"], mid)]
        stat["dropped"] += len(ok) - len(keep)
        ok = keep
    for r in ok:
        db.pool_add_price(title, r["unit"], r["price"], r["country"], r["city"], r["currency"])
        stat["added"] += 1
    return stat


def merge_pending(row_id: int, ref: str):
    """«Объединить с существующей»: загрузки уходят под название каталога или одобренное. Возвращает (название, счётчики)."""
    title = resolve_ref(ref)
    rows = db.pending_rows(row_id)
    if not title or not rows:
        return None
    stat = _move_group(rows, title, ref)
    db.pending_delete(row_id)
    return title, stat


def approve_pending(row_id: int):
    """«Одобрить»: название становится новым в общем прайсе, его загрузки переносятся. Возвращает (название, счётчики)."""
    rows = db.pending_rows(row_id)
    if not rows:
        return None
    title = rows[0]["title"]
    if match(title):                        # пока ждало проверки, подходящее название уже появилось: дубль не создаём
        ref, title = match(title)
    else:
        ref = f"a{db.pool_add_name(title)}"
    stat = _move_group(rows, title, ref)
    db.pending_delete(row_id)
    return title, stat
