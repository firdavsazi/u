#!/usr/bin/env bash
# Обновление уже установленного бота «Смета» (код меняется, база и .env на сервере НЕ трогаются).
# Перед обновлением делается копия базы и старого кода (папка backups/before_update_<дата>).
# Запуск из распакованной папки: sudo bash update.sh
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "Запустите через sudo: sudo bash update.sh"; exit 1
fi

HERE="$(cd "$(dirname "$0")" && pwd)"
APP=/opt/smeta_bot
FILES="main.py db.py flow.py calc.py catalog.py market.py pool.py pdf_report.py xcalc.py sections.py pricefile.py hints.py market_data.json requirements.txt"

[ -d "$APP" ] || { echo "Не найдена папка $APP: бот ещё не установлен (нужен install.sh)."; exit 1; }
for f in $FILES; do
  [ -f "$HERE/$f" ] || { echo "Нет файла $f в архиве."; exit 1; }
done

STAMP="$(date +%Y-%m-%d_%H%M%S)"
echo "== 1/4 Копия базы и старого кода"
mkdir -p "$APP/backups/before_update_$STAMP"
if [ -f "$APP/bot.db" ]; then
  "$APP/.venv/bin/python" - "$APP/bot.db" "$APP/backups/before_update_$STAMP/bot.db" <<'PY'
import sqlite3, sys
src = sqlite3.connect(sys.argv[1]); dst = sqlite3.connect(sys.argv[2])
src.backup(dst); dst.close(); src.close()
PY
  [ -s "$APP/backups/before_update_$STAMP/bot.db" ] || { echo "Копия базы не получилась, обновление остановлено."; exit 1; }
fi
for f in $FILES; do [ -f "$APP/$f" ] && cp "$APP/$f" "$APP/backups/before_update_$STAMP/$f"; done
echo "   копия: $APP/backups/before_update_$STAMP"

echo "== 2/4 Новые файлы"
for f in $FILES; do cp "$HERE/$f" "$APP/$f"; done
chown -R smeta:smeta "$APP"

echo "== 3/4 Библиотеки (если изменились; для чтения PDF нужна pdfplumber)"
"$APP/.venv/bin/pip" install -q -r "$APP/requirements.txt" || \
  echo "ВНИМАНИЕ: библиотеки не поставились. Бот запустится, но кнопка «PDF» при загрузке прайса не появится (Excel работает)."

echo "== 4/4 Перезапуск бота"
echo "   При первом запуске бот один раз наведёт порядок в «Мои цены»: сделает ещё одну копию базы"
echo "   (backups/before_sections_<дата>.db), удалит точные дубли услуг и разложит их по разделам."
echo "   Итог (сколько удалено, сколько в каких разделах) придёт владельцу сообщением в Телеграм."
echo "   Потом в боте у владельца работают команды: «дубли» (проверка и удаление копий), «разложить» (услуги Без раздела по группам),"
echo "   «без раздела» (список сомнительных), «итоги разделов», «подсказки»."
systemctl restart smeta-bot
sleep 5
systemctl --no-pager --lines=20 status smeta-bot || true
echo
journalctl -u smeta-bot --since "2 minutes ago" --no-pager 2>/dev/null | grep -E "Уборка в|Ошибка|Traceback" || true
echo
echo "Готово. Журнал: journalctl -u smeta-bot -n 50 --no-pager"
echo "Откат: скопируйте файлы и bot.db из $APP/backups/before_update_$STAMP обратно в $APP и выполните: sudo systemctl restart smeta-bot"
