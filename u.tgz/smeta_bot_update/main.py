"""Телеграм-бот «Смета на отделку».

Запуск: python main.py  (токен берётся из файла .env, см. README.md).

Файлы проекта:
    main.py       — этот файл: экраны и обработчики бота
    flow.py       — цепочка вопросов для комнаты
    calc.py       — расчёт сметы (без Телеграма)
    catalog.py    — страны, валюты, образец цен
    db.py         — SQLite (bot.db)
    pdf_report.py — выгрузка сметы в PDF

Как устроено «запоминание шага»: каждая незаконченная смета — это «черновик»
(таблица drafts). После каждого действия его состояние пишется в базу, поэтому
человек может выйти, вернуться через день или после перезапуска бота — и
продолжить с того же места. Одновременно может быть открыто несколько смет.
Во всех кнопках мастера зашит номер черновика, поэтому старая кнопка из
прошлого сообщения никогда не попадёт «не в ту» смету.
"""
import html
import io
import json
import logging
import os
import re
import sys
from pathlib import Path
from typing import Optional
from urllib.parse import quote

from telegram import InlineKeyboardButton as Btn
from telegram import InlineKeyboardMarkup, InputFile, Update
from telegram.constants import ParseMode
from telegram.error import BadRequest
from telegram.ext import (Application, CallbackQueryHandler, CommandHandler,
                          ContextTypes, MessageHandler, TypeHandler, filters)

import calc
import catalog
import db
import flow
import hints
import market
import pdf_report
import pool
import pricefile
import sections
import xcalc
from calc import fmoney, fnum

log = logging.getLogger("smeta")

# Комнаты главного меню: (код, эмодзи, название)
ROOMS = [
    ("bathroom", "🛁", "Ванная"), ("toilet", "🚽", "Туалет"),
    ("bedroom", "🛏", "Спальня"), ("corridor", "🚶", "Коридор"),
    ("kitchen", "🍳", "Кухня"), ("balcony", "🌇", "Балкон"),
    ("living", "🛋", "Гостиная"), ("kids", "🧸", "Детская"),
    ("hall", "🧥", "Прихожая"),
]
ROOM_NAME = {code: f"{icon} {name}" for code, icon, name in ROOMS}
ROOM_TITLE = {code: name for code, icon, name in ROOMS}
ROOM_ICON = {code: icon for code, icon, name in ROOMS}
READY_ROOMS = ("bathroom", "toilet")  # у остальных комнат готовых вопросов нет — они собираются в конструкторе

# Единицы измерения для кнопок при добавлении работы
UNITS = {"m2": "м²", "pm": "пог.м", "pc": "шт", "pt": "точка", "rm": "помещ.", "kp": "компл."}

# Статусы сметы: Открыта (можно править) → В работе (основные строки защищены, есть «Доп. работы») → Завершена (архив)
STATUS_NAME = {"open": "Открыта", "work": "В работе", "done": "Завершена"}
STATUS_ICON = {"open": "🟢", "work": "🛠", "done": "🗄"}
NOTE_MAX = 2000

TG_LIMIT = 3800  # запас до лимита Телеграма в 4096 символов


# =============================================================================
# Служебное: токен, оформление, показ экранов
# =============================================================================
def load_env(name: str) -> str:
    """Читает переменную из окружения или из файла .env рядом с main.py (значения не печатаем)."""
    value = os.environ.get(name, "").strip()
    env_file = Path(__file__).with_name(".env")
    if not value and env_file.exists():
        for line in env_file.read_text(encoding="utf-8-sig").splitlines():
            line = line.strip()
            if line.startswith(name + "="):
                value = line.split("=", 1)[1].strip().strip("\"'")
    return value


def load_token() -> str:
    """Токен бота (TELEGRAM_BOT_TOKEN). Он нигде не печатается."""
    return load_env("TELEGRAM_BOT_TOKEN")


def developer_url() -> str:
    """Ссылка на личные сообщения разработчику: DEVELOPER_USERNAME в .env (например, @username). Пусто — кнопки нет."""
    name = load_env("DEVELOPER_USERNAME").lstrip("@").strip()
    return f"https://t.me/{name}" if re.fullmatch(r"[A-Za-z0-9_]{4,32}", name) else ""


def esc(s) -> str:
    """Экранирование пользовательского текста для HTML-разметки Телеграма."""
    return html.escape(str(s))


def header(user) -> str:
    """Строка вверху экранов: «🇷🇺 Челябинск · рубли · русский»."""
    country = catalog.COUNTRIES[user["country"]]
    place = f"{country['flag']} {user['city']}".strip()
    return " · ".join([place, catalog.CURRENCIES[user["currency"]]["name"], catalog.LANGS[user["lang"]]])


def money(user, x) -> str:
    return fmoney(x, user["currency"])


def remember_screen(context: ContextTypes.DEFAULT_TYPE, text: str, rows: list, await_input) -> None:
    """Запоминает, что сейчас на экране и ждёт ли бот текст (await_input).
    Это нужно, чтобы на неожиданный ввод показать тот же экран заново."""
    ud = context.user_data
    ud["await"] = await_input
    ud["last"] = {"text": text, "rows": [[(b.text, b.callback_data, b.url) for b in row] for row in rows]}


async def show(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, rows: list, *,
               user=None, edit: bool = True, await_input=None) -> None:
    """Показывает экран: правит сообщение с кнопкой или шлёт новое.
    Если передан user, первой строкой идёт кнопка-заголовок со сменой настроек.
    await_input — что бот ждёт текстом на этом экране (None — ждёт только кнопки)."""
    if user is not None:
        rows = [[Btn(header(user), callback_data="settings")]] + rows
    markup = InlineKeyboardMarkup(rows)
    remember_screen(context, text, rows, await_input)
    q = update.callback_query
    if q and edit:
        try:
            await q.edit_message_text(text, reply_markup=markup, parse_mode=ParseMode.HTML)
            return
        except BadRequest as e:
            if "not modified" in str(e).lower():
                return
            # сообщение нельзя править (например, это файл) — пошлём новое
    await update.effective_chat.send_message(text, reply_markup=markup, parse_mode=ParseMode.HTML)


async def resend_last(update: Update, context: ContextTypes.DEFAULT_TYPE, hint: str = "") -> bool:
    """Показывает последний экран ещё раз (новым сообщением), с подсказкой сверху.
    Возвращает False, если показывать нечего."""
    last = context.user_data.get("last")
    if not last:
        return False
    rows = [[Btn(t, callback_data=cb, url=url) for t, cb, url in row] for row in last["rows"]]
    await update.effective_chat.send_message((hint + "\n\n" if hint else "") + last["text"],
                                             reply_markup=InlineKeyboardMarkup(rows), parse_mode=ParseMode.HTML)
    return True


def split_text(text: str) -> list[str]:
    """Режет длинный текст по переводам строк на куски до TG_LIMIT символов."""
    chunks, cur = [], ""
    for line in text.split("\n"):
        if cur and len(cur) + len(line) + 1 > TG_LIMIT:
            chunks.append(cur)
            cur = ""
        cur = f"{cur}\n{line}" if cur else line
    chunks.append(cur)
    return chunks


async def show_long(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, rows: list, *, user=None) -> None:
    """Как show, но для длинных смет: первые куски без кнопок, кнопки — под последним."""
    chunks = split_text(text)
    if len(chunks) == 1:
        await show(update, context, text, rows, user=user)
        return
    for i, chunk in enumerate(chunks[:-1]):
        if i == 0 and update.callback_query:
            try:
                await update.callback_query.edit_message_text(chunk, parse_mode=ParseMode.HTML)
                continue
            except BadRequest:
                pass
        await update.effective_chat.send_message(chunk, parse_mode=ParseMode.HTML)
    await show(update, context, chunks[-1], rows, user=user, edit=False)


# =============================================================================
# Память между сообщениями: сессия и черновики хранятся в базе
# =============================================================================
# Что из памяти человека хранится в базе между перезапусками бота (xc — список работ калькулятора)
SESSION_KEYS = ("await", "cur_obj", "cur_kind", "last", "draft_id", "xc", "obj_flt", "ref")


async def load_session(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Перед обработкой первого сообщения после запуска бота поднимаем из базы,
    на каком экране и в какой смете человек остановился."""
    if not update.effective_user:
        return
    ud = context.user_data
    if ud.get("_loaded"):
        return
    ud["_loaded"] = True
    uid = update.effective_user.id
    s = db.get_session(uid)
    if not s:
        return
    for k in SESSION_KEYS:
        ud[k] = s.get(k)
    if ud.get("draft_id"):
        row = db.get_draft(uid, ud["draft_id"])
        if row:
            ud["est"] = json.loads(row["state"])
            ud["est"]["id"] = ud["draft_id"]
        else:
            ud["draft_id"] = None


def flush(uid: int, ud: dict) -> None:
    """Записывает в базу текущую смету (если изменилась) и состояние сессии."""
    est, did = ud.get("est"), ud.get("draft_id")
    if est and did and est.get("id") == did:
        state = json.dumps(est, ensure_ascii=False, sort_keys=True)
        if ud.get("_saved_state") != (did, state):
            db.save_draft(uid, did, draft_title(est), est_step_label(est), est.get("obj"), state)
            ud["_saved_state"] = (did, state)
    data = {k: ud.get(k) for k in SESSION_KEYS}
    js = json.dumps(data, ensure_ascii=False, sort_keys=True)
    if ud.get("_saved_session") != js:
        db.save_session(uid, data)
        ud["_saved_session"] = js


async def persist(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """После каждого обработанного сообщения сохраняем состояние."""
    if update.effective_user:
        flush(update.effective_user.id, context.user_data)


# =============================================================================
# Первый вход и настройки
# =============================================================================
WELCOME = (
    "👋 <b>Привет! Я считаю смету на отделочные работы.</b>\n\n"
    "⚠️ <b>Важно:</b> цены, которые вы вводите в «Мои цены», попадают в общую анонимную "
    "базу цен — без имени, аккаунта, адресов и объектов (только страна и город).\n\n"
    "Для начала выберите страну:"
)


def country_rows(prefix: str = "cc") -> list:
    return [[Btn(f"{c['flag']} {c['name']}", callback_data=f"{prefix}:{code}")]
            for code, c in catalog.COUNTRIES.items()]


SEATS_CLOSED = ("😔 Места в бесплатном тесте закончились, о запуске для всех сообщим в канале.")


async def show_seats_closed(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Для тех, кто пришёл после сотого: записываем в список ожидания и ничего больше не открываем."""
    db.add_waitlist(update.effective_user.id)
    context.user_data["await"] = None
    rows = []
    if channel_link():
        rows.append([Btn("📢 Наш канал", url=channel_link())])
    await show(update, context, SEATS_CLOSED, rows, edit=False)


async def start_onboarding(update: Update, context: ContextTypes.DEFAULT_TYPE, ref: str = "") -> None:
    """Экран первого входа: предупреждение и выбор страны (если ещё есть бесплатные места).
    ref — код из ссылки-приглашения: запоминаем, чтобы привязать человека к пригласившему."""
    if not db.seat_open() and not is_owner(update.effective_user.id):
        await show_seats_closed(update, context)
        return
    ud = context.user_data
    for k in [k for k in ud if k != "_loaded"]:
        del ud[k]
    if ref:
        ud["ref"] = ref
    await show(update, context, WELCOME, country_rows(), edit=False)


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    if user and user["ready"]:
        await entry_continue(update, context)
        return
    arg = (context.args[0] if getattr(context, "args", None) else "")
    await start_onboarding(update, context, arg[2:] if arg.startswith("r_") else "")


async def choose_country(update: Update, context: ContextTypes.DEFAULT_TYPE, code: str) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    country = catalog.COUNTRIES[code]
    if not user:
        if not db.seat_open() and not is_owner(uid):  # пока человек выбирал страну, места разобрали
            await show_seats_closed(update, context)
            return
        inviter = db.user_by_ref(context.user_data.get("ref") or "")
        db.create_user(uid, code, inviter["user_id"] if inviter and inviter["user_id"] != uid else None)
        context.user_data.pop("ref", None)
    else:  # смена страны: язык и валюту предлагаем заново
        db.update_user(uid, country=code, lang=country["langs"][0], currency=country["currency"])
    user = db.get_user(uid)
    if not user["city"]:
        await show(update, context, "🏙 Напишите ваш город (например, Челябинск):", [], user=user,
                   await_input={"kind": "city"})
    else:
        await show_settings(update, context)


async def show_settings(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    c = catalog.COUNTRIES[user["country"]]
    text = (
        "⚙️ <b>Настройки</b>\n\n"
        f"Страна: {c['flag']} {c['name']}\n"
        f"Город: {esc(user['city'] or '—')}\n"
        f"Язык: {catalog.LANGS[user['lang']]}\n"
        f"Валюта: {catalog.CURRENCIES[user['currency']]['name']}\n"
    )
    if user["nick"]:
        text += f"Ник: {esc(user['nick'])}\n"
    if user["ready"]:
        rate = user["day_rate"] or 0
        text += ("Минимум по дням: " + (f"включён, {money(user, rate)} за день" if user["day_min_on"] and rate > 0
                                        else "выключен") + "\n")
    if user["lang"] != "ru":
        text += "\nℹ️ Интерфейс бота пока только на русском, выбранный язык сохранён в профиле.\n"
    if note:
        text += f"\n{note}\n"
    rows = [[Btn("🌍 Страна", callback_data="set:country"), Btn("🏙 Город", callback_data="set:city")],
            [Btn("🗣 Язык", callback_data="set:lang"), Btn("💱 Валюта", callback_data="set:cur")]]
    if user["ready"] and user["nick"]:
        rows.append([Btn("✏️ Ник", callback_data="set:nick")])
    if user["ready"]:
        on = bool(user["day_min_on"] and (user["day_rate"] or 0) > 0)
        rows.append([Btn(f"{'✅' if on else '⬜'} Минимум по дням", callback_data="set:daymin"),
                     Btn("💶 Сумма за день", callback_data="set:dayrate")])
        rows.append([Btn("⬅️ В меню", callback_data="menu")])
    else:
        text += "\nЯ подобрал язык и валюту по вашей стране. Если всё верно — нажмите «Готово», если нет — поменяйте."
        rows.append([Btn("✅ Готово", callback_data="done")])
    await show(update, context, text, rows, user=user)


async def ask_day_rate(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Сумма минимального заказа за один день работы (кусок 3, «Минимум по дням»)."""
    user = db.get_user(update.effective_user.id)
    now = user["day_rate"] or 0
    await show(update, context,
               "📅 <b>Минимум по дням</b>\nСколько стоит один рабочий день минимум? Например 3000. Один день — столько, "
               "два дня — вдвое больше, от трёх дней умножается на число дней. Если смета получится дешевле, "
               "итог поднимется до минимума (не прибавится к нему).\n\n"
               + (f"Сейчас: {money(user, now)}.\n" if now else "") + "Напишите сумму за день числом:",
               [[Btn("⬅️ Назад", callback_data="settings")]], user=user, await_input={"kind": "dayrate"})


async def finish_onboarding(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    db.ensure_prices(uid)  # заполняем личный прайс образцом
    db.update_user(uid, ready=1)
    context.user_data["fresh"] = True   # на первом меню напомним про образец прайса
    await entry_continue(update, context)


# =============================================================================
# Вход: подписка на канал → политика → ник → тестовый режим; срок и лимит бесплатных мест
# =============================================================================
POLICY_SHORT = (
    "📄 <b>Политика конфиденциальности</b>\n\n"
    "Перед началом прочитайте условия. Бот хранит ваши сметы, цены и настройки, ваше настоящее имя не показывает "
    "и данные не продаёт. Бот и его материалы принадлежат разработчикам бота. Полный текст всегда доступен "
    "в меню. Нажимая «Согласен», вы принимаете условия."
)
POLICY_FULL = (
    "📄 <b>Политика конфиденциальности</b>\n\n"
    "<b>1. Кто мы.</b> Бот {bot} и все его материалы (тексты, расчёты, база расценок, оформление, название) "
    "принадлежат разработчикам бота. Копировать, перепродавать и выдавать их за свои без письменного согласия "
    "разработчиков нельзя.\n\n"
    "<b>2. Какие данные бот хранит.</b> Только то, что нужно для работы: ваш номер аккаунта в Телеграме, "
    "выбранные язык, страну, город и валюту, ник (если вы его указали), ваши сметы, объекты, заметки и личные "
    "цены, а также ваши сообщения в разделах «Пожелания» и «Есть ошибка». Бот не просит и не хранит паспортные "
    "данные, банковские карты, пароли и точный адрес. Не вводите их в бот.\n\n"
    "<b>3. Зачем нужны данные.</b> Чтобы считать сметы, сохранять ваши объекты и цены, улучшать бота по вашим "
    "пожеланиям и сообщениям об ошибках, а также считать общую статистику (сколько людей, смет и популярных "
    "работ).\n\n"
    "<b>4. Что видят другие люди.</b> Ваши сметы и личные цены видите только вы и те, кому вы сами отправили "
    "смету кнопкой «Поделиться». Ваше настоящее имя не показывается другим пользователям.\n\n"
    "<b>5. Общий прайс.</b> Если вы дали согласие, ваши цены могут попадать в общий прайс без вашего имени и "
    "без привязки к вам: только название работы, единица и цена. Согласие можно отозвать в «Настройках».\n\n"
    "<b>6. Передача третьим лицам.</b> Мы не продаём ваши данные и не передаём их рекламным сервисам. Бот "
    "работает на сервере в Европе. Данные также обрабатывает сам Телеграм по своим правилам.\n\n"
    "<b>7. Сколько хранятся данные.</b> Пока вы пользуетесь ботом. Вы можете попросить удалить ваши данные, "
    "написав разработчикам через кнопку ниже, и они будут удалены в разумный срок.\n\n"
    "<b>8. Оплата.</b> Когда появятся платные тарифы, платёжные данные будет обрабатывать платёжный сервис. "
    "Бот их не видит и не хранит.\n\n"
    "<b>9. Результаты расчётов.</b> Сметы в боте носят справочный характер. Итоговую цену и объём работ вы "
    "согласуете со своим клиентом сами. Разработчики не отвечают за расхождения между расчётом и реальной "
    "стоимостью работ. Бот работает в тестовом режиме, возможны недочёты.\n\n"
    "<b>10. Изменения.</b> Текст может меняться. О существенных изменениях бот сообщит при входе. Дата "
    "последней редакции: 9 ноября 2026.\n\n"
    "<b>11. Согласие.</b> Нажимая «Согласен» при первом входе, вы подтверждаете, что прочитали этот текст и "
    "принимаете его условия. Прочитать его снова можно в любой момент в разделе «Политика конфиденциальности» "
    "в меню.\n\n"
    "<b>Связь с разработчиками.</b> Вопрос, просьба удалить данные или предложение: кнопка «Написать "
    "разработчику» (открывает раздел «Пожелания»)."
)


def bot_name() -> str:
    """Название бота для текстов: настройка bot_name (меняется без правки кода)."""
    return db.get_setting("bot_name").strip() or str(db.DEFAULT_SETTINGS["bot_name"])
NICK_ASK = "🏷 <b>Как вас называть?</b>\nПридумайте ник или пропустите."
TEST_MODE_TEXT = (
    "Бот работает в тестовом режиме, поэтому возможны недочёты. Мы стараемся для вас: если нашли ошибку или "
    "не хватает нужной функции, напишите в разделе «Пожелания» или кнопкой «Есть ошибка». Мы всё читаем, "
    "исправляем и улучшаем бота под вашу работу."
)
EXPIRED_TEXT = (
    "⏳ Срок вашего бесплатного теста закончился. Спасибо, что пользовались ботом!\n\n"
    "Тарифы скоро появятся, мы сообщим об этом. Ваши сметы, цены и объекты сохранены, ничего не удалено."
)


def channel_name() -> str:
    """Общий канал для подписки: настройка channel_username (или CHANNEL_USERNAME в .env). Пусто — шаг пропускается."""
    name = (db.get_setting("channel_username") or load_env("CHANNEL_USERNAME")).strip()
    if name and not name.startswith("@") and not name.lstrip("-").isdigit():
        name = "@" + name
    return name


def channel_link() -> str:
    link = (db.get_setting("channel_link") or load_env("CHANNEL_LINK")).strip()
    name = channel_name()
    if not link and name.startswith("@"):
        link = f"https://t.me/{name[1:]}"
    return link


def days_word(n: int) -> str:
    n = abs(int(n))
    if n % 10 == 1 and n % 100 != 11:
        return "день"
    if 2 <= n % 10 <= 4 and not 12 <= n % 100 <= 14:
        return "дня"
    return "дней"


def date_ru(s: str) -> str:
    """«2026-12-01 15:46:57» → «01.12.2026»."""
    return f"{s[8:10]}.{s[5:7]}.{s[0:4]}" if s else "—"


def entry_step(user) -> Optional[str]:
    """На каком шаге входа человек: full (мест нет) · sub · policy · nick · seat (надо занять место) · welcome ·
    expired (срок кончился) · None (всё пройдено)."""
    owner = is_owner(user["user_id"])
    if user["joined"] is None and not owner and not db.seat_open():
        return "full"
    if channel_name() and not user["sub_ok"]:
        return "sub"
    if not user["policy_ok"]:
        return "policy"
    if not user["nick"]:
        return "nick"
    if user["joined"] is None:
        return "seat"
    if not user["welcomed"]:
        return "welcome"
    if not owner and db.is_expired(user):   # у владельца срока нет
        return "expired"
    return None


async def entry_continue(update: Update, context: ContextTypes.DEFAULT_TYPE) -> Optional[str]:
    """Показывает следующий незавершённый шаг входа; если все пройдены — главное меню. Возвращает шаг (None — меню)."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    step = entry_step(user)
    if step == "seat":
        if not db.take_seat(uid, force=is_owner(uid)):
            step = "full"
        else:
            user = db.get_user(uid)
            step = entry_step(user)
    if step == "full":
        await show_seats_closed(update, context)
    elif step == "sub":
        await show_sub(update, context)
    elif step == "policy":
        await show_policy_consent(update, context)
    elif step == "nick":
        await ask_nick(update, context, entry=True)
    elif step == "welcome":
        await show_welcome(update, context, user)
    elif step == "expired":
        await show_expired(update, context)
    else:
        intro = ""
        if context.user_data.pop("fresh", None):
            intro = "✅ Готово! Я заполнил ваш прайс образцом — поправьте его в разделе «💰 Мои цены».\n\n"
        await send_menu(update, context, intro=intro)
    return step


def view_only(user) -> bool:
    """Срок бесплатного теста кончился: сохранённые сметы смотреть можно, создавать и менять нельзя."""
    return entry_step(user) == "expired"


def expired_may_open(p: list) -> bool:
    """Какие кнопки работают после конца срока: только просмотр сохранённого (объекты, сметы, PDF сохранённой сметы)."""
    cmd, sub = p[0], (p[1] if len(p) > 1 else "")
    if cmd == "tiler":
        return True
    if cmd == "obj":
        return sub in ("list", "closed", "st", "flt") or sub.isdigit()
    if cmd == "est":
        return sub.isdigit()
    if cmd in ("sh", "shp"):
        return sub.isdigit()   # d… — это ещё не сохранённая смета, её не отправляем
    if cmd == "fb":
        return len(p) > 2 and p[2][:1] == "e"   # «Верно» / «Есть ошибка» у сохранённой сметы
    return False


async def entry_block(update: Update, context: ContextTypes.DEFAULT_TYPE, user, p: Optional[list] = None) -> bool:
    """Если у человека не пройден вход или кончился срок — показывает нужный экран и возвращает True (дальше не пускаем).
    p — разобранные данные нажатой кнопки: после конца срока просмотр сохранённого пропускаем."""
    step = entry_step(user)
    if step is None or (step == "expired" and p and expired_may_open(p)):
        return False
    await entry_continue(update, context)
    return True


# --- Подписка на канал ---------------------------------------------------------------------
async def show_sub(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    rows = []
    if channel_link():
        rows.append([Btn("📢 Открыть канал", url=channel_link())])
    rows.append([Btn("✅ Я подписался", callback_data="sub:chk")])
    await show(update, context, note + "📢 <b>Подпишитесь на наш канал</b>\nТам новости бота, обновления и запуск "
                                       "для всех. Подпишитесь и нажмите «Я подписался».", rows, edit=False)


async def sub_check(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Проверяет подписку. Если Телеграм не даёт проверить (бот не админ канала, канал не найден) — не запираем
    людей навсегда: пускаем дальше и пишем причину в журнал бота."""
    uid = update.effective_user.id
    q = update.callback_query
    try:
        member = await context.bot.get_chat_member(channel_name(), uid)
        subscribed = member.status in ("member", "administrator", "creator") or (
            member.status == "restricted" and getattr(member, "is_member", False))
    except Exception as e:
        log.warning("Не удалось проверить подписку на канал %s: %s. Пропускаем человека "
                    "(бот должен быть администратором канала).", channel_name(), type(e).__name__)
        subscribed = True
    if not subscribed:
        if q:
            await q.answer("Подписки пока не видно. Подпишитесь и нажмите ещё раз.", show_alert=True)
        return
    if q:
        await q.answer()
    db.update_user_fields(uid, sub_ok=1)
    await entry_continue(update, context)


# --- Политика конфиденциальности -----------------------------------------------------------
async def show_policy_consent(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await show(update, context, POLICY_SHORT,
               [[Btn("✅ Согласен", callback_data="pol:ok")],
                [Btn("📄 Полный текст", callback_data="polv:c")]], edit=False)


async def show_policy_full(update: Update, context: ContextTypes.DEFAULT_TYPE, back: str) -> None:
    """Раздел меню «Политика конфиденциальности» (полный текст). back: c — к согласию, m — в меню."""
    rows = [[Btn("✉️ Написать разработчику", callback_data="wish")],
            [Btn("⬅️ Назад" if back == "c" else "⬅️ В меню", callback_data="pol:back" if back == "c" else "menu")]]
    await show(update, context, POLICY_FULL.replace("{bot}", esc(bot_name())), rows)


# --- Ник ---------------------------------------------------------------------------------------
NICK_BAD_STEMS = (
    "хуй", "хуе", "хуё", "хуя", "хули", "пизд", "пезд", "ебан", "ёбан", "ебат", "ебал", "ебну", "ебуч", "еблан",
    "блят", "бляд", "мудак", "мудил", "пидор", "пидар", "пидр", "гандон", "гондон", "залуп", "шлюх", "говн",
    "дерьм", "дебил", "идиот", "урод", "тварь", "гнид", "долбо", "чмо", "сучк", "сучар", "мразь", "ублюд",
)
NICK_BAD_WORDS = ("сука", "суки", "суке", "бля", "чмо")
NICK_RESERVED = ("админ", "admin", "разработчик", "владелец", "поддержка", "support", "модератор")


def nick_error(nick: str, uid: int) -> str:
    """Почему ник не подходит (пустая строка — подходит)."""
    nick = re.sub(r"\s+", " ", nick.strip())
    low = db.nick_norm(nick)
    if not 2 <= len(nick) <= 24:
        return "Ник должен быть от 2 до 24 символов."
    if re.search(r"https?|www|t\.me|@|\.[a-zа-я]{2,}|/", low):
        return "В нике не должно быть ссылок и адресов."
    if sum(ch.isdigit() for ch in nick) >= 5 or re.search(r"\d[\d\s\-()]{5,}\d", nick):
        return "В нике не должно быть телефонов и длинных цифр."
    if not re.fullmatch(r"[A-Za-zА-Яа-яЁё0-9 _\-]+", nick) or not re.search(r"[A-Za-zА-Яа-яЁё]", nick):
        return "Ник может состоять из букв, цифр, пробела, «_» и «-» (и в нём должна быть хотя бы одна буква)."
    words = re.findall(r"[a-zа-я0-9]+", low)
    if any(w in NICK_BAD_WORDS or w.startswith(NICK_BAD_STEMS) for w in words) or any(s in low for s in ("хуй", "пизд")):
        return "Такой ник не подойдёт. Придумайте другой."
    if any(r in low for r in NICK_RESERVED):
        return "Такой ник не подойдёт. Придумайте другой."
    if db.is_reserved_nick(nick):
        return "Этот ник зарезервирован. Придумайте другой."
    if db.nick_taken(nick, uid):
        return "Такой ник уже занят. Придумайте другой."
    return ""


async def ask_nick(update: Update, context: ContextTypes.DEFAULT_TYPE, entry: bool, note: str = "") -> None:
    if entry:
        rows = [[Btn("⏭ Пропустить", callback_data="nick:skip")]]
    else:
        rows = [[Btn("⬅️ Назад", callback_data="settings")]]
    await show(update, context, note + NICK_ASK, rows, await_input={"kind": "nick", "entry": entry}, edit=False)


async def save_nick(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, entry: bool) -> None:
    uid = update.effective_user.id
    err = nick_error(text, uid)
    if err:
        await ask_nick(update, context, entry, note=f"⚠️ {err}\n\n")
        return
    db.set_nick(uid, text)
    context.user_data["await"] = None
    if entry:
        await entry_continue(update, context)
    else:
        await show_settings(update, context, "✅ Ник сохранён.")


async def skip_nick(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    if not db.get_user(uid)["nick"]:
        db.auto_nick(uid)
    context.user_data["await"] = None
    await entry_continue(update, context)


# --- Тестовый режим, срок, конец срока -------------------------------------------------------
async def show_welcome(update: Update, context: ContextTypes.DEFAULT_TYPE, user) -> None:
    text = f"🛠 {TEST_MODE_TEXT}\n\n🎁 <b>Бесплатный тест для первых {db.free_limit()} пользователей</b>"
    if not is_owner(user["user_id"]):   # у владельца срока нет, дату не показываем
        text += f"\nВаш бесплатный срок: до {date_ru(user['expires'])}."
    await show(update, context, text, [[Btn("▶️ Начать", callback_data="wl:ok")]], edit=False)


async def show_expired(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    rows = []
    if channel_link():
        rows.append([Btn("📢 Наш канал", url=channel_link())])
    rows.append([Btn("📁 Мои сметы (просмотр)", callback_data="obj:list")])
    rows.append([Btn("💬 Пожелания", callback_data="wish"), Btn("📄 Политика", callback_data="polv:m")])
    await show(update, context, EXPIRED_TEXT, rows, edit=False)


# =============================================================================
# Главное меню
# =============================================================================
async def send_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, intro: str = "") -> None:
    """Главное меню. Открытые сметы тут НЕ трогаются: их можно продолжить."""
    uid = update.effective_user.id
    ud = context.user_data
    user = db.get_user(uid)
    db.ensure_prices(uid)  # вдруг в прайсе появились новые позиции
    flush(uid, ud)         # чтобы название и шаг текущей сметы в меню были свежими
    text = f"{intro}🏠 <b>Главное меню</b>\nВыберите комнату для расчёта сметы:"
    rows = []
    drafts = db.list_drafts(uid)
    if drafts:
        target = next((d for d in drafts if d["id"] == ud.get("draft_id")), drafts[0])
        text += f"\n\n▶️ Продолжаем: {esc(target['title'])}, шаг: {esc(target['step'])}."
        rows.append([Btn("▶️ Продолжить смету", callback_data=f"dr:{target['id']}")])
        rows.append([Btn(f"📋 Мои открытые сметы ({len(drafts)})", callback_data="drl")])
    obj_id = ud.get("cur_obj")
    if obj_id:
        obj = db.get_object(uid, obj_id)
        if obj:
            what = "допработа (отдельная смета)" if ud.get("cur_kind") == "extra" else "смета"
            text += f"\n\n📁 Новая {what} будет сохранена в объект «{esc(obj['name'])}»."
        else:
            ud.pop("cur_obj", None)
            ud.pop("cur_kind", None)
            obj_id = None
    room_buttons = [Btn(f"{icon} {name}", callback_data=f"room:{code}") for code, icon, name in ROOMS]
    for i in range(0, len(room_buttons), 2):
        rows.append(room_buttons[i:i + 2])
    rows.append([Btn("➕ Добавить своё помещение", callback_data="room:own")])
    rows.append([Btn("🔧 Мелкие работы", callback_data="small:start"), Btn("🏗 Объект без стен", callback_data="open:start")])
    rows.append([Btn("📁 Мои объекты", callback_data="obj:list"), Btn("💰 Мои цены", callback_data="price:list")])
    rows.append([Btn("📚 Прайсы", callback_data="pm:start"), Btn("🧮 Калькулятор из Excel", callback_data="xc:start")])
    rows.append([Btn("💬 Пожелания и замечания", callback_data="wish")])
    rows.append([Btn("🤝 Пригласить друга", callback_data="inv"), Btn("❓ Помощь", callback_data="help")])
    rows.append([Btn("📄 Политика конфиденциальности", callback_data="polv:m")])
    if obj_id:
        rows.append([Btn("❎ Не привязывать к объекту", callback_data="obj:unlink")])
    await show(update, context, text, rows, user=user)


HELP = (
    "❓ <b>Как пользоваться</b>\n\n"
    "1. В главном меню выберите комнату. Ванная и туалет считаются по готовым вопросам.\n"
    "2. Остальные комнаты: после выбора комнаты замер вводится одним экраном (длина, ширина, высота, "
    "вычеты двери, окна и своих проёмов). Дальше — конструктор: один общий список работ с галочками. "
    "Количество бот считает сам по замеру, любую строку можно поправить в итоге.\n"
    "3. В итоге смета с разбивкой по разделам. Там же можно добавить работу, поменять цену, "
    "сохранить смету в объект или отправить PDF. Если на работу не указана цена, рядом с итогом "
    "будет кнопка «Указать цену», цена сохранится в «Мои цены».\n"
    "«⬅️ Назад» возвращает на шаг назад. Варианты выбирайте кнопками, числа пишите текстом "
    "(можно и с запятой, и с точкой).\n\n"
    "▶️ <b>Смета не пропадает.</b> Вышли в меню или закрыли Телеграм — в меню будет кнопка "
    "«Продолжить смету», а все незаконченные сметы лежат в «📋 Мои открытые сметы».\n\n"
    "📁 <b>Мои объекты</b> — папки (адрес или клиент). Внутри лежат сметы и допработы, сумма по объекту "
    "собирается из них. Когда работа закончена, нажмите «Завершить объект». "
    "Кнопка «⬜ Плиточник» показывает все сметы с плиткой по всем объектам.\n"
    "🔄 <b>Статус сметы</b>: «Открыта» (можно править), «В работе» (основные строки защищены, новое — кнопкой "
    "«Доп. работы»), «Завершена» (уходит в архив: можно смотреть, нельзя изменить случайно, из архива смету "
    "можно вернуть). «📝 Заметка» — одна на смету и одна на объект, клиенту в PDF она не попадает.\n"
    "🧮 <b>Калькулятор из Excel</b> — свой список работ файлом или текстом, бот посчитает итог. "
    "Цены из файла не меняют «Мои цены», пока вы сами не нажмёте «Сохранить эти цены».\n"
    "💰 <b>Мои цены</b> — ваш личный прайс и минимальная сумма выезда. "
    "Свой прайс можно загрузить файлом Excel: кнопка «Загрузить прайс файлом».\n"
    "Строка со страной, городом и валютой остаётся в главном меню и на итоговом экране: "
    "нажмите на неё, чтобы сменить настройки.\n\n"
    "🎁 Первые {limit} мест — бесплатно (30 дней со дня входа).\n"
    "🛠 Бот в разработке: вопросы и пожелания приветствуются."
)

# Частые вопросы: (вопрос на кнопке, ответ)
FAQ = [
    ("Сколько стоит бот",
     "Первые 100 пользователей пользуются бесплатно в тестовый период. Потом будут тарифы, о них сообщим заранее."),
    ("Как поменять цену",
     "Цену можно поменять тремя способами: в «Мои цены», в списке работ при выборе и в готовой смете кнопкой "
     "«Изменить цену». Любая изменённая цена запоминается и подставляется в следующие сметы."),
    ("Как отправить смету клиенту",
     "В готовой смете нажмите «Поделиться», выберите вид: подробная, с метражом и ценами, или короткая, только услуги "
     "и общая сумма. Потом отправьте PDF клиенту в мессенджере или на почту."),
    ("Что значит «не указана цена»",
     "Для этой работы нет цены, поэтому она не вошла в итог. Нажмите «Указать цену» и введите свою, тогда работа "
     "попадёт в смету, а цена запомнится на будущее."),
    ("Как сохранить смету в объекте",
     "В готовой смете нажмите «Сохранить» и выберите объект (адрес или имя клиента) или создайте новый. Все сметы по "
     "объекту лежат в «Мои объекты», итоговая сумма по объекту собирается из них."),
    ("Как загрузить свой прайс",
     "Откройте «Мои цены» → «Загрузить прайс файлом» (или «Добавить свою работу» → «Загрузить прайс файлом»). Выберите "
     "«Таблица Excel» или «PDF»: у обоих три колонки — Услуга, Единица, Цена. Строка, где заполнено только название, "
     "начинает раздел. Бот покажет, сколько работ нашёл, и после вашего подтверждения добавит их в «Мои цены»."),
]


async def show_help(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = db.get_user(update.effective_user.id)
    rows = [[Btn("💬 Частые вопросы", callback_data="faq")]]
    url = developer_url()
    if url:
        rows.append([Btn("✉️ Написать разработчику", url=url)])
    rows.append([Btn("⬅️ В меню", callback_data="menu")])
    await show(update, context, HELP.replace("{limit}", str(db.free_limit())), rows, user=user)


async def show_faq(update: Update, context: ContextTypes.DEFAULT_TYPE, idx=None) -> None:
    user = db.get_user(update.effective_user.id)
    if idx is None or not 0 <= idx < len(FAQ):
        rows = [[Btn(q, callback_data=f"faq:{i}")] for i, (q, _) in enumerate(FAQ)]
        rows.append([Btn("⬅️ К помощи", callback_data="help")])
        await show(update, context, "💬 <b>Частые вопросы</b>\nВыберите вопрос:", rows, user=user)
        return
    q, answer = FAQ[idx]
    await show(update, context, f"💬 <b>{esc(q)}</b>\n\n{answer}",
               [[Btn("⬅️ К вопросам", callback_data="faq")]], user=user)


# --- Пожелания и замечания -----------------------------------------------------------
WISH_MAX = 2000
WISH_SHOWN = 50


def is_owner(uid: int) -> bool:
    """Владелец бота — тот, чей номер записан в .env как OWNER_ID (узнать номер можно командой /id)."""
    return str(uid) == load_env("OWNER_ID")


async def ask_wish(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = db.get_user(update.effective_user.id)
    await show(update, context, "💬 <b>Пожелания и замечания</b>\nНапишите одним сообщением, что вам не нравится "
                                "или что стоит доработать. Я сохраню это для разработчика.",
               [[Btn("⬅️ В меню", callback_data="menu")]], user=user, await_input={"kind": "wish"})


async def save_wish(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    user = db.get_user(update.effective_user.id)
    db.add_feedback(update.effective_user.id, text[:WISH_MAX])
    await show(update, context, "🙏 Спасибо! Сообщение сохранено, разработчик его прочитает.",
               [[Btn("🏠 В меню", callback_data="menu")]], user=user, edit=False)


def est_ref_label(ref: str) -> str:
    """«e5» → «смета №5», «d8» → «смета №8 (не сохранена)»."""
    if ref[:1] == "e" and ref[1:].isdigit():
        return f"смета №{ref[1:]}"
    if ref[:1] == "d" and ref[1:].isdigit():
        return f"смета №{ref[1:]} (не сохранена)"
    return ""


def feedback_line(r) -> str:
    mark = " · <b>ошибка</b>" if r["kind"] == "bug" else ""
    ref = est_ref_label(r["est_ref"] or "")
    return (f"<b>№{r['id']}</b> · {r['created']} UTC · {esc(db.user_label(r['user_id']))}{mark}"
            + (f" · {ref}" if ref else "") + f"\n{esc(r['text'])}")


async def send_feedback_list(update: Update, rows, head: str) -> None:
    parts = [head] + [feedback_line(r) for r in rows]
    for chunk in split_text("\n\n".join(parts)):
        await update.effective_chat.send_message(chunk, parse_mode=ParseMode.HTML)


async def show_wishes(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Команда владельца «пожелания»: накопленное, новые сверху (время по UTC)."""
    rows, total = db.list_feedback(WISH_SHOWN)
    if not rows:
        await update.effective_chat.send_message("Пока нет ни одного пожелания.")
        return
    head = f"💬 <b>Пожелания</b>: всего {total}" + (f", показаны последние {len(rows)}" if total > len(rows) else "")
    await send_feedback_list(update, rows, head)


async def show_new_wishes(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Команда владельца «новые пожелания»: то, что ещё не показывали, по дате (новые сверху). После показа
    записи считаются просмотренными, в следующий раз придут только более свежие."""
    rows = db.list_new_feedback()
    if not rows:
        await update.effective_chat.send_message("Новых пожеланий и ошибок нет.")
        return
    bugs = sum(1 for r in rows if r["kind"] == "bug")
    await send_feedback_list(update, rows, f"🆕 <b>Новые</b>: {len(rows)} (из них ошибок: {bugs})")
    db.mark_feedback_seen([r["id"] for r in rows])


async def cmd_wishes(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if is_owner(update.effective_user.id):
        await show_wishes(update, context)


async def cmd_newwishes(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if is_owner(update.effective_user.id):
        await show_new_wishes(update, context)


# Что владелец может менять командой «настройка имя значение» (всё остальное — только в коде)
SETTING_NAMES = {"free_limit": "лимит бесплатных мест", "trial_days": "дней бесплатного теста",
                 "invite_bonus_days": "дней в подарок за друга", "channel_username": "имя канала (@имя)",
                 "channel_link": "ссылка на канал", "bot_name": "название бота в политике",
                 "dim_ask_bath": "ванная/туалет: переспрос от (м)", "dim_strict_bath": "ванная/туалет: строгий переспрос от (м)",
                 "dim_ask_room": "другие комнаты: переспрос от (м)", "dim_ask_height": "высота потолка: переспрос от (м)",
                 "dim_ask_own": "своё помещение, длина/ширина: переспрос от (м)",
                 "dim_ask_own_height": "своё помещение, высота: переспрос от (м)"}
DIM_SETTINGS = ("dim_ask_bath", "dim_strict_bath", "dim_ask_room", "dim_ask_height", "dim_ask_own", "dim_ask_own_height")


async def owner_settings(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    """«настройки» — показать; «настройка free_limit 2» — поменять; «настройка channel_username -» — очистить."""
    parts = text.split(None, 2)
    if len(parts) >= 3 and parts[0].lower().lstrip("/") == "настройка":
        key, value = parts[1], parts[2].strip()
        if key not in SETTING_NAMES:
            await update.effective_chat.send_message("Такой настройки нет. Доступны: " + ", ".join(SETTING_NAMES))
            return
        value = "" if value == "-" else value
        if key in ("free_limit", "trial_days", "invite_bonus_days") and not (value.isdigit() and int(value) >= 0):
            await update.effective_chat.send_message("Здесь нужно целое число, не меньше нуля.")
            return
        if key in DIM_SETTINGS:
            try:
                ok = float(value.replace(",", ".")) > 0
            except ValueError:
                ok = False
            if not ok:
                await update.effective_chat.send_message("Здесь нужно число больше нуля (в метрах), например 3 или 2,5.")
                return
        db.set_setting(key, value)
    lines = [f"{k} — {v}: {db.get_setting(k) or '(пусто)'}" for k, v in SETTING_NAMES.items()]
    await update.effective_chat.send_message(
        "⚙️ Настройки бота\n" + "\n".join(lines) +
        f"\nЗанято мест: {db.joined_count()} из {db.free_limit()}\n\nМеняется так: настройка free_limit 100")


async def cmd_id(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_chat.send_message(f"Ваш номер в Телеграме: {update.effective_user.id}")


INVITE_TEXT = ("Считаю смету на отделку в этом боте. Попробуйте: первый месяц бесплатно, пока идёт набор "
               "первой сотни.")


def invite_link(context: ContextTypes.DEFAULT_TYPE, uid: int) -> str:
    return f"https://t.me/{context.bot.username}?start=r_{db.ensure_ref_code(uid)}"


async def show_invite(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """«Пригласить друга»: личная ссылка, без рейтинга. Бонус начисляется, когда друг посчитал смету (см. db.mark_calculated)."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    link = invite_link(context, uid)
    bonus = db.bonus_days()
    st = db.invite_stats(uid)
    text = (f"🤝 <b>Пригласить друга</b>\n\n"
            f"Пригласите друга: он получит бесплатный месяц, а вы {bonus} {days_word(bonus)} в подарок к своему сроку. "
            "Бонус начисляется, когда друг посчитал хотя бы одну смету. Действует, пока набирается первая сотня.\n\n"
            f"Ваша ссылка:\n{esc(link)}\n\n"
            f"Зашли по вашей ссылке: {st['entered']}\nПосчитали смету: {st['counted']}")
    rows = []
    if db.seat_open():
        share_url = f"https://t.me/share/url?url={quote(link)}&text={quote(INVITE_TEXT)}"
        rows.append([Btn("📨 Поделиться ссылкой", url=share_url)])
    else:
        text += "\n\nМеста в бесплатном тесте закончились: новые друзья попадут в список ожидания."
    rows.append([Btn("⬅️ В меню", callback_data="menu")])
    await show(update, context, text, rows, user=user)


async def notify_bonus(context: ContextTypes.DEFAULT_TYPE, award) -> None:
    """Сообщаем пригласившему, что ему добавили дни (если Телеграм не даёт написать — не страшно)."""
    if not award:
        return
    inviter, days = award
    row = db.get_user(inviter)
    if is_owner(inviter):   # у владельца срока нет — про дни и дату не пишем
        text = "🎁 Ваш друг посчитал смету."
    else:
        text = (f"🎁 Ваш друг посчитал смету. Вам добавлено {days} {days_word(days)} к бесплатному сроку, "
                f"теперь он до {date_ru(row['expires'])}.")
    try:
        await context.bot.send_message(inviter, text)
    except Exception:
        log.info("Не удалось сообщить пригласившему о бонусе")


# --- Кнопки под сметой: «Верно» и «Есть ошибка» ---------------------------------------------
def est_ref_of(est: dict) -> str:
    """Номер сметы для отметок: сохранённая — e<номер>, ещё не сохранённая — d<номер черновика>."""
    return f"e{est['edit_id']}" if est.get("edit_id") else f"d{est['id']}"


def feedback_row(ref: str) -> list:
    return [Btn("✅ Верно", callback_data=f"fb:ok:{ref}"), Btn("⚠️ Есть ошибка", callback_data=f"fb:err:{ref}")]


async def estimate_shown(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Человек увидел посчитанную смету: впервые — отмечаем (для бонуса пригласившему)."""
    await notify_bonus(context, db.mark_calculated(update.effective_user.id))


def ref_back(ref: str) -> str:
    """Кнопка «назад к смете»: незаконченная открывается как черновик, сохранённая — из объекта."""
    return f"dr:{ref[1:]}" if ref[:1] == "d" else f"est:{ref[1:]}"


async def cb_feedback(update: Update, context: ContextTypes.DEFAULT_TYPE, p: list) -> None:
    uid = update.effective_user.id
    q = update.callback_query
    if len(p) < 3 or p[1] not in ("ok", "err") or not est_ref_label(p[2]):
        await q.answer()
        return
    ref = p[2]
    if p[1] == "ok":
        fresh = db.add_vote(uid, ref, "ok")   # скрытая статистика, людям не показывается
        await q.answer("Спасибо!" if fresh else "Вы уже отметили эту смету.")
        await drop_feedback_row(update, context)
        return
    await q.answer()
    user = db.get_user(uid)
    await show(update, context, f"⚠️ <b>Есть ошибка</b> ({est_ref_label(ref)})\nОпишите одним сообщением, что не так: "
                                "что посчитано неверно или чего не хватает. Я сохраню это для разработчика.",
               [[Btn("⬅️ Отмена", callback_data=ref_back(ref))]], user=user, await_input={"kind": "bug", "ref": ref})


async def drop_feedback_row(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """После «Верно» убираем ряд с кнопками и на экране, и в запомненном экране (чтобы не вернулся при повторе)."""
    q = update.callback_query
    last = context.user_data.get("last")
    if last:
        last["rows"] = [r for r in last["rows"] if not any((cb or "").startswith("fb:") for _, cb, _ in r)]
    try:
        kb = [r for r in q.message.reply_markup.inline_keyboard
              if not any((b.callback_data or "").startswith("fb:") for b in r)]
        await q.edit_message_reply_markup(InlineKeyboardMarkup(kb))
    except Exception:
        pass


async def save_bug(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, ref: str) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    db.add_vote(uid, ref, "bug")
    db.add_feedback(uid, text[:WISH_MAX], kind="bug", est_ref=ref)
    context.user_data["await"] = None
    await show(update, context, "🙏 Спасибо! Ошибка записана, разработчик её прочитает.",
               [[Btn("⬅️ К смете", callback_data=ref_back(ref)), Btn("🏠 В меню", callback_data="menu")]],
               user=user, edit=False)


# =============================================================================
# Мои цены
# =============================================================================
PRICE_PAGE = 10        # услуг на одной странице раздела «Мои цены»
SEC_LIST_MAX = 60      # разделов в списке «Мои цены» (кнопок в сообщении Телеграма не больше ста)


def catalog_group_entries(uid: int, idx: int) -> tuple:
    """Раздел готового прайса: (название, [(ключ, название, единица, цена)])."""
    prices = db.get_prices(uid)
    group = catalog.GROUPS[idx]
    return group, [(k, it["title"], it["unit"], prices.get(k, 0)) for k, it in catalog.ITEM_BY_KEY.items()
                   if it["group"] == group and k not in catalog.HIDDEN_DUPLICATES]


def section_entries(uid: int, sid: int) -> list:
    """Услуги своего раздела мастера: [(ключ c<номер>, название, единица, цена)]."""
    return [(f"c{c['id']}", c["title"], c["unit"], c["price"]) for c in db.list_section_items(uid, sid)]


async def show_price_groups(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    secs = db.list_sections(uid)
    counts = [(i, g, len(catalog_group_entries(uid, i)[1])) for i, g in enumerate(catalog.GROUPS)]
    own = sum(s["n"] for s in secs)
    total = sum(n for _, _, n in counts) + own
    # наверху: общее число услуг и, если есть группы (разделы), сколько в каждой
    by_group = [f"• {esc(g)} — {n}" for _i, g, n in counts if n] + [f"• 🧰 {esc(s['name'])} — {s['n']}" for s in secs[:SEC_LIST_MAX]]
    text = (f"💰 <b>Мои цены</b>\nВсего услуг: <b>{total}</b>\n"
            + ("\n".join(by_group) + "\n" if by_group else "")
            + "\nВыберите раздел, чтобы поменять цены. Число рядом с названием — сколько в нём услуг.\n"
            f"Минимальная сумма сметы (выезд): <b>{money(user, user['min_total'])}</b>")
    if own:
        text += (f"\n\n🧰 — ваши услуги (всего {own}), разложенные по разделам. Раздел можно открыть и соединить "
                 "с другим или разделить на два.")
    rows = [[Btn(f"{g} · {n}", callback_data=f"price:g:{i}")] for i, g, n in counts]
    rows += [[Btn(f"🧰 {s['name']} · {s['n']}", callback_data=f"price:s:{s['id']}")] for s in secs[:SEC_LIST_MAX]]
    rows.append([Btn("📥 Загрузить прайс файлом", callback_data="price:file")])
    rows.append([Btn("💶 Минимальный выезд", callback_data="price:min")])
    rows.append([Btn("⬅️ В меню", callback_data="menu")])
    await show(update, context, text, rows, user=user)


def pager_row(base: str, pg: int, pages: int) -> list:
    return [Btn("⏮", callback_data=f"{base}:0"), Btn("◀️", callback_data=f"{base}:{max(pg - 1, 0)}"),
            Btn(f"{pg + 1} / {pages}", callback_data=f"{base}:{pg}"),
            Btn("▶️", callback_data=f"{base}:{min(pg + 1, pages - 1)}"),
            Btn("⏭", callback_data=f"{base}:{pages - 1}")]


def number_rows(buttons: list, per_row: int = 5) -> list:
    return [buttons[i:i + per_row] for i in range(0, len(buttons), per_row)]


def hint_rows(text: str, limit: int = 3) -> list:
    """Кнопки «❓ Что это: слово» для непонятных слов в тексте (названия услуг, смета). Нажатие показывает короткое
    объяснение всплывающим окном, экран и шаг не меняются. Слов-подсказок немного (hints.HINTS), лишних кнопок нет."""
    return [[Btn(f"❓ Что это: {word}", callback_data=f"hint:{code}")] for code, word in hints.find(text, limit)]


def cut_title(title: str, n: int) -> str:
    """Название услуги для строки списка на экране: чем длиннее список, тем короче строки (в сообщение Телеграма
    помещается 4096 знаков). Режем до экранирования, чтобы не разорвать «&amp;»."""
    room = 80 if n <= 20 else 50 if n <= 40 else 32
    return title if len(title) <= room else title[:room - 1] + "…"


async def show_price_page(update: Update, context: ContextTypes.DEFAULT_TYPE, kind: str, ident: int,
                          pg: int = 0, note: str = "") -> None:
    """Раздел «Мои цены»: услуги списком текстом (названия выровнены по левому краю), под ним кнопки с номерами.
    kind 'g' — раздел готового прайса, 's' — свой раздел мастера (его можно соединить с другим или разделить)."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    if kind == "g":
        if not 0 <= ident < len(catalog.GROUPS):
            await show_price_groups(update, context)
            return
        name, entries = catalog_group_entries(uid, ident)
    else:
        name = db.section_name(uid, ident)
        entries = section_entries(uid, ident) if name is not None else []
        if not entries:   # раздела уже нет (например, соединили) — к списку
            await show_price_groups(update, context)
            return
    base = f"price:{kind}:{ident}"
    pages = max(1, -(-len(entries) // PRICE_PAGE))
    pg = min(max(pg, 0), pages - 1)
    context.user_data["pv"] = [kind, ident, pg]   # куда вернуться после правки цены
    page = entries[pg * PRICE_PAGE:(pg + 1) * PRICE_PAGE]
    lines, unset = [], False
    for n, (key, title, unit, price) in enumerate(page, pg * PRICE_PAGE + 1):
        if price <= 0:
            unset = True
            lines.append(f"{n}. ⚠️ {esc(title)} — укажите свою цену")
        else:
            lines.append(f"{n}. {esc(title)} — {fnum(price)}/{esc(unit)}")
    text = (f"💰 <b>{esc(name)}</b> · услуг: {len(entries)}" + (f" · стр. {pg + 1} из {pages}" if pages > 1 else "")
            + f"\nНажмите номер услуги, чтобы изменить цену (в валюте: {catalog.CURRENCIES[user['currency']]['name']})."
            + "\n\n" + "\n".join(lines))
    if unset:
        text += "\n\n⚠️ Работы без цены в смету не входят, пока вы не укажете цену."
    rows = number_rows([Btn(str(n), callback_data=f"price:e:{key}")
                        for n, (key, *_r) in enumerate(page, pg * PRICE_PAGE + 1)])
    rows += hint_rows("\n".join(t for _k, t, *_r in page))
    if pages > 1:
        rows.append(pager_row(base, pg, pages))
    if kind == "s":
        rows.append([Btn("🔗 Соединить", callback_data=f"price:sm:{ident}"),
                     Btn("✂️ Разделить", callback_data=f"price:sp:{ident}")])
    rows.append([Btn("⬅️ К разделам", callback_data="price:list")])
    await show(update, context, note + text, rows, user=user)


async def show_price_group(update: Update, context: ContextTypes.DEFAULT_TYPE, idx: int, pg: int = 0) -> None:
    """Раздел готового прайса (номер в catalog.GROUPS). Старые кнопки «Мои работы» ведут к списку разделов."""
    await show_price_page(update, context, "g", idx, pg)


def price_back(ud: dict, key: str, uid: int) -> str:
    """Кнопка «Назад» с экрана правки цены: туда же, откуда пришли (раздел и страница)."""
    cid = custom_id(key)
    if cid is not None:
        item = db.get_custom_item(uid, cid)
        sid = (item["section_id"] or 0) if item else 0
        kind, ident = "s", sid
    else:
        kind, ident = "g", catalog.GROUPS.index(catalog.ITEM_BY_KEY[key]["group"])
    pv = ud.get("pv") or []
    pg = pv[2] if len(pv) == 3 and pv[0] == kind and pv[1] == ident else 0
    return f"price:{kind}:{ident}:{pg}"


async def reopen_price_view(update: Update, context: ContextTypes.DEFAULT_TYPE, key: str, note: str = "") -> None:
    """После правки цены: снова показать раздел, где эта услуга лежит (на той же странице)."""
    p = price_back(context.user_data, key, update.effective_user.id).split(":")
    await show_price_page(update, context, p[1], int(p[2]), int(p[3]), note)


async def show_merge_pick(update: Update, context: ContextTypes.DEFAULT_TYPE, sid: int) -> None:
    """«Соединить»: с каким разделом? Все услуги этого раздела перейдут в выбранный."""
    uid = update.effective_user.id
    name = db.section_name(uid, sid)
    mine = next((s for s in db.list_sections(uid) if s["id"] == sid), None)
    if name is None or not mine:
        await show_price_groups(update, context)
        return
    others = [s for s in db.list_sections(uid) if s["id"] not in (sid, 0)]
    if not others:
        await show(update, context, f"🔗 <b>Соединить «{esc(name)}»</b>\nДругих групп пока нет — соединять не с чем.",
                   [[Btn("⬅️ Назад", callback_data=f"price:s:{sid}")]], user=db.get_user(uid))
        return
    rows = [[Btn(f"{s['name']} · {s['n']}", callback_data=f"price:smt:{sid}:{s['id']}")] for s in others[:SEC_LIST_MAX]]
    rows.append([Btn("⬅️ Назад", callback_data=f"price:s:{sid}")])
    await show(update, context, f"🔗 <b>Соединить «{esc(name)}»</b> (услуг: {mine['n']})\nС какой группой?",
               rows, user=db.get_user(uid))


async def show_split(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    """«Разделить»: отметьте услуги, которые уйдут в новый раздел."""
    uid = update.effective_user.id
    sp = context.user_data.get("split")
    name = db.section_name(uid, sp["sid"]) if sp else None
    entries = section_entries(uid, sp["sid"]) if name is not None else []
    if not entries:
        context.user_data["split"] = None
        await show_price_groups(update, context)
        return
    ids = {k for k, *_r in entries}
    sp["sel"] = [k for k in sp["sel"] if k in ids]
    pages = max(1, -(-len(entries) // PRICE_PAGE))
    sp["pg"] = pg = min(max(sp.get("pg", 0), 0), pages - 1)
    page = entries[pg * PRICE_PAGE:(pg + 1) * PRICE_PAGE]
    lines, btns = [], []
    for n, (key, title, unit, price) in enumerate(page, pg * PRICE_PAGE + 1):
        on = key in sp["sel"]
        lines.append(f"{'✅' if on else '⬜'} {n}. {esc(title)} — {fnum(price)}/{esc(unit)}" if price > 0
                     else f"{'✅' if on else '⬜'} {n}. {esc(title)} — без цены")
        btns.append(Btn(f"{'✅' if on else ''}{n}", callback_data=f"price:spt:{key}"))
    text = (f"✂️ <b>Разделить «{esc(name)}»</b> · услуг: {len(entries)}" + (f" · стр. {pg + 1} из {pages}" if pages > 1 else "")
            + "\nОтметьте услуги, которые уйдут в другую группу (новую или уже существующую): нажмите номер "
              "(ещё раз — снять отметку).\n"
            f"Выбрано: <b>{len(sp['sel'])}</b>\n\n" + "\n".join(lines))
    rows = number_rows(btns)
    if pages > 1:
        rows.append(pager_row("price:spp", pg, pages))
    rows.append([Btn("☑️ Все на странице", callback_data="price:spall"), Btn("🧹 Снять отметки", callback_data="price:spnone")])
    if sp["sel"]:
        rows.append([Btn(f"➡️ Дальше: куда перенести ({len(sp['sel'])})", callback_data="price:spgo")])
    rows.append([Btn("⬅️ Отмена", callback_data=f"price:s:{sp['sid']}")])
    await show(update, context, note + text, rows, user=db.get_user(uid))


async def price_section_action(update: Update, context: ContextTypes.DEFAULT_TYPE, p: list) -> None:
    """Кнопки раздела мастера: страницы, «Соединить», «Разделить». p = ['price', команда, ...]."""
    uid = update.effective_user.id
    ud = context.user_data
    sub = p[1]
    if sub == "s":
        await show_price_page(update, context, "s", int(p[2]), int(p[3]) if len(p) > 3 else 0)
    elif sub == "sm":
        await show_merge_pick(update, context, int(p[2]))
    elif sub == "smt":   # выбрали раздел: просим подтвердить
        src, dst = int(p[2]), int(p[3])
        a, b = db.section_name(uid, src), db.section_name(uid, dst)
        n = len(db.list_section_items(uid, src))
        if a is None or b is None or not n or src == dst:
            await show_price_groups(update, context)
            return
        await show(update, context, f"🔗 Перенести все услуги ({n}) из «{esc(a)}» в «{esc(b)}»?\n"
                                    f"Раздел «{esc(a)}» после этого исчезнет.",
                   [[Btn("✅ Да, соединить", callback_data=f"price:smok:{src}:{dst}"),
                     Btn("Нет", callback_data=f"price:s:{src}")]], user=db.get_user(uid))
    elif sub == "smok":
        src, dst = int(p[2]), int(p[3])
        a, b = db.section_name(uid, src), db.section_name(uid, dst)
        if a is None or b is None:
            await show_price_groups(update, context)
            return
        n = db.merge_sections(uid, src, dst)
        await show_price_page(update, context, "s", dst, 0, f"✅ Соединил: {n} услуг из «{esc(a)}» теперь в «{esc(b)}».\n\n")
    elif sub == "sp":    # начало «Разделить»
        sid = int(p[2])
        ud["split"] = {"sid": sid, "sel": [], "pg": 0}
        await show_split(update, context)
    elif sub == "spto":   # «Разделить»: выбранные услуги уходят в уже существующую группу
        sp = ud.get("split")
        dst = int(p[2])
        src_name, dst_name = (db.section_name(uid, sp["sid"]), db.section_name(uid, dst)) if sp else (None, None)
        if not sp or not sp["sel"] or src_name is None or dst_name is None or dst == sp["sid"]:
            await q_gone(update, context)
            return
        n = db.move_items(uid, [int(k[1:]) for k in sp["sel"]], dst)
        ud["split"] = None
        await show_price_page(update, context, "s", dst, 0, f"✅ {n} услуг перешли из «{esc(src_name)}» в «{esc(dst_name)}».\n\n")
    elif sub in ("spt", "spp", "spall", "spnone", "spgo"):
        sp = ud.get("split")
        if not sp:
            await q_gone(update, context)
            return
        if sub == "spt":
            key = p[2]
            sp["sel"].remove(key) if key in sp["sel"] else sp["sel"].append(key)
        elif sub == "spp":
            sp["pg"] = int(p[2])
        elif sub == "spall":
            page = section_entries(uid, sp["sid"])[sp["pg"] * PRICE_PAGE:(sp["pg"] + 1) * PRICE_PAGE]
            for key, *_r in page:
                if key not in sp["sel"]:
                    sp["sel"].append(key)
        elif sub == "spnone":
            sp["sel"] = []
        if sub == "spgo":
            if not sp["sel"]:
                await show_split(update, context, "⚠️ Сначала отметьте хотя бы одну услугу.\n\n")
                return
            others = [s for s in db.list_sections(uid) if s["id"] not in (sp["sid"], 0)][:SEC_LIST_MAX]
            rows = [[Btn(f"{s['name']} · {s['n']}", callback_data=f"price:spto:{s['id']}")] for s in others]
            rows.append([Btn("⬅️ Назад к выбору", callback_data="price:spp:" + str(sp["pg"]))])
            await show(update, context, f"✂️ Выбрано услуг: {len(sp['sel'])}.\nКуда перенести? "
                                        + ("Нажмите существующую группу или напишите название новой" if others else
                                           "Напишите название новой группы")
                                        + f" (до {sections.SECTION_MAX} знаков).",
                       rows, user=db.get_user(uid), await_input={"kind": "secname"})
        else:
            await show_split(update, context)


async def q_gone(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Кнопка из старого сообщения: бот уже не помнит, что выбирали (например, после перезапуска)."""
    await update.effective_chat.send_message("Это уже неактуально, начните заново.")
    await show_price_groups(update, context)


async def save_section_name(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str) -> None:
    """Название нового раздела от мастера: выбранные услуги уходят в него."""
    uid = update.effective_user.id
    sp = context.user_data.get("split")
    if not sp or not sp["sel"]:
        context.user_data["await"] = None
        await q_gone(update, context)
        return
    name = sections.clean_name(text)
    if not name:
        return
    dst = db.section_id_by_name(uid, name)
    if dst is not None:   # такая группа уже есть: услуги уходят в неё
        if dst == sp["sid"]:
            await show(update, context, f"⚠️ Эти услуги и так лежат в «{esc(db.section_name(uid, dst))}». Назовите другую группу.",
                       [[Btn("⬅️ Назад к выбору", callback_data="price:spp:" + str(sp["pg"]))]],
                       user=db.get_user(uid), await_input={"kind": "secname"}, edit=False)
            return
        src_name, dst_name = db.section_name(uid, sp["sid"]), db.section_name(uid, dst)
        n = db.move_items(uid, [int(k[1:]) for k in sp["sel"]], dst)
        context.user_data["split"] = None
        await show_price_page(update, context, "s", dst, 0,
                              f"✅ {n} услуг перешли из «{esc(src_name or '')}» в уже существующую группу «{esc(dst_name or '')}».\n\n")
        return
    src_name = db.section_name(uid, sp["sid"])
    sid, n = db.split_section(uid, [int(k[1:]) for k in sp["sel"]], name)
    context.user_data["split"] = None
    await show_price_page(update, context, "s", sid, 0,
                          f"✅ Создал раздел «{esc(name)}»: {n} услуг перешли из «{esc(src_name or '')}».\n\n")


# =============================================================================
# Открытые сметы (черновики)
# =============================================================================
def estimate_title(est: dict) -> str:
    base = "Ванная + туалет" if len(est["rooms"]) > 1 else "Ванная"
    return f"{base} · {calc.STAGE_TITLES[est['stage']]}"


def draft_title(est: dict) -> str:
    """Название открытой сметы для меню и списка."""
    if est.get("type") == "extra":
        title = "Допработа" + (f": {est['name']}" if est.get("name") else "")
    elif est.get("type") == "croom":
        title = est["room_name"] if (est.get("pm") or est.get("room") == "calc") else f"{est['room_name']} · конструктор"
        if est.get("kind") == "extra":
            title = "Допработа · " + title
    else:
        title = estimate_title(est) if est.get("stage") else "Ванная"
        if est.get("kind") == "extra":
            title = "Допработа · " + title
    if est.get("edit_id"):
        title = "Правка: " + title
    return title


def est_step_label(est: dict) -> str:
    """Коротко, на каком шаге остановились: «плитка», «этап», «итог»…"""
    if est.get("type") == "extra":
        return "добавление строк"
    if est.get("type") == "croom":
        if est.get("pm") and not est.get("pm_go") and not est.get("mz_done"):
            return "темы и работы"
        return "добавление работ" if est.get("mz_done") or est.get("lines") else "замер"
    if not est.get("sep"):
        return "тип санузла"
    if not est.get("stage"):
        return "этап"
    step = expected_step(est) if est["rooms"] else None
    if step is None:
        return "правки" if est.get("editing") else "итог"
    return flow.SHORT.get(step.key, step.key).lower()


def new_draft(update: Update, context: ContextTypes.DEFAULT_TYPE, dtype: str = "room",
              obj: Optional[int] = None, kind: str = "main", track: bool = True) -> dict:
    """Создаёт новую открытую смету и делает её текущей (остальные не трогаются).
    track=False — это не новая смета, а открытая для правки сохранённая (в тихий счётчик не идёт)."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    did = db.create_draft(uid, dtype, obj)
    if track:
        db.log_event("est_started")
    est = {"id": did, "type": dtype, "kind": kind, "obj": obj, "cur": user["currency"],
           "sep": None, "stage": None, "rooms": [], "ri": 0, "edit_id": None, "edit_key": None,
           "editing": False, "multi_key": None, "multi": [], "manual": [], "price_over": {}, "tmp": {}}
    context.user_data["est"] = est
    context.user_data["draft_id"] = did
    return est


async def activate(update: Update, context: ContextTypes.DEFAULT_TYPE, did: int) -> Optional[dict]:
    """Делает черновик did текущим. Если такой уже закрыт — сообщает об этом (ничего не сбрасывая)."""
    ud = context.user_data
    est = ud.get("est")
    if est and est.get("id") == did and ud.get("draft_id") == did:
        return est
    uid = update.effective_user.id
    flush(uid, ud)  # сначала сохраняем ту смету, что была текущей
    row = db.get_draft(uid, did)
    if not row:
        q = update.callback_query
        if q:
            await q.answer("Эта смета уже закрыта.", show_alert=True)
        await send_menu(update, context)
        return None
    est = json.loads(row["state"])
    est["id"] = did
    ud["est"], ud["draft_id"] = est, did
    ud["_saved_state"] = (did, row["state"])
    return est


def drop_draft(update: Update, context: ContextTypes.DEFAULT_TYPE, did: int) -> None:
    """Удаляет черновик (сохранили смету или человек сбросил её сам)."""
    uid = update.effective_user.id
    db.delete_draft(uid, did)
    ud = context.user_data
    if ud.get("draft_id") == did:
        ud.pop("est", None)
        ud["draft_id"] = None


async def resume_est(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Возвращает человека на тот же шаг, где он остановился."""
    est = context.user_data.get("est")
    if not est:
        await send_menu(update, context)
    elif est.get("type") in ("extra", "croom"):
        await show_extra(update, context)
    elif not est["sep"]:
        await ask_sep(update, context)
    elif not est["stage"]:
        await ask_stage(update, context)
    else:
        await advance(update, context)


async def show_drafts(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    flush(uid, context.user_data)
    drafts = db.list_drafts(uid)
    text = "📋 <b>Мои открытые сметы</b>\nКаждая смета помнит свой шаг. Нажмите, чтобы продолжить."
    if not drafts:
        text += "\n\nОткрытых смет нет."
    rows = []
    for d in drafts:
        obj = db.get_object(uid, d["object_id"]) if d["object_id"] else None
        label = f"▶️ {d['title']} · шаг: {d['step']}" + (f" · {obj['name']}" if obj else "")
        rows.append([Btn(label[:60], callback_data=f"dr:{d['id']}"), Btn("🗑", callback_data=f"drdel:{d['id']}")])
    rows.append([Btn("🆕 Новая смета", callback_data="menu")])
    rows.append([Btn("⬅️ В меню", callback_data="menu")])
    await show(update, context, text, rows, user=user)


# =============================================================================
# Мастер расчёта комнаты
# =============================================================================
def ctx_of(est: dict, room: dict) -> dict:
    return {"stage": est["stage"], "kind": room["kind"], "cur": est.get("cur", "rub")}


def room_heading(est: dict, room: dict) -> str:
    if len(est["rooms"]) < 2:
        return ""
    icon = "🚽" if room["kind"] == "wc" else "🛁"
    return f"{icon} <b>{calc.ROOM_TITLES[room['kind']]}</b>\n"


def nav_row(d: int) -> list:
    return [Btn("⬅️ Назад", callback_data=f"w:{d}:back"), Btn("✖️ Отмена", callback_data=f"w:{d}:cancel")]


async def start_room(update: Update, context: ContextTypes.DEFAULT_TYPE, code: str) -> None:
    """Выбрана комната. Ванная и туалет — готовые вопросы, остальные — конструктор."""
    ud = context.user_data
    if code not in READY_ROOMS:
        await show_room_intro(update, context, code)
        return
    obj, kind = ud.pop("cur_obj", None), ud.pop("cur_kind", None) or "main"
    new_draft(update, context, "room", obj, kind)
    await ask_sep(update, context)


async def show_room_intro(update: Update, context: ContextTypes.DEFAULT_TYPE, code: str) -> None:
    """Комната без готовых вопросов: смета не создаётся, пока человек не нажмёт кнопку конструктора."""
    await show(update, context,
               f"{esc(ROOM_TITLE[code])} пока без готовых вопросов, зато здесь вы сами хозяин сметы: "
               "выбирайте работы, ставьте свои цены, а мы всё посчитаем.",
               [[Btn("Собрать смету в конструкторе", callback_data=f"crm:{code}")],
                [Btn("⬅️ Назад", callback_data="menu")]])


async def start_prices(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Раздел «Прайсы»: темы услуг → галочки → замер (или без него) → смета. Это тот же конструктор, что у комнат."""
    ud = context.user_data
    obj, kind = ud.pop("cur_obj", None), ud.pop("cur_kind", None)
    est = ud.get("est")
    if (est and est.get("type") == "croom" and est.get("pm") and not est["lines"] and not est.get("pm_go")
            and not est.get("edit_id") and ud.get("draft_id") == est["id"]):
        if obj is not None:
            est["obj"], est["kind"] = obj, kind or "main"
    else:
        est = new_draft(update, context, "croom", obj, kind or "main")
        est.update(room="price", room_name="Смета по прайсу", icon="📚", lines=[], name="",
                   mz=new_mz(), mz_done=False, flt={}, pm=True, pm_go=False)
    await show_extra(update, context)


async def start_croom(update: Update, context: ContextTypes.DEFAULT_TYPE, code: str) -> None:
    """Открывает конструктор комнаты. Повторное нажатие кнопки не плодит пустые сметы."""
    ud = context.user_data
    obj, kind = ud.pop("cur_obj", None), ud.pop("cur_kind", None)
    est = ud.get("est")
    if (est and est.get("type") == "croom" and est.get("room") == code and not est["lines"]
            and not est.get("edit_id") and ud.get("draft_id") == est["id"]):
        if obj is not None:  # пустая смета этой комнаты уже открыта: переносим её в выбранный объект
            est["obj"], est["kind"] = obj, kind or "main"
    else:
        est = new_draft(update, context, "croom", obj, kind or "main")
        est.update(room=code, room_name=ROOM_TITLE[code], icon=ROOM_ICON[code], lines=[], name="",
                   mz=new_mz(), mz_done=False, flt={})
    await show_extra(update, context)   # сначала замер одним экраном, потом общий список работ


async def ask_sep(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    est = context.user_data["est"]
    d = est["id"]
    await show(update, context, "🛁 <b>Ванная</b>\nСанузел совмещённый или раздельный?\n"
                                "<i>Раздельный: после ванной спрошу то же самое про туалет, итог сложу.</i>",
               [[Btn("🛁🚽 Совмещённый", callback_data=f"sep:{d}:one")],
                [Btn("🛁 | 🚽 Раздельный", callback_data=f"sep:{d}:two")],
                [Btn("✖️ Отмена", callback_data=f"w:{d}:cancel")]])


async def ask_stage(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    d = context.user_data["est"]["id"]
    await show(update, context, "🛠 Какой этап считаем?",
               [[Btn("🧱 Черновой", callback_data=f"stage:{d}:rough")],
                [Btn("✨ Чистовой", callback_data=f"stage:{d}:finish")],
                [Btn("🔁 Всё сразу", callback_data=f"stage:{d}:all")],
                [Btn("⬅️ Назад", callback_data=f"bk:{d}:sep"), Btn("✖️ Отмена", callback_data=f"w:{d}:cancel")]])


def make_rooms(sep: str) -> list:
    if sep == "one":
        return [{"kind": "bath_full", "a": {}, "hist": []}]
    return [{"kind": "bath_only", "a": {}, "hist": []}, {"kind": "wc", "a": {}, "hist": []}]


def expected_step(est: dict):
    """Вопрос, на который бот сейчас ждёт ответ."""
    room = est["rooms"][est["ri"]]
    c = ctx_of(est, room)
    if est.get("edit_key"):
        return flow.active_step(est["edit_key"], room["a"], c)
    return flow.next_step(room["a"], c)


def next_question(est: dict):
    """Следующий вопрос и заметка. Ответы, которые бот подставляет сам (остаток плитки), записываются тут же."""
    note = ""
    step = expected_step(est)
    while step is not None and step.auto and not est.get("edit_key"):
        room = est["rooms"][est["ri"]]
        value = step.auto(room["a"], ctx_of(est, room))
        if step.auto_note:
            note += step.auto_note(room["a"], ctx_of(est, room), value)
        room["a"][step.key] = round(value, 2) if isinstance(value, (int, float)) else value
        if step.key not in room["hist"]:
            room["hist"].append(step.key)
        step = expected_step(est)
    return step, note


async def advance(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Задаёт следующий вопрос; когда вопросы кончились — считает смету (или показывает экран правок)."""
    est = context.user_data["est"]
    step, note = next_question(est)
    if step is not None:
        await ask_step(update, context, step, note)
        return
    # в текущей комнате всё спрошено — переходим к следующей
    while est["ri"] + 1 < len(est["rooms"]):
        est["ri"] += 1
        step, more = next_question(est)
        if step is not None:
            await ask_step(update, context, step, note + more)
            return
    if est["editing"]:
        await show_edit_menu(update, context)
    else:
        await finish_estimate(update, context)


async def ask_step(update: Update, context: ContextTypes.DEFAULT_TYPE, step: flow.Step, note: str = "") -> None:
    est = context.user_data["est"]
    d = est["id"]
    room = est["rooms"][est["ri"]]
    a, c = room["a"], ctx_of(est, room)
    key = step.key
    text = room_heading(est, room) + note + flow.resolve(step.text, a, c)
    prev = a.get(key) if est.get("edit_key") == key else None
    rows: list = []
    await_input = None  # для вопросов с кнопками текст не ждём: на текст бот ответит подсказкой

    if step.kind == "yn":
        rows.append([Btn("✅ Да", callback_data=f"a:{d}:{key}:y"), Btn("❌ Нет", callback_data=f"a:{d}:{key}:n")])
    elif step.kind == "choice":
        for val, label in flow.resolve(step.options, a, c):
            rows.append([Btn(label, callback_data=f"a:{d}:{key}:{val}")])
    elif step.kind == "multi":
        if est.get("multi_key") != key:  # вход в вопрос: начинаем с прежних отметок или с отметок по умолчанию
            start = prev if prev is not None else flow.resolve(step.default, a, c)
            est["multi_key"], est["multi"] = key, list(start or [])
        for val, label in flow.resolve(step.options, a, c):
            mark = "✅" if val in est["multi"] else "⬜"
            rows.append([Btn(f"{mark} {label}", callback_data=f"m:{d}:{key}:{val}")])
        rows.append([Btn("✅ Готово", callback_data=f"md:{d}:{key}")])
    elif step.kind == "text":  # короткий текст (название своего люка)
        await_input = {"kind": "txt", "key": key, "d": d}
        text += "\n\n✍️ Напишите ответ текстом."
    else:  # num: ждём число текстом, плюс быстрые кнопки
        await_input = {"kind": "num", "key": key, "d": d}
        quick = flow.resolve(step.quick, a, c) or []
        if quick:
            rows.append([Btn(label, callback_data=f"a:{d}:{key}:{fnum_cb(val)}") for label, val in quick])
        text += "\n\n✍️ Напишите число в ответ (можно через запятую или точку)."

    if prev is not None and step.kind not in ("multi", "text"):
        rows.append([Btn(f"↩️ Оставить: {flow.answer_label(step, a, c)}", callback_data=f"a:{d}:{key}:{fnum_cb(prev)}")])
    for code, label in hints.button_labels(hints.find(flow.resolve(step.text, a, c))):   # «Что это?» к непонятным словам
        rows.append([Btn(label, callback_data=f"hint:{code}")])
    rows.append(nav_row(d))
    await show(update, context, text, rows, await_input=await_input)


def fnum_cb(val) -> str:
    """Значение для callback_data: числа без лишних нулей (1.0 -> '1'), остальное как есть."""
    return f"{val:g}" if isinstance(val, float) else str(val)


async def submit_answer(update: Update, context: ContextTypes.DEFAULT_TYPE, step: flow.Step, value) -> None:
    est = context.user_data["est"]
    room = est["rooms"][est["ri"]]
    changed = room["a"].get(step.key) != value
    room["a"][step.key] = value
    if step.key not in room["hist"]:
        room["hist"].append(step.key)
    if est.get("edit_key") and changed:  # поправили ответ: то, что от него зависит (типы плитки), надо ввести заново
        for dep in flow.RESET_ON_EDIT.get(step.key, []):
            room["a"].pop(dep, None)
            if dep in room["hist"]:
                room["hist"].remove(dep)
    est["edit_key"] = None
    est["multi_key"] = None
    await advance(update, context)


# --- Необычно большие размеры комнаты: не запрещаем, а переспрашиваем (пороги — в настройках dim_*) -----------
DIM_WORD = {"len": "длина", "wid": "ширина", "hei": "высота"}
BATH_WORD = {"bath_full": "ванная", "bath_only": "ванная", "wc": "туалет"}   # вид комнаты мастера → слово


def dim_level(field: str, value: float, bath_kind: Optional[str] = None, own: bool = False) -> str:
    """Насколько необычен размер: '' — обычный, 'ask' — переспросить «это верно?», 'strict' — переспросить построже
    (только длина и ширина ванной/туалета). Размер, равный порогу, уже считается большим."""
    if field == "hei":
        return "ask" if value >= db.float_setting("dim_ask_own_height" if own else "dim_ask_height") else ""
    if bath_kind:
        if value >= db.float_setting("dim_strict_bath"):
            return "strict"
        return "ask" if value >= db.float_setting("dim_ask_bath") else ""
    return "ask" if value >= db.float_setting("dim_ask_own" if own else "dim_ask_room") else ""


def dim_confirm_text(field: str, value: float, level: str, bath_kind: Optional[str] = None) -> str:
    text = f"❓ Вы ввели {fnum(value)} метров, это верно?\n<i>({DIM_WORD[field]})</i>"
    if level == "strict":
        what = "большой туалет" if bath_kind == "wc" else "большая ванная"
        text = f"⚠️ Это очень {what}, возможно, вы ошиблись.\n\n" + text
    return text


def parse_number(text: str):
    """'1,53' / '1.53 м' -> 1.53; при ошибке None."""
    t = text.strip().lower().replace(",", ".")
    for suffix in ("м²", "м2", "пог.м", "пм", "шт", "м", "m"):
        if t.endswith(suffix):
            t = t[: -len(suffix)].strip()
            break
    try:
        value = float(t)
    except ValueError:
        return None
    return value if value == value and abs(value) != float("inf") else None


async def show_dim_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """«Вы ввели N метров, это верно?» — для ванной и туалета (мастер вопросов)."""
    est = context.user_data["est"]
    room = est["rooms"][est["ri"]]
    pend = est["dim_pending"]
    d = est["id"]
    text = room_heading(est, room) + dim_confirm_text(pend["key"], pend["value"], pend["level"], room["kind"])
    await show(update, context, text,
               [[Btn("✅ Да, верно", callback_data=f"dm:{d}:yes"), Btn("✏️ Исправить", callback_data=f"dm:{d}:fix")]])


async def wizard_back(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    est = context.user_data["est"]
    if est.get("edit_key"):  # правка отдельного пункта — просто выходим на экран правок
        est["edit_key"] = None
        await show_edit_menu(update, context)
        return
    room = est["rooms"][est["ri"]]
    if not room["hist"]:
        if est["ri"] > 0:
            est["ri"] -= 1
            room = est["rooms"][est["ri"]]
        elif est["editing"]:
            await show_edit_menu(update, context)
            return
        else:
            await ask_stage(update, context)
            return
    while room["hist"]:  # ответы, которые бот подставил сам (остаток плитки), при возврате пропускаем
        key = room["hist"].pop()
        room["a"].pop(key, None)
        if not any(s.auto for s in flow.STEP_BY_KEY.get(key, [])):
            break
    est["multi_key"] = None
    await advance(update, context)


# --- Экран правок ---------------------------------------------------------------
async def show_edit_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    est = context.user_data["est"]
    d = est["id"]
    est["edit_key"] = None
    est["editing"] = True
    rows = []
    for ri, room in enumerate(est["rooms"]):
        c = ctx_of(est, room)
        prefix = ("🚽 " if room["kind"] == "wc" else "🛁 ") if len(est["rooms"]) > 1 else ""
        buttons = [Btn(f"{prefix}{name}: {label}"[:40], callback_data=f"ed:{d}:{ri}:{key}")
                   for key, name, label in flow.edit_items(room["a"], c)]
        for i in range(0, len(buttons), 2):
            rows.append(buttons[i:i + 2])
    rows.append([Btn("✅ Пересчитать", callback_data=f"ed:{d}:done")])
    rows.append([Btn("✖️ Отмена", callback_data=f"w:{d}:cancel")])
    await show(update, context, "✏️ <b>Что поправить?</b>\nНажмите на пункт, чтобы изменить ответ. "
                                "Когда закончите — «Пересчитать».", rows)


# =============================================================================
# Итог: пересчёт, добавление работы, смена цены, сохранение
# =============================================================================
def day_min_active(user, est: dict) -> bool:
    """«Минимум по дням» работает: включён у мастера, задана сумма за день и в смете указаны дни работы."""
    return bool(est.get("kind") != "extra" and user["day_min_on"] and (user["day_rate"] or 0) > 0
                and (est.get("days") or 0) > 0)


def min_for(user, est: dict) -> float:
    """Минимальная сумма сметы: при включённом «Минимуме по дням» это сумма за день × число дней (вместо минимального
    выезда); иначе минимальный выезд, как раньше. Итог поднимается до минимума, а не складывается с ним."""
    if day_min_active(user, est):
        return round(user["day_rate"] * est["days"])
    return user["min_total"]


def mark_days(result: dict, user, est: dict) -> dict:
    """Помечает результат: минимум посчитан по дням (в смете подпись «минимум за N дн.» вместо «минимальный выезд»)."""
    if day_min_active(user, est):
        result["min_days"] = est["days"]
    return result


def adjusted(result: dict, est: dict, user) -> dict:
    """Наценка и скидка сметы (кусок 3, est['adj']). У допработ их нет; без наценки и скидки результат не меняется."""
    if est.get("kind") == "extra" or not est.get("adj"):
        return result
    return calc.apply_adjust(result, est["adj"], min_for(user, est))


def recalc(est: dict, uid: int, user) -> None:
    """Считает смету заново по ответам, текущим ценам пользователя, правкам цен и добавленным работам."""
    db.ensure_prices(uid)
    prices = db.get_prices(uid)
    prices.update(est.get("price_over") or {})
    rooms = [{"kind": r["kind"], "a": flow.clean_answers(r["a"], ctx_of(est, r))} for r in est["rooms"]]
    for r in rooms:  # свои ревизионные люки попадают в «Мои цены» (если такой там ещё нет)
        for src in ("box", "screen", "inst"):
            if r["a"].get(f"hk_{src}") == "custom" and r["a"].get(f"hname_{src}") and r["a"].get(f"hprice_{src}", 0) > 0:
                db.ensure_custom_item(uid, f"Ревизионный люк: {r['a'][f'hname_{src}']}", "шт", r["a"][f"hprice_{src}"])
    result = calc.build_estimate(rooms, est["stage"], prices, min_for(user, est),
                                 manual=est.get("manual") or [], apply_min=est.get("kind") != "extra")
    result = mark_days(adjusted(result, est, user), user, est)
    result["currency"] = user["currency"]
    est["result"] = result
    est["params"] = {"type": "room", "sep": est["sep"], "stage": est["stage"], "rooms": rooms,
                     "manual": est.get("manual") or [], "price_over": est.get("price_over") or {}}
    if est.get("adj"):
        est["params"]["adj"] = est["adj"]
    if est.get("days"):
        est["params"]["days"] = est["days"]


async def finish_estimate(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    uid = update.effective_user.id
    est = context.user_data["est"]
    est["editing"] = False  # правки закончены: дальше человек видит итог
    recalc(est, uid, db.get_user(uid))
    await show_result(update, context, note)


async def show_result(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    user = db.get_user(update.effective_user.id)
    est = context.user_data["est"]
    d = est["id"]
    if "result" not in est:
        await finish_estimate(update, context, note)
        return
    title = ("Допработа · " if est.get("kind") == "extra" else "") + estimate_title(est)
    text = (f"🧾 <b>Смета: {title}</b>\n\n" + (note + "\n\n" if note else "") + note_text(est.get("note"))
            + calc.format_text(est["result"], user["currency"]))
    save_label = "💾 Сохранить изменения" if est.get("edit_id") else "💾 Сохранить"
    rows = [[Btn(save_label, callback_data=f"save:{d}"), Btn("📤 Поделиться", callback_data=f"sh:d{d}")],
            [Btn("➕ Добавить работу", callback_data=f"aw:{d}:start"), Btn("💲 Изменить цену", callback_data=f"pc:{d}:list")],
            [Btn("✏️ Поправить", callback_data=f"ed:{d}:menu"), Btn("📝 Заметка", callback_data=f"nt:d{d}")],
            [Btn("🏠 В меню", callback_data="menu")]]
    if est.get("kind") != "extra":
        rows.insert(3, adj_button(est))   # «Наценка и скидка» над кнопкой «В меню»
        if days_button(est, user):
            rows.insert(3, days_button(est, user))
    if est.get("price_over"):
        rows.insert(2, [Btn("💾 Сохранить новые цены в «Мои цены»", callback_data=f"pc:{d}:keepall")])
    rows.insert(len(rows) - 1, feedback_row(est_ref_of(est)))   # «Верно» / «Есть ошибка» над кнопкой «В меню»
    for hr in reversed(hint_rows(text, 5)):   # «Что это?» к непонятным словам в смете
        rows.insert(len(rows) - 2, hr)
    rows = missing_price_rows(est, f"pc:{d}:mk:") + rows
    await estimate_shown(update, context)
    await show_long(update, context, text, rows, user=user)


def note_text(note) -> str:
    """Заметка над сметой на экране (в PDF для клиента заметок нет)."""
    return f"📝 <b>Заметка:</b> {esc(note)}\n\n" if note else ""


def missing_price_rows(est: dict, prefix: str) -> list:
    """Кнопка «Указать цену» у каждой работы без цены (одинаковые строки не повторяем)."""
    rows, seen = [], set()
    for m in est["result"].get("missing", []):
        ref = m["key"] if prefix.startswith("pc") else str(m.get("idx"))
        if ref in seen or ref == "None":
            continue
        seen.add(ref)
        rows.append([Btn(f"💲 Указать цену: {m['title']}"[:60], callback_data=f"{prefix}{ref}")])
        if len(rows) >= 20:  # в клавиатуре Телеграма не больше 100 кнопок; остальные видно в «Изменить цену»
            break
    return rows


# --- Изменить цену -----------------------------------------------------------------
def price_items(est: dict) -> list:
    """Что можно перецепить на итоговой странице: [(ключ, название, единица, цена или None)]."""
    seen, items = set(), []
    for room in est["result"]["rooms"]:
        for l in room["lines"]:
            if l["key"] not in seen:
                seen.add(l["key"])
                cat = catalog.ITEM_BY_KEY.get(l["key"])
                items.append((l["key"], cat["title"] if cat else l["title"], l["unit"], l["price"]))
    for m in est["result"].get("missing", []):
        if m["key"] not in seen:
            seen.add(m["key"])
            cat = catalog.ITEM_BY_KEY.get(m["key"])
            items.append((m["key"], cat["title"] if cat else m["title"], m["unit"], None))
    return items


async def show_price_list(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    user = db.get_user(update.effective_user.id)
    est = context.user_data["est"]
    d = est["id"]
    items = price_items(est)
    lines, nums, dels = [], [], []
    for i, (key, title, unit, price) in enumerate(items, 1):
        t = esc(cut_title(title, len(items)))
        lines.append(f"{i}. ⚠️ {t} — укажите цену" if price is None else f"{i}. {t} — {fnum(price)}/{esc(unit)}")
        nums.append(Btn(str(i), callback_data=f"pc:{d}:k:{key}"))
        if key.startswith("custom_"):
            dels.append(Btn(f"🗑 {i}", callback_data=f"pc:{d}:delc:{key[7:]}"))
    rows = number_rows(nums)   # список текстом (по левому краю), кнопки — номера
    if dels:
        rows += number_rows(dels)
    rows.append([Btn("⬅️ К смете", callback_data=f"w:{d}:results")])
    await show(update, context, note + "💲 <b>Какую цену изменить?</b>\nНажмите номер. Цена поменяется только в этой смете. "
                                       "Потом её можно сохранить в «Мои цены»."
               + ("\n🗑 + номер — убрать вашу добавленную работу." if dels else "") + "\n\n" + "\n".join(lines),
               rows, user=user)


async def ask_new_price(update: Update, context: ContextTypes.DEFAULT_TYPE, key: str, keep: bool = False) -> None:
    """keep=True — цену для работы без цены: она сразу сохраняется в «Мои цены»."""
    user = db.get_user(update.effective_user.id)
    est = context.user_data["est"]
    d = est["id"]
    items = {k: (t, u, p) for k, t, u, p in price_items(est)}
    if key not in items:
        await show_price_list(update, context)
        return
    title, unit, price = items[key]
    now = "не указана" if price is None else f"{fnum(price)}"
    tail = "\nОна сохранится в «Мои цены»." if keep else ""
    back = f"w:{d}:results" if keep else f"pc:{d}:list"
    rows = []
    ms = market.stats(key, title, unit)
    if ms:   # подсказка по рынку Челябинска; цену выбирает человек
        tail += f"\n💡 {market.hint(ms)}"
        if keep:
            rows.append([Btn(f"Взять среднюю по рынку: {fnum(ms['avg'])} ₽", callback_data=f"pc:{d}:mavg:{key}")])
    rows.append([Btn("⬅️ Отмена", callback_data=back)])
    await show(update, context, f"💲 <b>{esc(title)}</b>\nСейчас: {now} за {unit}.\n\nНапишите цену числом:{tail}",
               rows, user=user, await_input={"kind": "pc_price", "d": d, "key": key, "keep": keep})


async def apply_new_price(update: Update, context: ContextTypes.DEFAULT_TYPE, key: str, value: float,
                          keep: bool = False) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    est = context.user_data["est"]
    d = est["id"]
    old = {k: p for k, t, u, p in price_items(est)}.get(key)
    title = {k: t for k, t, u, p in price_items(est)}.get(key, key)
    if key.startswith("custom_"):
        line = est["manual"][int(key[7:])]
        line["price"] = value
        if keep:  # добавленная вручную работа: запоминаем в «Мои работы»
            db.add_custom_item(uid, line["title"], line["unit"], value)
    elif keep:
        db.set_price(uid, key, value)
    else:
        est["price_over"][key] = value
    recalc(est, uid, user)
    before = "не была указана" if old is None else f"была {fnum(old)}"
    text = (f"✅ Цена {'сохранена в «Мои цены»' if keep else 'изменена'}: <b>{esc(title)}</b> — теперь {fnum(value)} "
            f"({before}).\nИтог пересчитан: <b>{money(user, est['result']['total'])}</b>.")
    rows = []
    if not keep and not key.startswith("custom_"):
        rows.append([Btn("💾 Сохранить в «Мои цены»", callback_data=f"pc:{d}:keep:{key}")])
        rows.append([Btn("↩️ Вернуть прежнюю цену", callback_data=f"pc:{d}:undo:{key}")])
    rows.append([Btn("💲 Изменить ещё", callback_data=f"pc:{d}:list"), Btn("📄 К смете", callback_data=f"w:{d}:results")])
    await show(update, context, text, rows, user=user)


async def pc_action(update: Update, context: ContextTypes.DEFAULT_TYPE, p: list) -> None:
    """Кнопки смены цены: pc:<смета>:list|k:<ключ>|keep:<ключ>|keepall|undo:<ключ>|delc:<номер>."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    est = context.user_data["est"]
    d = est["id"]
    sub = p[1]
    if "result" not in est:
        recalc(est, uid, user)
    if sub == "list":
        await show_price_list(update, context)
    elif sub == "k":
        await ask_new_price(update, context, p[2])
    elif sub == "mk":  # цена для работы, на которую она не указана: сразу в «Мои цены»
        await ask_new_price(update, context, p[2], keep=True)
    elif sub == "mavg":   # «Взять среднюю по рынку» для работы без цены
        items = {k: (t, u) for k, t, u, _ in price_items(est)}
        ms = market.stats(p[2], *items.get(p[2], ("", "")))
        if ms:
            await apply_new_price(update, context, p[2], float(ms["avg"]), keep=True)
    elif sub == "keep":
        key = p[2]
        if key in est["price_over"]:
            db.set_price(uid, key, est["price_over"].pop(key))
            recalc(est, uid, user)
        title = catalog.ITEM_BY_KEY.get(key, {}).get("title", key)
        await show(update, context, f"✅ Цена «{esc(title)}» сохранена в «Мои цены» — она останется для всех будущих смет.",
                   [[Btn("💲 Изменить ещё", callback_data=f"pc:{d}:list"), Btn("📄 К смете", callback_data=f"w:{d}:results")]],
                   user=user)
    elif sub == "keepall":
        n = 0
        for key in list(est["price_over"]):
            db.set_price(uid, key, est["price_over"].pop(key))
            n += 1
        recalc(est, uid, user)
        await show_result(update, context, f"✅ Новые цены сохранены в «Мои цены» ({n}).")
    elif sub == "undo":
        est["price_over"].pop(p[2], None)
        recalc(est, uid, user)
        await show_price_list(update, context, "↩️ Прежняя цена возвращена.\n\n")
    elif sub == "delc":
        i = int(p[2])
        if 0 <= i < len(est["manual"]):
            est["manual"].pop(i)
            recalc(est, uid, user)
        await show_price_list(update, context, "🗑 Добавленная работа убрана.\n\n")


# --- Добавить работу -----------------------------------------------------------------
async def aw_ask(update: Update, context: ContextTypes.DEFAULT_TYPE, stage: str, note: str = "") -> None:
    """Добавление работы по шагам: название → единица → цена → количество."""
    user = db.get_user(update.effective_user.id)
    est = context.user_data["est"]
    d = est["id"]
    tmp = est["tmp"]
    cancel = [Btn("⬅️ Отмена", callback_data=f"w:{d}:results")]
    await_input = {"kind": "aw_" + stage, "d": d}
    rows: list = []
    if stage == "title":
        text = "➕ <b>Добавить работу</b>\nНапишите название работы (например, «Установка полотенцесушителя»):"
    elif stage == "unit":
        text = f"➕ <b>{esc(tmp['title'])}</b>\nВ чём считаем? Нажмите кнопку или напишите свою единицу."
        codes = list(UNITS)
        for i in range(0, len(codes), 3):
            rows.append([Btn(UNITS[c], callback_data=f"aw:{d}:u:{c}") for c in codes[i:i + 3]])
    elif stage == "price":
        text = f"➕ <b>{esc(tmp['title'])}</b>\nЦена за 1 {esc(tmp['unit'])} (числом):"
    else:
        text = f"➕ <b>{esc(tmp['title'])}</b>\nСколько {esc(tmp['unit'])}? (числом)"
        rows.append([Btn("1", callback_data=f"aw:{d}:q:1")])
    rows.append(cancel)
    await show(update, context, note + text, rows, user=user, await_input=await_input)


async def aw_finish(update: Update, context: ContextTypes.DEFAULT_TYPE, qty: float) -> None:
    uid = update.effective_user.id
    est = context.user_data["est"]
    tmp = est["tmp"]
    est["manual"].append({"title": tmp["title"], "unit": tmp["unit"], "price": tmp["price"], "qty": qty})
    title = tmp["title"]
    est["tmp"] = {}
    recalc(est, uid, db.get_user(uid))
    await show_result(update, context, f"✅ Работа добавлена в смету: {esc(title)}.")


async def aw_action(update: Update, context: ContextTypes.DEFAULT_TYPE, p: list) -> None:
    est = context.user_data["est"]
    sub = p[1]
    if sub == "start":
        est["tmp"] = {}
        await aw_ask(update, context, "title")
    elif sub == "u" and p[2] in UNITS and "title" in est["tmp"]:
        est["tmp"]["unit"] = UNITS[p[2]]
        await aw_ask(update, context, "price")
    elif sub == "q" and {"title", "unit", "price"} <= set(est["tmp"]):
        await aw_finish(update, context, float(p[2]))
    else:
        await show_result(update, context)


# --- Сохранение ----------------------------------------------------------------------
async def save_current(update: Update, context: ContextTypes.DEFAULT_TYPE, object_id: int) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    est = context.user_data["est"]
    old = db.get_estimate(uid, est["edit_id"]) if est.get("edit_id") else None
    if old and (old["status"] or "open") == "done":   # смета тем временем ушла в архив: молча перезаписывать нельзя
        await show(update, context, "🗄 Эта смета в архиве, изменить её нельзя. Откройте её в архиве и нажмите "
                                    "«Вернуть для доработки».",
                   [[Btn("📂 Открыть смету", callback_data=f"est:{old['id']}"), Btn("🏠 В меню", callback_data="menu")]],
                   user=user)
        return
    if est["type"] == "extra":
        kind, title = "extra", est.get("name") or "Допработа"
        params = {"type": "extra", "name": title, "lines": est["lines"], "rates": est.get("rates") or {}}
        room = "extra"
    elif est["type"] == "croom":
        kind, title, room = est.get("kind", "main"), est["room_name"], est["room"]
        params = {"type": "croom", "room": room, "name": title, "lines": est["lines"], "mz": est.get("mz"),
                  "adj": est.get("adj"), "days": est.get("days"), "og": est.get("og")}
    else:
        kind, title = est.get("kind", "main"), estimate_title(est)
        params, room = est["params"], "bathroom"
    sid = db.save_estimate(uid, object_id, room, title, est["result"]["has_tile"], params, est["result"],
                           est.get("edit_id"), kind, parent_id=est.get("parent"), note=est.get("note"))
    if not est.get("edit_id"):   # тихий счётчик: сохранённая смета и какие работы в ней были (без метража и цен)
        db.log_event("est_saved")
        for name in sorted(work_names(est["result"])):
            db.log_event("work", name)
    drop_draft(update, context, est["id"])
    obj = db.get_object(uid, object_id)
    rows = [[Btn("📂 Открыть смету", callback_data=f"est:{sid}"), Btn("📤 Поделиться", callback_data=f"sh:{sid}")],
            [Btn("📁 К объекту", callback_data=f"obj:{object_id}"), Btn("🏠 В меню", callback_data="menu")]]
    if est.get("parent"):   # допработа к смете «В работе»: возвращаемся к ней, блок уже там
        rows.insert(0, [Btn("⬅️ К основной смете", callback_data=f"est:{est['parent']}")])
    await show(update, context, f"✅ Сохранено в объект «{esc(obj['name'])}»: {esc(title)}.", rows, user=user)


def work_names(result: dict) -> set:
    """Названия работ сметы для тихого счётчика популярных работ: каталожные — как в каталоге, свои — очищенные."""
    names = set()
    for room in result.get("rooms", []):
        for l in room["lines"]:
            cat = catalog.ITEM_BY_KEY.get(l["key"])
            name = cat["title"] if cat else pool.clean_title(l["title"])
            if name:
                names.add(name)
    return names


async def ask_where_to_save(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    d = context.user_data["est"]["id"]
    rows = [[Btn(f"🏠 {o['name']}", callback_data=f"sv:{d}:{o['id']}")] for o in db.list_objects(uid)]
    rows.append([Btn("➕ Новый объект", callback_data=f"sv:{d}:new")])
    rows.append([Btn("⬅️ Назад", callback_data=f"w:{d}:results")])
    await show(update, context, "💾 В какой объект сохранить смету?", rows, user=user)


# =============================================================================
# Объекты и сохранённые сметы
# =============================================================================
def est_status(row) -> str:
    """Статус сметы из строки базы (у старых смет пусто — они «Открыты»)."""
    st = row["status"] if "status" in row.keys() else None
    return st if st in STATUS_NAME else "open"


def is_protected(row) -> bool:
    """Основные строки сметы «В работе» защищены от правки (допработы к ней править можно)."""
    return est_status(row) == "work" and not (row["kind"] == "extra" and row["parent_id"])


def est_label(user, e) -> str:
    mark = "➕ " if e["kind"] == "extra" else "🧾 "
    return f"{STATUS_ICON[est_status(e)]} {mark}{e['title']} · {money(user, e['total'])}"


STATUS_LEGEND = "🟢 открыта · 🛠 в работе · 🗄 завершена (архив)"


async def show_objects(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    objs = db.list_objects(uid, "open")
    text = "📁 <b>Мои объекты</b>\nОбъект — это папка: адрес или клиент. Внутри лежат сметы и допработы."
    if not objs:
        text += "\n\nПока ни одного объекта в работе."
    rows = [[Btn("⬜ Плиточник (все плиточные сметы)", callback_data="tiler")]]
    if not view_only(user):
        rows.append([Btn("➕ Новый объект", callback_data="obj:new")])
    counts = db.count_estimates_by_status(uid)
    if counts:   # сметы можно смотреть по статусам, по всем объектам сразу
        rows.append([Btn(f"{STATUS_ICON[s]} {STATUS_NAME[s]} ({counts.get(s, 0)})", callback_data=f"obj:st:{s}")
                     for s in ("open", "work", "done")])
    for o in objs:
        extra = f" (+{o['n_extra']} доп.)" if o["n_extra"] else ""
        rows.append([Btn(f"🏠 {o['name']} · {o['n']} см.{extra} · {money(user, o['total'])}"[:60],
                         callback_data=f"obj:{o['id']}")])
    done = db.list_objects(uid, "done")
    if done:
        rows.append([Btn(f"✅ Завершённые ({len(done)})", callback_data="obj:closed")])
    rows.append([Btn("⬅️ В меню", callback_data="menu")])
    await show(update, context, text, rows, user=user)


async def show_status_list(update: Update, context: ContextTypes.DEFAULT_TYPE, status: str) -> None:
    """Все сметы с одним статусом по всем объектам («Мои объекты» → по статусам)."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    ests = db.list_estimates(uid, status=status)
    text = f"{STATUS_ICON[status]} <b>Сметы: {STATUS_NAME[status].lower()}</b>"
    if status == "done":
        text += "\nАрхив: смету можно открыть и посмотреть, изменить случайно нельзя."
    if not ests:
        text += "\n\nТаких смет пока нет."
    rows = [[Btn(f"{e['object_name']} · {e['title']} · {money(user, e['total'])}"[:60], callback_data=f"est:{e['id']}")]
            for e in ests]
    rows.append([Btn("⬅️ К объектам", callback_data="obj:list")])
    await show(update, context, text, rows, user=user)


async def show_closed_objects(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    rows = [[Btn(f"✅ {o['name']} · {money(user, o['total'])}"[:60], callback_data=f"obj:{o['id']}")]
            for o in db.list_objects(uid, "done")]
    rows.append([Btn("⬅️ К объектам", callback_data="obj:list")])
    await show(update, context, "✅ <b>Завершённые объекты</b>", rows, user=user)


OBJ_FILTERS = (("active", "Активные"), ("open", "Открытые"), ("work", "В работе"), ("done", "🗄 Архив"))


async def show_object(update: Update, context: ContextTypes.DEFAULT_TYPE, object_id: int) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    obj = db.get_object(uid, object_id)
    if not obj:
        await show_objects(update, context)
        return
    ests = db.list_estimates(uid, object_id)
    main_sum = sum(e["total"] for e in ests if e["kind"] != "extra")
    extra_sum = sum(e["total"] for e in ests if e["kind"] == "extra")
    n_main = sum(1 for e in ests if e["kind"] != "extra")
    n_extra = len(ests) - n_main
    by = {s: sum(1 for e in ests if est_status(e) == s) for s in STATUS_NAME}
    flt = (context.user_data.get("obj_flt") or {}).get(str(object_id), "active")
    shown = [e for e in ests if (est_status(e) != "done" if flt == "active" else est_status(e) == flt)]
    done = (obj["status"] or "open") == "done"
    text = f"{'✅' if done else '🏠'} <b>{esc(obj['name'])}</b>" + (" — завершён" if done else " — в работе") + "\n\n"
    text += note_text(obj["note"])
    text += f"Основные сметы: {n_main} · {money(user, main_sum)}\n"
    if n_extra:
        text += f"Допработы: {n_extra} · {money(user, extra_sum)}\n"
    text += f"💰 Всего по объекту: <b>{money(user, main_sum + extra_sum)}</b>\n"
    if ests:
        text += f"\nСметы: {STATUS_LEGEND}\nПоказаны: {dict(OBJ_FILTERS)[flt].lower()}"
        if not shown:
            text += "\nТаких смет нет."
    rows = []
    if ests:   # список можно смотреть по статусам
        rows.append([Btn(("👉 " if k == flt else "") + name + (f" ({by['done']})" if k == "done" else ""),
                         callback_data=f"obj:flt:{object_id}:{k}") for k, name in OBJ_FILTERS])
    rows += [[Btn(est_label(user, e)[:60], callback_data=f"est:{e['id']}")] for e in shown]
    if view_only(user):   # срок кончился: только просмотр
        rows.append([Btn("⬅️ К объектам", callback_data="obj:list")])
        await show(update, context, text, rows, user=user)
        return
    if done:
        rows.append([Btn("↩️ Вернуть в работу", callback_data=f"obj:reopen:{object_id}")])
    else:
        rows.append([Btn("➕ Новая смета здесь", callback_data=f"obj:add:{object_id}"),
                     Btn("➕ Допработа", callback_data=f"obj:xadd:{object_id}")])
        rows.append([Btn("✅ Завершить объект", callback_data=f"obj:done:{object_id}")])
    rows.append([Btn("📝 Заметка", callback_data=f"nt:o{object_id}"),
                 Btn("✏️ Переименовать", callback_data=f"obj:ren:{object_id}")])
    rows.append([Btn("🗑 Удалить", callback_data=f"obj:del:{object_id}"),
                 Btn("⬅️ К объектам", callback_data="obj:list")])
    await show(update, context, text, rows, user=user)


async def show_tiler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Фильтр: все сметы с укладкой плитки по всем объектам."""
    user = db.get_user(update.effective_user.id)
    ests = db.list_estimates(user["user_id"], tiler_only=True)
    tile_total = sum(json.loads(e["result"]).get("tile_sum", 0) for e in ests)
    text = "⬜ <b>Плиточник</b>\nВсе сметы с укладкой плитки по всем объектам."
    if ests:
        text += f"\n\nСмет: {len(ests)}\nПлиточные работы всего: <b>{money(user, tile_total)}</b>"
    else:
        text += "\n\nПлиточных смет пока нет."
    rows = []
    for e in ests:
        tile_sum = json.loads(e["result"]).get("tile_sum", 0)
        mark = "➕" if e["kind"] == "extra" else "🏠"
        rows.append([Btn(f"{mark} {e['object_name']} · {e['title']} · плитка {money(user, tile_sum)}"[:60],
                         callback_data=f"est:{e['id']}")])
    rows.append([Btn("⬅️ К объектам", callback_data="obj:list")])
    await show(update, context, text, rows, user=user)


def extras_text(children, cur: str, main_total: float) -> str:
    """Блок «Доп. работы» в готовой смете: допработы добавлены отдельно, основные строки не менялись."""
    out = ["➕ <b>Доп. работы</b> (добавлены отдельным блоком, основная смета не менялась)"]
    total = 0
    for c in children:
        res = json.loads(c["result"])
        out.append(f"<b>{esc(c['title'])}</b>")
        for room in res["rooms"]:
            for l in room["lines"]:
                out.append(f"• {esc(l['title'])}: {fnum(l['qty'])} {esc(l['unit'])} × {fnum(l['price'])} = "
                           f"{fmoney(l['sum'], cur)}")
        out.append(f"  Итого: {fmoney(res['total'], cur)}")
        total += res["total"]
    out.append(f"\n💰 <b>Всего с допработами: {fmoney(main_total + total, cur)}</b>")
    return "\n".join(out)


async def show_saved_estimate(update: Update, context: ContextTypes.DEFAULT_TYPE, est_id: int, note: str = "") -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    row = db.get_estimate(uid, est_id)
    if not row:
        await show_objects(update, context)
        return
    result = json.loads(row["result"])
    params = json.loads(row["params"])
    cur = result.get("currency", user["currency"])
    st = est_status(row)
    child_of = row["parent_id"] if row["kind"] == "extra" else None
    kind = "Допработа" if row["kind"] == "extra" else "Смета"
    text = (f"🧾 <b>{kind}: {esc(row['title'])}</b>\n🏠 Объект: {esc(row['object_name'])}\n"
            f"{STATUS_ICON[st]} Статус: <b>{STATUS_NAME[st]}</b>" + (" — в архиве" if st == "done" else "") + "\n\n"
            + (note + "\n\n" if note else "") + note_text(row["note"]) + calc.format_text(result, cur))
    children = [] if row["kind"] == "extra" else db.list_children(uid, est_id)
    if children:
        text += "\n\n" + extras_text(children, cur, result["total"])
    rows = []
    locked = view_only(user)   # срок теста кончился: смотреть и отправлять можно, менять нельзя
    if locked:
        rows.append([Btn("📤 Поделиться", callback_data=f"sh:{est_id}")])
    elif st == "done":    # архив: смотреть и отправлять можно, менять нельзя
        rows.append([Btn("📤 Поделиться", callback_data=f"sh:{est_id}")])
        rows.append([Btn("↩️ Вернуть для доработки", callback_data=f"est:sts:{est_id}:work")])
    elif is_protected(row):   # «В работе»: основные строки защищены, новое — отдельным блоком
        rows.append([Btn("➕ Доп. работы", callback_data=f"est:xw:{est_id}"),
                     Btn("📤 Поделиться", callback_data=f"sh:{est_id}")])
        rows.append([Btn("✏️ Изменить", callback_data=f"est:edit:{est_id}")])
    else:
        rows.append([Btn("✏️ Поправить", callback_data=f"est:edit:{est_id}"),
                     Btn("📤 Поделиться", callback_data=f"sh:{est_id}")])
        if params.get("type") not in ("extra", "croom"):
            rows.append([Btn("➕ Добавить работу", callback_data=f"est:addw:{est_id}"),
                         Btn("💲 Изменить цену", callback_data=f"est:pc:{est_id}")])
    for c in children:
        rows.append([Btn(est_label(user, c)[:60], callback_data=f"est:{c['id']}")])
    tools = []
    if st != "done" and not locked:
        tools.append(Btn("📝 Заметка", callback_data=f"nt:e{est_id}"))
    if not child_of and not locked:    # у допработы статус тот же, что у её сметы
        tools.append(Btn("🔄 Статус", callback_data=f"est:st:{est_id}"))
    if tools:
        rows.append(tools)
    rows += hint_rows(text, 5)   # «Что это?» к непонятным словам в смете (для заказчика тоже)
    rows.append(feedback_row(f"e{est_id}"))
    last = []
    if st != "done" and not is_protected(row) and not locked:
        last.append(Btn("🗑 Удалить", callback_data=f"est:del:{est_id}"))
    last.append(Btn("⬅️ К смете" if child_of else "⬅️ К объекту",
                    callback_data=f"est:{child_of}" if child_of else f"obj:{row['object_id']}"))
    rows.append(last)
    await show_long(update, context, text, rows, user=user)


async def show_status_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, est_id: int) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    row = db.get_estimate(uid, est_id)
    if not row:
        await show_objects(update, context)
        return
    st = est_status(row)
    text = (f"🔄 <b>Статус сметы</b> «{esc(row['title'])}»\nСейчас: {STATUS_ICON[st]} <b>{STATUS_NAME[st]}</b>\n\n"
            "🟢 <b>Открыта</b> — смету можно править.\n"
            "🛠 <b>В работе</b> — основные строки защищены от случайной правки, новое добавляется кнопкой «Доп. работы» "
            "отдельным блоком, по тем же расценкам.\n"
            "🗄 <b>Завершена</b> — уходит в архив: открыть можно, изменить нельзя. Из архива смету можно вернуть.")
    rows = [[Btn(("✅ " if s == st else "") + f"{STATUS_ICON[s]} {STATUS_NAME[s]}", callback_data=f"est:sts:{est_id}:{s}")]
            for s in ("open", "work", "done")]
    rows.append([Btn("⬅️ К смете", callback_data=f"est:{est_id}")])
    await show(update, context, text, rows, user=user)


async def set_status(update: Update, context: ContextTypes.DEFAULT_TYPE, est_id: int, status: str, confirmed: bool) -> None:
    """Смена статуса кнопкой. «Завершена» (архив) просит подтверждения."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    row = db.get_estimate(uid, est_id)
    if not row or status not in STATUS_NAME:
        await show_objects(update, context)
        return
    if row["kind"] == "extra" and row["parent_id"]:   # статус допработы — статус её сметы
        await show_saved_estimate(update, context, row["parent_id"])
        return
    if status == "done" and not confirmed and est_status(row) != "done":
        await show(update, context, f"🗄 Завершить смету «{esc(row['title'])}»? Она уйдёт в архив: открыть и посмотреть "
                                    "можно, изменить нельзя. Из архива её можно вернуть для доработки.",
                   [[Btn("Да, завершить", callback_data=f"est:stok:{est_id}"), Btn("Нет", callback_data=f"est:st:{est_id}")]],
                   user=user)
        return
    db.set_estimate_status(uid, est_id, status)
    await show_saved_estimate(update, context, est_id, f"{STATUS_ICON[status]} Статус: {STATUS_NAME[status]}."
                              + (" Смета в архиве." if status == "done" else ""))


async def start_extra_for(update: Update, context: ContextTypes.DEFAULT_TYPE, row) -> None:
    """«Доп. работы» у сметы «В работе»: новые работы собираются отдельным блоком, расценки берутся из этой сметы."""
    uid = update.effective_user.id
    for d in db.list_drafts(uid):   # блок допработ к этой смете уже начат — продолжаем его
        st = json.loads(d["state"])
        if st.get("type") == "extra" and st.get("parent") == row["id"] and not st.get("edit_id"):
            if await activate(update, context, d["id"]):
                await show_extra(update, context)
            return
    est = new_draft(update, context, "extra", row["object_id"], "extra")
    result = json.loads(row["result"])
    est.update(lines=[], name="Допработы", parent=row["id"],
               rates={l["key"]: l["price"] for room in result["rooms"] for l in room["lines"]})
    await show_extra(update, context)


# --- Заметки: одна на смету и одна на объект ------------------------------------------
def note_target(user, context, target: str):
    """Заметка по кнопке «Заметка»: target — d<номер открытой сметы>, e<номер сохранённой сметы>, o<номер объекта>.
    Возвращает (текущий текст, куда вернуться) или None, если такой цели нет."""
    uid = user["user_id"]
    kind, num = target[:1], target[1:]
    if not num.isdigit():
        return None
    num = int(num)
    if kind == "d":
        est = context.user_data.get("est")
        if not est or est.get("id") != num:
            return None
        return est.get("note") or "", f"w:{num}:results"
    if kind == "e":
        row = db.get_estimate(uid, num)
        return (row["note"] or "", f"est:{num}") if row and est_status(row) != "done" else None
    if kind == "o":
        row = db.get_object(uid, num)
        return (row["note"] or "", f"obj:{num}") if row else None
    return None


async def show_note(update: Update, context: ContextTypes.DEFAULT_TYPE, user, target: str) -> None:
    found = note_target(user, context, target)
    if not found:
        await send_menu(update, context)
        return
    cur, back = found
    what = "объекту" if target[0] == "o" else "смете"
    text = f"📝 <b>Заметка к {what}</b>\n"
    text += (f"\nСейчас: {esc(cur)}\n\nНапишите новый текст, он заменит прежний." if cur else
             "\nЗаметки пока нет. Напишите текст свободно: он сохранится и будет виден при открытии. "
             "В PDF для клиента заметка не попадает.")
    rows = []
    if cur:
        rows.append([Btn("🗑 Удалить заметку", callback_data=f"nt:{target}:x")])
    rows.append([Btn("⬅️ Назад", callback_data=back)])
    await show(update, context, text, rows, user=user, await_input={"kind": "note", "t": target})


async def save_note(update: Update, context: ContextTypes.DEFAULT_TYPE, user, target: str, text: str) -> None:
    """Записывает заметку (пустой текст — удаляет) и возвращает на экран сметы или объекта."""
    uid = user["user_id"]
    found = note_target(user, context, target)
    if not found:
        await send_menu(update, context)
        return
    _, back = found
    text = text.strip()[:NOTE_MAX]
    kind, num = target[0], int(target[1:])
    if kind == "d":
        context.user_data["est"]["note"] = text
        context.user_data["await"] = None
        est = context.user_data["est"]
        if est["type"] == "croom":
            await show_croom_result(update, context, "📝 Заметка сохранена.")
        else:
            await show_result(update, context, "📝 Заметка сохранена.")
        return
    context.user_data["await"] = None
    if kind == "e":
        db.set_estimate_note(uid, num, text)
        await show_saved_estimate(update, context, num, "📝 Заметка сохранена." if text else "🗑 Заметка удалена.")
    else:
        db.set_object_note(uid, num, text)
        await show_object(update, context, num)


async def load_saved_into_draft(update: Update, context: ContextTypes.DEFAULT_TYPE, est_id: int) -> Optional[dict]:
    """Открывает сохранённую смету для правки как открытую смету (повторно не плодит копии)."""
    uid = update.effective_user.id
    row = db.get_estimate(uid, est_id)
    if not row:
        await show_objects(update, context)
        return None
    for d in db.list_drafts(uid):  # правка этой сметы уже открыта — продолжаем её
        st = json.loads(d["state"])
        if st.get("edit_id") == est_id:
            return await activate(update, context, d["id"])
    params = json.loads(row["params"])
    if params.get("type") == "extra":
        est = new_draft(update, context, "extra", row["object_id"], "extra", track=False)
        est.update(edit_id=est_id, name=params.get("name", ""), lines=params.get("lines", []),
                   parent=row["parent_id"], rates=params.get("rates") or {}, note=row["note"] or "")
        return est
    if params.get("type") == "croom":
        est = new_draft(update, context, "croom", row["object_id"], row["kind"] or "main", track=False)
        est.update(edit_id=est_id, room=params["room"], room_name=params["name"], name="",
                   icon=ROOM_ICON.get(params["room"], {"price": "📚", "calc": "🧮", "own": "🏭", "small": "🔧", "open": "🏗"}.get(params["room"], "🏠")),
                   lines=params.get("lines", []), note=row["note"] or "",
                   mz=params.get("mz"), mz_done=True, flt={})   # смета уже была собрана: замер не переспрашиваем
        if params.get("adj"):
            est["adj"] = params["adj"]
        if params.get("days"):
            est["days"] = params["days"]
        if params.get("og"):
            est["og"] = params["og"]
        return est
    est = new_draft(update, context, "room", row["object_id"], row["kind"] or "main", track=False)
    est.update(sep=params["sep"], stage=params["stage"], edit_id=est_id, editing=True, note=row["note"] or "",
               manual=params.get("manual", []), price_over=params.get("price_over", {}))
    if params.get("adj"):
        est["adj"] = params["adj"]
    if params.get("days"):
        est["days"] = params["days"]
    est["rooms"] = []
    for r in params["rooms"]:
        answers = flow.migrate_answers(r["a"])
        est["rooms"].append({"kind": r["kind"], "a": answers, "hist": list(answers.keys())})
    return est


# =============================================================================
# Допработа по строкам
# =============================================================================
def extra_lines_text(est: dict, user) -> str:
    croom = est["type"] == "croom"
    if not est["lines"]:
        return "Работ пока нет." if croom else "Строк пока нет."
    out, total = [], 0
    for i, l in enumerate(est["lines"], 1):
        s = round(round(l["qty"], 2) * l["price"])
        total += s
        out.append(f"{i}. {esc(l['title'])}: {fnum(l['qty'])} {esc(l['unit'])} × {fnum(l['price'])} = {money(user, s)}"
                   + (" ⚠️ цена не указана, в итог не войдёт" if croom and l["price"] <= 0 else ""))
    out.append(f"\n💰 Итого: <b>{money(user, total)}</b>")
    return "\n".join(out)


def x_cancel(est: dict) -> list:
    """Кнопка «Отмена» на каждом шаге конструктора комнаты (в допработе её нет). Смета при этом остаётся открытой."""
    return [Btn("✖️ Отмена", callback_data=f"w:{est['id']}:cancel")] if est["type"] == "croom" else []


def save_pending_prices(uid: int, est: dict, only: Optional[int] = None) -> int:
    """Конструктор комнаты: кладёт в «Мои цены» новые работы и изменённые цены. Возвращает, сколько записано.
    only — номер одной строки (так сохраняется цена, которую человек указал для работы без цены)."""
    n = 0
    for i, l in enumerate(est["lines"]):
        if not l.get("pend") or (only is not None and i != only):
            continue
        key = l.get("key") or ""
        cid = custom_id(key)
        if cid is not None and db.get_custom_item(uid, cid):
            db.set_custom_price(uid, cid, l["price"])
        elif key in catalog.ITEM_BY_KEY:
            db.set_price(uid, key, l["price"])
        else:
            l["key"] = f"c{db.add_custom_item(uid, l['title'], l['unit'], l['price'])}"
        l["pend"] = False
        n += 1
    return n


# --- Поиск работы по всем разделам прайса ------------------------------------------
def _norm(s: str) -> str:
    """Для поиска: без регистра, «ё» = «е»."""
    return s.lower().replace("ё", "е")


def _stem(word: str) -> str:
    """Грубо отрезает окончание, чтобы «розетки» находило «розетка» (ищем по части слова)."""
    if len(word) > 5:
        return word[:-2]
    if len(word) > 3:
        return word[:-1]
    return word


def all_items(uid: int) -> list:
    """Все работы пользователя: [(ключ, название, единица, цена)]. Ключ своих работ — c<номер>."""
    prices = db.get_prices(uid)
    items = [(k, it["title"], it["unit"], prices.get(k, 0)) for k, it in catalog.ITEM_BY_KEY.items()]
    custom = db.list_custom_items(uid)
    mine = {(c["title"].lower().strip(), c["unit"]) for c in custom}
    # работы из прайсов фирм (без своей цены); если человек уже сохранил такую у себя, показываем его вариант
    items += [(m["id"], m["title"], m["unit"], 0) for m in market.items()
              if (m["title"].lower().strip(), m["unit"]) not in mine]
    items += [(f"c{c['id']}", c["title"], c["unit"], c["price"]) for c in custom]
    return items


def lookup_item(uid: int, key: str):
    return next((it for it in all_items(uid) if it[0] == key), None)


def search_items(uid: int, query: str):
    """Ищет по названиям во всех разделах. Возвращает (список, точное_ли_совпадение).
    Сначала ищем работы, где есть все слова запроса; если таких нет — где есть хоть одно."""
    words = [_stem(w) for w in re.findall(r"\w+", _norm(query)) if len(w) > 1]
    if not words:
        return [], True
    items = [it for it in all_items(uid) if it[0] not in catalog.HIDDEN_DUPLICATES]
    exact = [it for it in items if all(w in _norm(it[1]) for w in words)]
    if exact:
        return exact, True
    return [it for it in items if any(w in _norm(it[1]) for w in words)], False


def custom_id(key: str):
    """'c12' -> 12 (своя работа пользователя); для обычных ключей прайса — None."""
    m = re.fullmatch(r"c(\d+)", key)
    return int(m.group(1)) if m else None


def price_of(uid: int, key: str) -> float:
    item = lookup_item(uid, key)
    return item[3] if item else 0


def item_label(key: str, title: str, unit: str, price: float) -> str:
    return f"{title} — {fnum(price)}/{unit}" if price > 0 else f"⚠️ {title} — цена не указана"


def item_lines_text(found: list) -> str:
    """Список работ для выбора текстом: «1. Название — цена/единица». Ровно по левому краю (у кнопок Телеграма
    выравнивание не задаётся), выбирать — кнопками с номерами под списком (item_number_rows)."""
    return "\n".join(f"{n}. " + esc(item_label(k, cut_title(t, len(found)), u, p)) for n, (k, t, u, p) in enumerate(found, 1))


def item_number_rows(d: int, found: list) -> list:
    return number_rows([Btn(str(n), callback_data=f"xa:{d}:i:{it[0]}") for n, it in enumerate(found, 1)])


MAX_FOUND = 10
XA_LIST_MAX = 40   # работ раздела на экране выбора допработы (кнопок в сообщении Телеграма не больше ста)


async def x_search(update: Update, context: ContextTypes.DEFAULT_TYPE, query) -> None:
    """Экран поиска работы для допработы. query=None — ещё ничего не искали."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    est = context.user_data["est"]
    d = est["id"]
    rows: list = []
    if query is None:
        text = ("🔍 <b>Найти работу</b>\nНапишите слово (например, «розетка») — я поищу по названиям "
                "во всех разделах. Или выберите работу из разделов.")
    else:
        found, exact = search_items(uid, query)
        est["tmp"] = {"query": query.strip()[:60]}
        if not found:
            text = (f"🔍 По запросу «{esc(query)}» ничего не нашёл.\nПопробуйте другое слово или добавьте свою работу: "
                    f"название, единицу и цену — она попадёт в {'смету' if est['type'] == 'croom' else 'допработу'}, "
                    "и её можно будет сохранить в «Мои цены».")
        else:
            text = f"🔍 Нашёл по запросу «{esc(query)}»:" if exact else \
                   f"🔍 Точного совпадения с «{esc(query)}» нет, показываю похожие:"
            if len(found) > MAX_FOUND:
                text += f"\n(показаны первые {MAX_FOUND} из {len(found)}, уточните слово)"
            text += "\n\n" + item_lines_text(found[:MAX_FOUND])   # список текстом, кнопки — номера
            rows += item_number_rows(d, found[:MAX_FOUND])
            rows += hint_rows("\n".join(it[1] for it in found[:MAX_FOUND]))
            text += "\n\nНажмите номер нужной работы или напишите другое слово."
    rows.append([Btn("📂 Выбрать из разделов", callback_data=f"xa:{d}:grp"),
                 Btn("✍️ Добавить свою работу", callback_data=f"xa:{d}:own")])
    rows.append([Btn("⬅️ Назад", callback_data=f"xa:{d}:back")] + x_cancel(est))
    await show(update, context, text, rows, await_input={"kind": "x_search", "d": d})


PAGE_SIZE = 12   # сколько работ на одной странице общего списка (подсказки «по рынку» идут текстом под ним)


def est_geom(est: dict, part: Optional[int] = None):
    """Геометрия комнаты по замеру (None — замера нет или он не закончен). part — номер части комнаты:
    None — вся комната (части складываются), 0 — основная, 1 и дальше — добавленные."""
    if est.get("og"):   # «Объект без стен»: своя геометрия, частей комнаты нет
        return calc.open_geometry(est["og"])
    mz = est.get("mz")
    if mz and calc.mz_complete(mz):
        if part is not None and not 0 <= part < len(calc.mz_parts(mz)):
            part = None
        return calc.room_geometry(mz, part)
    return None


def auto_qty(est: dict, key, unit: str, title: str = "", part: Optional[int] = None):
    """Количество работы по замеру: (число, считает ли его бот сам). Нет правила — 1, считается вручную.
    part — для какой части комнаты работа (None — для всей комнаты)."""
    g = est_geom(est, part)
    basis = catalog.QTY_BASIS.get(key or "")
    if basis is None:
        # работа из прайсов фирм (или уже сохранённая в «Мои работы» из них): по названию — стены, пол, потолок, плинтус
        m = market.item(key or "") or market.item(("t", title.lower().strip(), unit))
        if m:
            basis = market.basis_for(m["title"], unit)
        elif key is None or custom_id(key) is not None:  # своя работа: по единице
            basis = {"м²": "floor", "пог.м": "perim"}.get(unit)
    if basis is None:
        return 1.0, False
    if g is None:   # замера ещё нет («Прайсы»): пока 1, после замера бот пересчитает сам
        return 1.0, True
    return calc.basis_qty(basis, g), True


def refresh_auto_qty(est: dict) -> None:
    """Замер поменяли: пересчитываем количество у строк, которые бот считал сам (поправленные вручную не трогаем)."""
    if est_geom(est) is None:
        return
    for l in est["lines"]:
        if l.get("auto"):
            l["qty"] = auto_qty(est, l.get("key"), l["unit"], l["title"], l.get("part"))[0]
    est.pop("result", None)


def scope_of(est: dict) -> Optional[int]:
    """Для какой части комнаты сейчас выбираем работы: None — для всей комнаты (так и бывает, если часть одна)."""
    mz = est.get("mz")
    n = len(calc.mz_parts(mz)) if mz else 1
    s = est.get("part")
    return s if n > 1 and s is not None and 0 <= s < n else None


def line_in_scope(l: dict, scope: Optional[int]) -> bool:
    return l.get("part") == scope


def list_items(uid: int, est: dict) -> list:
    """Общий список работ: [(ключ, название, единица, цена)]. Порядок не меняется при нажатии на галочку:
    ⬜ превращается в ✅ на той же строке.

    Фильтр est['flt']: q — слова поиска, th — номер темы прайса (кнопка «Из разделов» и раздел «Прайсы»).
    Без фильтра — весь список подряд."""
    flt = est.get("flt") or {}
    items = [it for it in all_items(uid) if it[0] not in catalog.CONSTRUCTOR_HIDDEN]
    if flt.get("q"):
        found = {it[0] for it in search_items(uid, flt["q"])[0]}
        items = [it for it in items if it[0] in found]
    if flt.get("th") is not None:
        names = theme_names(uid)
        theme = names[flt["th"]] if 0 <= flt["th"] < len(names) else None
        cmap = db.custom_theme_map(uid)
        items = [it for it in items if theme_of(it[0], cmap) == theme]
    return items


def theme_names(uid: int) -> list:
    """Темы прайса; «Другое» (редкие работы из прайсов фирм) появляется, когда в нём что-то есть. Свои разделы мастера
    тоже темы (если название совпало с готовой темой, например «Плитка», свои работы лежат вместе с ней);
    свои работы без раздела — «Мои работы»."""
    names = [t for t, _ in catalog.THEMES]
    if any(m["theme"] == "Другое" for m in market.items()):
        names.append("Другое")
    for s in db.list_sections(uid):
        name = "Мои работы" if s["id"] == 0 else s["name"]
        if name not in names:
            names.append(name)
    return names


def theme_of(key: str, cmap: Optional[dict] = None) -> str:
    """Тема работы: каталог — по списку тем, работа из прайсов фирм — своя тема, своя работа (c<номер>) — раздел мастера
    (cmap — db.custom_theme_map; без раздела — «Мои работы»)."""
    if custom_id(key) is not None:
        return (cmap or {}).get(key, "Мои работы")
    m = market.item(key)
    return m["theme"] if m else catalog.THEME_OF.get(key, "Другое")


async def show_extra(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    """Экран со списком строк: допработа по строкам или конструктор комнаты (общий список работ с галочками)."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    est = context.user_data["est"]
    d = est["id"]
    obj = db.get_object(uid, est["obj"])
    if est["type"] == "croom":
        if est.get("room") == "small":   # «Мелкие работы»: без замера, работы и количество напрямую
            await show_small(update, context, note)
            return
        if est.get("room") == "open" and not est.get("mz_done"):   # «Объект без стен»: сначала свой замер
            await show_open(update, context, note)
            return
        if "mz" not in est and est["lines"]:  # старая смета без замера: работы уже выбраны, замер не нужен
            est["mz"], est["mz_done"] = None, True
        if est.get("pm") and not est.get("pm_go") and not est.get("mz_done"):   # «Прайсы»: сначала темы и галочки
            await show_themes(update, context, note)
            return
        if not est.get("mz_done"):
            await show_measure(update, context, note)
            return
        await show_constructor(update, context, note)
        return
    text = (f"🧰 <b>Допработа</b> — объект «{esc(obj['name']) if obj else '—'}»\n"
            f"Основная смета не меняется: допработа считается отдельно.\n\n{note}{extra_lines_text(est, user)}")
    rows = [[Btn("🔍 Найти работу в прайсе", callback_data=f"xa:{d}:my")],
            [Btn("✍️ Добавить свою работу", callback_data=f"xa:{d}:own"),
             Btn("💰 Сумма вручную", callback_data=f"xa:{d}:sum")]]
    for i, l in enumerate(est["lines"]):
        rows.append([Btn(f"🗑 Убрать: {i + 1}. {l['title']}"[:55], callback_data=f"xa:{d}:del:{i}")])
    rows += hint_rows("\n".join(l["title"] for l in est["lines"]))
    n_own = sum(1 for l in est["lines"] if l.get("own"))   # свои работы, которых ещё нет в «Мои цены»
    if est["lines"]:
        # под списком: «Сохранить» (свои работы → «Мои цены», только если есть что сохранять), «Готово», «Изменить»
        bottom = []
        if n_own:
            bottom.append(Btn("💾 Сохранить" + (f" ({n_own})" if n_own > 1 else ""), callback_data=f"xa:{d}:keep"))
        bottom += [Btn("✅ Готово", callback_data=f"xa:{d}:fin"), Btn("✏️ Изменить", callback_data=f"xa:{d}:xl")]
        rows.append(bottom)
        if n_own:
            text += ("\n\n💾 «Сохранить» — запомнить свои работы в «Мои цены», чтобы находить их поиском. "
                     "✅ «Готово» — закончить допработу и сохранить её в объект.")
    rows.append([Btn("✖️ Отмена", callback_data=f"w:{d}:cancel")])
    await show(update, context, text, rows)


# --- Допработа по строкам: изменить строку (название, цену, количество) ---------------------
async def show_xline_list(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    """«Изменить»: допработы по порядку, нажмите на нужную."""
    est = context.user_data["est"]
    d = est["id"]
    if not est["lines"]:
        await show_extra(update, context, note)
        return
    # список текстом (ровно по левому краю), под ним кнопки с номерами: у кнопок Телеграма выравнивание не задаётся
    lines = [f"{i + 1}. {esc(cut_title(l['title'], len(est['lines'])))} — " + (f"сумма {fnum(l['price'])}" if l.get("unit") == "сумма"
                                                  else f"{fnum(l['qty'])} {esc(l['unit'])} × {fnum(l['price'])}")
             for i, l in enumerate(est["lines"])]
    rows = number_rows([Btn(str(i + 1), callback_data=f"xa:{d}:xi:{i}") for i in range(len(est["lines"]))])
    rows.append([Btn("⬅️ Назад", callback_data=f"xa:{d}:back")])
    await show(update, context, note + "✏️ <b>Какую строку изменить?</b>\nНажмите номер нужной. Можно поменять название, "
                                       "цену или количество, либо убрать строку.\n\n" + "\n".join(lines), rows)


async def show_xline_edit(update: Update, context: ContextTypes.DEFAULT_TYPE, i: int, note: str = "") -> None:
    est = context.user_data["est"]
    d = est["id"]
    if not 0 <= i < len(est["lines"]):
        await show_xline_list(update, context)
        return
    l = est["lines"][i]
    is_sum = l.get("unit") == "сумма"   # «сумма вручную»: количества нет, есть только сумма
    body = (f"Сумма: {fnum(l['price'])}" if is_sum else
            f"Количество: {fnum(l['qty'])} {esc(l['unit'])}\nЦена: {fnum(l['price'])} за {esc(l['unit'])}")
    first = [Btn("📝 Название", callback_data=f"xa:{d}:xt:{i}")]
    if not is_sum:
        first.append(Btn("🔢 Количество", callback_data=f"xa:{d}:xq:{i}"))
    first.append(Btn("💲 Сумма" if is_sum else "💲 Цена", callback_data=f"xa:{d}:xp:{i}"))
    await show(update, context, f"{note}✏️ <b>{i + 1}. {esc(l['title'])}</b>\n{body}",
               [first, [Btn("🗑 Убрать строку", callback_data=f"xa:{d}:xd:{i}")],
                [Btn("⬅️ К списку", callback_data=f"xa:{d}:xl")]])


async def ask_xline_value(update: Update, context: ContextTypes.DEFAULT_TYPE, i: int, what: str, note: str = "") -> None:
    """what: 'title' | 'qty' | 'price'. Ждём текст; «Отмена» возвращает к строке."""
    est = context.user_data["est"]
    d = est["id"]
    if not 0 <= i < len(est["lines"]):
        await show_xline_list(update, context)
        return
    l = est["lines"][i]
    ask = {"title": "Напишите новое название:",
           "qty": f"Сколько {esc(l['unit'])}? (числом)",
           "price": ("Напишите сумму числом:" if l.get("unit") == "сумма" else f"Цена за 1 {esc(l['unit'])} (числом):")}[what]
    await show(update, context, f"{note}✏️ <b>{esc(l['title'])}</b>\n{ask}",
               [[Btn("⬅️ Отмена", callback_data=f"xa:{d}:xi:{i}")]],
               await_input={"kind": f"x_e{what}", "d": d, "idx": i})


async def x_edit_line(update: Update, context: ContextTypes.DEFAULT_TYPE, p: list) -> None:
    """Кнопки «Изменить» допработы: xl — список, xi — строка, xt/xq/xp — что менять, xd — убрать."""
    est = context.user_data["est"]
    sub = p[1]
    i = int(p[2]) if len(p) > 2 else -1
    if sub == "xl":
        await show_xline_list(update, context)
    elif sub == "xi":
        await show_xline_edit(update, context, i)
    elif sub in ("xt", "xq", "xp"):
        await ask_xline_value(update, context, i, {"xt": "title", "xq": "qty", "xp": "price"}[sub])
    elif sub == "xd":
        if 0 <= i < len(est["lines"]):
            est["lines"].pop(i)
            est.pop("result", None)
        await show_xline_list(update, context, "🗑 Строка убрана.\n\n")


async def save_xline_value(update: Update, context: ContextTypes.DEFAULT_TYPE, kind: str, i: int, text: str) -> None:
    """Новое название, количество или цена строки допработы (текстом). Дальше — снова список строк."""
    est = context.user_data["est"]
    if not 0 <= i < len(est["lines"]):
        await show_xline_list(update, context)
        return
    l = est["lines"][i]
    what = kind[3:]
    if what == "title":
        title = text.strip()[:80]
        if not title:
            return
        l["title"] = title
    else:
        value = parse_number(text)
        if value is None or value < 0 or (what == "qty" and value <= 0):
            await ask_xline_value(update, context, i, what, "⚠️ Нужно число" + (" больше нуля" if what == "qty" else "")
                                  + ", например 1500.\n\n")
            return
        if what == "qty":
            l["qty"] = value
        else:
            l["price"] = value
            if l.get("unit") == "сумма":
                l["qty"] = 1
    est.pop("result", None)
    await show_xline_list(update, context, "✅ Строка изменена.\n\n")


async def show_constructor(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    """Конструктор комнаты: один общий список работ с галочками, отмеченные наверху."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    est = context.user_data["est"]
    d = est["id"]
    obj = db.get_object(uid, est["obj"])
    flt = est.setdefault("flt", {})
    where = f" — объект «{esc(obj['name'])}»" if obj else ""
    what = "Допработа: комната. " if est.get("kind") == "extra" else ""
    text = (f"{est['icon']} <b>{esc(est['room_name'])}</b> · конструктор{where}\n"
            f"{what}Комната считается по вашим работам и ценам. Напишите название работы, например розетка.\n")
    g = est_geom(est)
    scope = scope_of(est)
    if g and (g.get("parts") or g.get("open")):
        text += "\n📏 " + "\n".join(calc.geom_lines(g)) + "\n"
    elif g:
        ded = f", вычеты −{fnum(g['door_area'])}" if g["door_area"] else ""
        text += (f"\n📏 {fnum(g['len'])} × {fnum(g['wid'])} × {fnum(g['hei'])} м · пол {fnum(g['floor'])} м² · "
                 f"периметр {fnum(g['perim'])} м · стены {fnum(g['walls'])} м²{ded}\n")
    chosen = len(est["lines"])
    if chosen:
        total = sum(round(round(l["qty"], 2) * l["price"]) for l in est["lines"])
        text += f"✅ Выбрано работ: {chosen} · {money(user, total)}\n"
    scope_rows = []
    if g and g.get("parts"):   # у комнаты несколько частей: у каждой свои работы
        names = ["Вся комната"] + [p["name"] for p in g["parts"]]
        shown = names[0] if scope is None else g["parts"][scope]["name"]
        text += f"🎯 Работы выбираем для: <b>{esc(shown)}</b> (количество считается по этой части)\n"
        btns = []
        for i, nm in enumerate([None] + list(range(len(g["parts"])))):
            n_lines = sum(1 for l in est["lines"] if line_in_scope(l, nm))
            label = ("👉 " if nm == scope else "") + names[i][:18] + (f" ({n_lines})" if n_lines else "")
            btns.append(Btn(label, callback_data=f"xa:{d}:ps:{'a' if nm is None else nm}"))
        scope_rows = [btns[i:i + 3] for i in range(0, len(btns), 3)]
    if flt.get("q"):
        text += f"\n🔍 Поиск: «{esc(flt['q'])}»"
    elif flt.get("th") is not None:
        names = theme_names(uid)
        text += f"\n📂 Тема: {esc(names[flt['th']]) if flt['th'] < len(names) else '—'}"
    if note:
        text += f"\n{note}"

    filtered = bool(flt.get("q") or flt.get("th") is not None)
    keyless = [] if filtered else [(i, l) for i, l in enumerate(est["lines"])
                                   if not l.get("key") and line_in_scope(l, scope)]
    items = list_items(uid, est)
    lines_by_key = {l["key"]: l for l in est["lines"] if l.get("key") and line_in_scope(l, scope)}
    # (кнопка, подпись, название для подсказки, ключ, единица): сначала свои работы без ключа, дальше список в обычном порядке;
    # нажатие на ⬜ делает строку ✅ на том же месте
    entries = [(f"xa:{d}:tl:{i}", f"✅ {l['title']} · {fnum(l['qty'])} {l['unit']}", None, None, None)
               for i, l in keyless]
    for key, title, unit, price in items:
        line = lines_by_key.get(key)
        ms = market.stats(key, title, unit)
        rynok = f" · {market.short(ms)}" if ms else ""
        # название обрезаем так, чтобы подсказка «рынок …» уместилась в кнопку (60 знаков)
        if line:
            head, tail = "✅ ", f" · {fnum(line['qty'])} {unit}{rynok}"
        elif price <= 0:
            head, tail = "⬜ ⚠️ ", f", {unit}{rynok if ms else ' — цена не указана'}"
        else:
            head, tail = "⬜ ", f" — {fnum(price)}/{unit}{rynok}"
        room_left = max(60 - len(head) - len(tail), 12)
        shown = title if len(title) <= room_left else title[:room_left - 1] + "…"
        entries.append((f"xa:{d}:t:{key}", f"{head}{shown}{tail}", title, key, unit))
    pages = max(1, -(-len(entries) // PAGE_SIZE))
    flt["pg"] = min(flt.get("pg", 0), pages - 1)
    page = entries[flt["pg"] * PAGE_SIZE:(flt["pg"] + 1) * PAGE_SIZE]
    # работы списком текстом (по левому краю), под ним кнопки-номера: нажатие ⬜ ставит ✅ (и обратно) на том же месте
    first = flt["pg"] * PAGE_SIZE
    if page:
        text = text.rstrip() + "\n\n" + "\n".join(f"{first + k}. {esc(label)}" for k, (_cb, label, *_r) in enumerate(page, 1))
        text += "\nНажмите номер работы, чтобы отметить её ✅ или снять отметку."
    rows = scope_rows + number_rows([Btn(("✅" if label.startswith("✅") else "⬜") + str(first + k), callback_data=cb)
                                     for k, (cb, label, *_r) in enumerate(page, 1)])
    rows += hint_rows("\n".join(label for _cb, label, *_r in page))   # «Что это?» к словам из названий работ на странице
    # полная подсказка «по рынку» по каждой работе страницы (в кнопку она не помещается)
    hints = [f"• {esc(t[:55])} ({esc(u)}): {market.hint(market.stats(k, t, u))}" for _, _, t, k, u in page
             if t and market.stats(k, t, u)]
    if hints:
        text += "\n\n<b>Цены фирм Челябинска</b> (подсказка, в смету не входит):\n" + "\n".join(hints)
    pool_hints = [f"• {esc(t[:55])}: {h}" for _, _, t, k, u in page if t
                  for h in [pool.hint(t, u, user['currency'])] if h][:6]
    if pool_hints:   # общий прайс из загруженных смет: диапазон и среднее, только когда набралось не меньше 5 загрузок
        text += "\n\n<b>Общий прайс мастеров</b> (анонимно, подсказка):\n" + "\n".join(pool_hints)
    if not entries:
        text += "\n\nНичего не нашёл. Попробуйте другое слово или добавьте свою работу."
    if pages > 1:
        pg = flt["pg"]
        rows.append([Btn("⏮", callback_data=f"xa:{d}:pg:0"),
                     Btn("◀️", callback_data=f"xa:{d}:pg:{max(pg - 1, 0)}"),
                     Btn(f"{pg + 1} / {pages}", callback_data=f"xa:{d}:pg:{pg}"),
                     Btn("▶️", callback_data=f"xa:{d}:pg:{min(pg + 1, pages - 1)}"),
                     Btn("⏭", callback_data=f"xa:{d}:pg:{pages - 1}")])
    rows.append([Btn("🔍 Найти работу", callback_data=f"xa:{d}:my"), Btn("📂 Из разделов", callback_data=f"xa:{d}:grp")])
    rows.append([Btn("✍️ Добавить свою работу", callback_data=f"xa:{d}:own"),
                 Btn("📥 Загрузить прайс файлом", callback_data=f"xa:{d}:pf")])
    if filtered:
        rows.append([Btn("📋 Показать всё подряд", callback_data=f"xa:{d}:fx")])
    if est.get("pm"):   # «Прайсы»: из списка можно вернуться к темам
        rows.append([Btn("⬅️ К темам", callback_data=f"xa:{d}:grp")])
    n_pend = sum(1 for l in est["lines"] if l.get("pend"))
    if n_pend:  # новые работы и изменённые цены можно запомнить в «Мои цены»
        rows.append([Btn(f"💾 Сохранить в «Мои цены» ({n_pend})", callback_data=f"xa:{d}:keepl")])
    if est.get("og"):
        rows.append([Btn("📏 Изменить замер", callback_data=f"xa:{d}:op:redo")])
    elif est.get("mz"):
        rows.append([Btn("📏 Изменить замер", callback_data=f"xa:{d}:mz:redo")])
    if est["lines"]:
        rows.append([Btn(f"✅ {'Собрать смету' if est.get('pm') else 'Готово — посчитать'}", callback_data=f"xa:{d}:fin")])
    rows.append([Btn("✖️ Отмена", callback_data=f"w:{d}:cancel")])
    await show(update, context, text, rows, await_input={"kind": "x_search", "d": d})


async def show_themes(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    """Темы прайса (демонтаж, черновые, чистовые…): тема открывает тот же общий список, отфильтрованный по теме."""
    uid = update.effective_user.id
    est = context.user_data["est"]
    d = est["id"]
    names = theme_names(uid)
    scope = scope_of(est)
    chosen = {l.get("key") for l in est["lines"] if l.get("key") and line_in_scope(l, scope)}
    items = [it for it in all_items(uid) if it[0] not in catalog.CONSTRUCTOR_HIDDEN]
    rows = []
    cmap = db.custom_theme_map(uid)
    for i, name in enumerate(names):
        keys = [it[0] for it in items if theme_of(it[0], cmap) == name]
        n = sum(1 for k in keys if k in chosen)
        mark = f"✅ {name} · выбрано {n} из {len(keys)}" if n else f"⬜ {name} · работ: {len(keys)}"
        rows.append([Btn(mark[:60], callback_data=f"xa:{d}:g:{i}")])
    if est.get("pm"):
        text = ("📚 <b>Прайсы</b>\nВыберите тему, поставьте галочки на нужных услугах — я соберу из них смету. "
                "Количество посчитаю по замеру комнаты (или введёте вручную), в итоге его можно поправить.")
        if est["lines"]:
            rows.append([Btn(f"✅ Собрать смету (выбрано: {len(est['lines'])})", callback_data=f"xa:{d}:fin")])
        rows.append([Btn("📋 Весь список подряд", callback_data=f"xa:{d}:fx")])
        rows.append([Btn("✖️ Отмена", callback_data=f"w:{d}:cancel")])
    else:
        text = "📂 <b>Из разделов</b>\nВыберите тему прайса — покажу только её работы."
        rows.append([Btn("⬅️ Назад к списку", callback_data=f"xa:{d}:fx")])
    await show(update, context, note + text, rows, await_input={"kind": "x_search", "d": d})


# --- Замер комнаты одним экраном ----------------------------------------------------
MZ_FIELDS = ("len", "wid", "hei")
MZ_NAMES = {"len": "Длина", "wid": "Ширина", "hei": "Высота", "joint": "Стык"}
MZ_MAX_PARTS = 6                                 # основная часть и до пяти добавленных
OPEN_PASS_H = calc.DOOR_ROOM_H                   # высота открытого прохода, если написали одну ширину
NUM_RE = re.compile(r"\d+(?:[.,]\d+)?")


def mz_level(est: dict, field: str, value: float) -> str:
    """Необычно ли велик размер (пороги — в настройках dim_*); «своё помещение» (ангар, склад) — с другими порогами."""
    return dim_level(field, value, own=est.get("room") == "own")


def new_mz(bath: bool = False) -> dict:
    """Пустой замер: дверь (0,9 м) и окно (1,3×1,4 м) вычитаются сразу, размеры можно поменять кнопкой «Свой размер».
    Для ванной и туалета (bath=True): дверь 0,7 м, окно без галочки."""
    return {"len": None, "wid": None, "hei": None, "door": True,
            "door_w": calc.DOOR_STD_W if bath else calc.DOOR_ROOM_W, "door_h": calc.DOOR_ROOM_H,
            "win": not bath, "win_w": calc.WINDOW_STD_W, "win_h": calc.WINDOW_STD_H, "extra": [], "parts": []}


# --- «Объект без стен» (кусок 3) ---------------------------------------------------------
OPEN_LEN_MAX = 1000.0    # одна длина или площадь, м (больше — скорее опечатка)
OPEN_HEI_MAX = 30.0


def new_og() -> dict:
    return {"step": "q", "walls": None, "contour": [], "parts": [], "area": None, "area_auto": False, "hei": None,
            "beams": 0, "cols": 0, "openings": []}


async def start_open(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Режим «Объект без стен»: сначала «Есть несущие стены?», дальше свой замер, потом общий список работ."""
    ud = context.user_data
    obj, kind = ud.pop("cur_obj", None), ud.pop("cur_kind", None)
    est = new_draft(update, context, "croom", obj, kind or "main")
    est.update(room="open", room_name="Объект без стен", icon="🏗", lines=[], name="", mz=None, mz_done=False,
               flt={}, og=new_og())
    await show_open(update, context)


def og_rect_area(contour: list):
    """Контур из четырёх стен, где противоположные равны, — прямоугольник: площадь считаем сами (иначе None)."""
    if len(contour) == 4 and abs(contour[0] - contour[2]) < 0.005 and abs(contour[1] - contour[3]) < 0.005:
        return round(contour[0] * contour[1], 2)
    return None


async def show_open(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    """Экран замера «Объекта без стен»: один шаг за раз (og['step']), итог замера — на шаге sum."""
    user = db.get_user(update.effective_user.id)
    est = context.user_data["est"]
    d = est["id"]
    og = est.setdefault("og", new_og())
    step = og["step"]
    head = "🏗 <b>Объект без стен</b>\n"
    text_step = {"contour", "area", "parts", "hei", "bc", "opening"}
    rows = []
    if step == "q":
        text = head + "Есть несущие стены?\n<i>Несущие — те, что держат перекрытие. От ответа зависит, что мерить.</i>"
        rows = [[Btn("✅ Да", callback_data=f"xa:{d}:op:w:y"), Btn("⬜ Нет", callback_data=f"xa:{d}:op:w:n")]]
    elif step == "contour":
        c = og["contour"]
        text = (head + "📐 <b>Контур</b>\nИдите от входа вдоль стен и пишите длину каждой стены в метрах по порядку, "
                       "например <code>6 4 6 4</code> (можно по одной или сразу несколько).\n"
                + (f"\nУже записано: {' · '.join(fnum(x) for x in c)} (сумма {fnum(sum(c))} м)." if c else "")
                + "\nКогда обошли весь контур, нажмите «Контур замкнут».")
        if len(c) >= 3:
            rows.append([Btn("✅ Контур замкнут", callback_data=f"xa:{d}:op:cc")])
        if c:
            rows.append([Btn("⌫ Убрать последнюю", callback_data=f"xa:{d}:op:cu")])
    elif step == "area":
        text = head + "📐 <b>Площадь пола</b>, м²:\nНапишите число. Если контур не прямоугольный, возьмите площадь по плану."
    elif step == "parts":
        p = og["parts"]
        text = (head + "🧱 <b>Перегородки</b>\nПишите длину каждой внутренней перегородки в метрах (по одной или несколько "
                       "через пробел). Стены считаются с двух сторон.\n"
                + (f"\nУже записано: {' · '.join(fnum(x) for x in p)} (сумма {fnum(sum(p))} м)." if p else ""))
        rows.append([Btn("✅ Готово", callback_data=f"xa:{d}:op:pd")] if p else
                    [Btn("🚫 Перегородок нет", callback_data=f"xa:{d}:op:pn")])
        if p:
            rows.append([Btn("⌫ Убрать последнюю", callback_data=f"xa:{d}:op:pu")])
    elif step == "hei":
        text = head + "📏 <b>Высота потолка</b>, м:"
        rows.append([Btn(x, callback_data=f"xa:{d}:op:hv:{x.replace(',', '.')}") for x in ("2,5", "2,7", "3", "3,5", "4")])
    elif step == "bc":
        text = (head + "🏛 <b>Балки и колонны</b>\nНесущих стен нет, поэтому спрашиваю про балки и колонны. Напишите два числа: "
                       "сколько балок и сколько колонн, например <code>2 4</code>.")
        rows.append([Btn("🚫 Нет ни балок, ни колонн", callback_data=f"xa:{d}:op:bn")])
    elif step == "opening":
        text = (head + "🚪 <b>Проём</b>\nНапишите название, ширину и высоту, например: <code>ворота 3×3</code> или "
                       "<code>окно 1,5×1,4</code>. Площадь проёма уйдёт из стен.")
    else:   # sum: итог замера
        g = est_geom(est)
        text = head + "\n".join(calc.geom_lines(g)) if g else head + "Данных пока мало."
        text += "\n\n<i>Считается только работа (материалы в смете не учитываются).</i>"
        for i, o in enumerate(og["openings"]):
            text += f"\n• проём: {esc(o['name'])} {fnum(o['w'])}×{fnum(o['h'])} м"
        rows.append([Btn("🚪 Добавить проём", callback_data=f"xa:{d}:op:ao")])
        for i, o in enumerate(og["openings"]):
            rows.append([Btn(f"🗑 Убрать проём: {o['name']}"[:55], callback_data=f"xa:{d}:op:od:{i}")])
        rows.append([Btn("✅ Далее — к работам", callback_data=f"xa:{d}:op:ok")])
    if step != "q":
        rows.append([Btn("🔄 Начать замер сначала", callback_data=f"xa:{d}:op:reset")])
    rows.append([Btn("✖️ Отмена", callback_data=f"w:{d}:cancel")])
    if note:
        text = note + "\n\n" + text
    await show(update, context, text, rows, user=None,
               await_input={"kind": "op", "d": d, "field": step} if step in text_step else None)


def og_next(og: dict, after: str) -> str:
    """Какой шаг дальше. С несущими стенами: контур → площадь (если не прямоугольник) → перегородки → высота → итог.
    Без стен: площадь → высота → балки и колонны → итог."""
    y = og["walls"] == "y"
    order = (["contour", "area", "parts", "hei", "sum"] if y else ["area", "hei", "bc", "sum"])
    if after == "contour" and og.get("area"):   # прямоугольник: площадь уже посчитана
        return "parts"
    return order[order.index(after) + 1]


async def open_action(update: Update, context: ContextTypes.DEFAULT_TYPE, p: list) -> None:
    """Кнопки «Объекта без стен»: xa:<смета>:op:<что>[:<значение>]."""
    est = context.user_data["est"]
    og = est.setdefault("og", new_og())
    sub, arg = p[2], (p[3] if len(p) > 3 else "")
    est.pop("result", None)
    if sub == "w" and arg in ("y", "n"):
        og["walls"] = arg
        og["step"] = "contour" if arg == "y" else "area"
    elif sub == "cc" and og["step"] == "contour" and len(og["contour"]) >= 3:
        auto = og_rect_area(og["contour"])
        og["area"], og["area_auto"] = (auto, True) if auto else (None, False)
        og["step"] = og_next(og, "contour")
    elif sub == "cu" and og["contour"]:
        og["contour"].pop()
    elif sub == "pd" and og["step"] == "parts":
        og["step"] = og_next(og, "parts")
    elif sub == "pn" and og["step"] == "parts":
        og["parts"] = []
        og["step"] = og_next(og, "parts")
    elif sub == "pu" and og["parts"]:
        og["parts"].pop()
    elif sub == "hv" and og["step"] == "hei":
        og["hei"] = float(arg)
        og["step"] = og_next(og, "hei")
    elif sub == "bn" and og["step"] == "bc":
        og["beams"] = og["cols"] = 0
        og["step"] = og_next(og, "bc")
    elif sub == "ao":
        og["step"] = "opening"
    elif sub == "od" and arg.isdigit() and int(arg) < len(og["openings"]):
        og["openings"].pop(int(arg))
    elif sub == "reset":
        est["og"] = new_og()
        est["mz_done"] = False
    elif sub == "redo":
        est["mz_done"] = False
        og["step"] = "sum"
    elif sub == "ok" and og["step"] == "sum" and calc.open_geometry(og):
        est["mz_done"] = True
        refresh_auto_qty(est)
        await show_constructor(update, context)
        return
    await show_open(update, context)


async def open_input(update: Update, context: ContextTypes.DEFAULT_TYPE, field: str, text: str) -> None:
    """Текст на экране «Объекта без стен»: длины, площадь, высота, балки и колонны, проём."""
    est = context.user_data["est"]
    og = est.setdefault("og", new_og())
    if og["step"] != field:
        await show_open(update, context)
        return
    nums = find_numbers(text)
    bad = None
    if field in ("contour", "parts"):
        if not nums or any(not 0 < n <= OPEN_LEN_MAX for n in nums):
            bad = "Нужны длины в метрах числами больше нуля, например 6 4 6 4."
        else:
            og[field].extend(nums)
    elif field == "area":
        if not nums or not 0 < nums[0] <= OPEN_LEN_MAX * 10:
            bad = "Нужно число больше нуля, например 120."
        else:
            og["area"], og["area_auto"] = nums[0], False
            og["step"] = og_next(og, "area")
    elif field == "hei":
        if not nums or not 0 < nums[0] <= OPEN_HEI_MAX:
            bad = f"Нужно число больше нуля и не больше {fnum(OPEN_HEI_MAX)}, например 3,2."
        else:
            og["hei"] = nums[0]
            og["step"] = og_next(og, "hei")
    elif field == "bc":
        if len(nums) < 2 or any(n < 0 or n != int(n) or n > 1000 for n in nums[:2]):
            bad = "Нужно два целых числа: сколько балок и сколько колонн, например 2 4."
        else:
            og["beams"], og["cols"] = int(nums[0]), int(nums[1])
            og["step"] = og_next(og, "bc")
    elif field == "opening":
        name = NUM_RE.split(text)[0].strip(" ,.:;-×xх*") or "проём"
        if len(nums) < 2 or any(not 0 < n <= 50 for n in nums[:2]):
            bad = "Нужны название и два размера, например: ворота 3×3."
        else:
            og["openings"].append({"name": name[:30], "w": nums[0], "h": nums[1]})
            og["step"] = "sum"
    est.pop("result", None)
    await show_open(update, context, f"⚠️ {bad}" if bad else "")


def find_numbers(text: str) -> list:
    """Все числа из текста; запятая и точка одинаково: '4,5 x 3.2' -> [4.5, 3.2]."""
    return [float(x.replace(",", ".")) for x in NUM_RE.findall(text)]


def part_ref(mz: dict, idx: int) -> dict:
    """Словарь, где лежат размеры части: основная часть — сам замер, добавленные — mz['parts'][idx-1]."""
    return mz if idx == 0 else mz["parts"][idx - 1]


def part_name(mz: dict, idx: int) -> str:
    return calc.mz_parts(mz)[idx]["name"]


def active_part(est: dict) -> int:
    """Часть комнаты, которую сейчас меряем (0 — основная)."""
    mz = est.get("mz") or {}
    idx = est.get("mz_part") or 0
    return idx if 0 <= idx <= len(mz.get("parts") or []) else 0


def mz_fmt(v) -> str:
    return f"{fnum(v)} м" if v else "—"


def mz_value_of(buf: dict):
    """Число, которое сейчас набрано кнопками: метры (с «+10»), десятые, сотые."""
    base = buf["ip"] if buf["ip"] is not None else buf["plus"]
    return round(base + (buf["t"] or 0) / 10 + (buf["h"] or 0) / 100, 2)


def mz_stage(buf: dict) -> str:
    """Какая цифра вводится дальше: m — целые метры, t — десятые, h — сотые, '' — число набрано."""
    if buf["ip"] is None:
        return "m"
    if buf["t"] is None:
        return "t"
    return "h" if buf["h"] is None else ""


STAGE_NAME = {"m": "метры", "t": "десятые доли", "h": "сотые доли"}


def mz_field_now(est: dict):
    """Поле, которое меряем: выбранное кнопкой или первое пустое у текущей части. None — у части всё заполнено."""
    mz = est["mz"]
    ref = part_ref(mz, active_part(est))
    field = est.get("mz_field")
    if field in ("len", "wid", "hei", "joint", "door", "win", "extra", "open", "pname"):
        return field
    return next((f for f in MZ_FIELDS if not ref[f]), None)


def mz_buf_for(est: dict, field: str) -> dict:
    """Буфер набора цифр для поля текущей части (при смене части или поля начинаем набор заново)."""
    key = [active_part(est), field]
    buf = est.get("mz_buf")
    if not buf or buf.get("key") != key:
        buf = est["mz_buf"] = {"key": key, "plus": 0, "ip": None, "t": None, "h": None}
    return buf


def mz_geom_note(est: dict) -> str:
    """Что получилось по всей комнате (после ввода всех размеров)."""
    g = est_geom(est)
    if not g:
        return ""
    return (f"\n\nПол {fnum(g['floor'])} м² · периметр {fnum(g['perim'])} м · "
            f"стены {fnum(g['walls'])} м² (вычеты −{fnum(g['door_area'])} м²)")


async def show_measure(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    """Один экран замера: длина, ширина, высота цифрами-кнопками, части комнаты, вычеты (дверь, окно, свои проёмы)."""
    est = context.user_data["est"]
    d = est["id"]
    mz = est["mz"] = est.get("mz") or new_mz()
    mz.setdefault("parts", [])
    parts = calc.mz_parts(mz)
    ap = est["mz_part"] = active_part(est)
    ref = part_ref(mz, ap)
    field = mz_field_now(est)
    multi = len(parts) > 1
    mark = lambda f: "👉 " if field == f else ""
    head = f"{est['icon']} <b>{esc(est['room_name'])}</b> · замер"
    if multi:
        head += f"\n📐 Сейчас меряем: <b>{esc(parts[ap]['name'])}</b>"
    lines = [f"{mark(f)}{MZ_NAMES[f]}: <b>{mz_fmt(ref[f])}</b>" for f in MZ_FIELDS]
    if ap > 0:
        j = calc.part_joint({"len": ref["len"] or 0, "wid": ref["wid"] or 0, "joint": ref.get("joint")}) \
            if (ref["len"] and ref["wid"]) else None
        joint = "авто" if ref.get("joint") is None else "задан вручную"
        lines.append(f"{mark('joint')}Стык с основной частью: <b>{mz_fmt(j) if j is not None else '—'}</b> ({joint})")
    text = head + "\n" + "\n".join(lines)
    if multi:
        text += "\n\n<b>Части комнаты</b>"
        for i, p in enumerate(parts):
            sizes = " × ".join(fnum(p[k]) if p[k] else "—" for k in MZ_FIELDS)
            text += f"\n• {esc(p['name'])}: {sizes} м"
        text += ("\n<i>Стык — общая граница части с основной: на нём стен нет (коридор «Г», ниша, эркер, "
                 "бывший балкон). Пол и стены считаются по сумме частей.</i>")
    text += ("\n\n<b>Вычеты из площади стен</b>\n"
             f"{'✅' if mz['door'] else '⬜'} Дверь {fnum(mz['door_w'])}×{fnum(mz['door_h'])} м\n"
             f"{'✅' if mz['win'] else '⬜'} Окно {fnum(mz['win_w'])}×{fnum(mz['win_h'])} м")
    for e in mz["extra"]:
        where = f" ({esc(parts[e.get('part', 0)]['name'])})" if multi and e.get("part", 0) < len(parts) else ""
        no_plinth = " · плинтуса нет" if e.get("open") else ""
        text += f"\n• {esc(e['name'])} {fnum(e['w'])}×{fnum(e['h'])} м{where}{no_plinth}"
    text += mz_geom_note(est)
    buf = None
    if field in ("len", "wid", "hei", "joint"):
        buf = mz_buf_for(est, field)
        st = mz_stage(buf)
        shown = mz_value_of(buf) if (buf["ip"] is not None or buf["plus"]) else None
        text += (f"\n\n🔢 <b>{MZ_NAMES[field]}</b>: {mz_fmt(shown) if shown is not None else '—'}"
                 + (f" · нажмите цифру: {STAGE_NAME[st]}" if st else " · число набрано")
                 + "\nЦифры кнопками или число текстом (запятая или точка). Можно сразу три числа: "
                   "<code>4,5 3,2 2,7</code>.")
    elif field in ("door", "win"):
        text += f"\n\n✍️ Напишите ширину и высоту {'двери' if field == 'door' else 'окна'}, например 0,9×2,1"
    elif field == "extra":
        text += "\n\n✍️ Напишите название и размеры, например: арка 1,5×2,2 или ниша 0,5×1,2"
    elif field == "open":
        text += (f"\n\n✍️ Открытый проход — там, где нет двери (арка, проём в другую комнату). Напишите ширину и высоту, "
                 f"например 0,9×2,1. Если написать одну ширину, высоту возьму {fnum(OPEN_PASS_H)} м. "
                 "Площадь уйдёт из стен, а плинтус в проходе не считается.")
    elif field == "pname":
        text += "\n\n✍️ Напишите название части, например: коридор, балкон, ниша"
    elif field is None:
        text += "\n\nРазмеры этой части заданы. Нажмите на размер, чтобы поправить."
    if note:
        text = note + "\n\n" + text

    rows = []
    if multi:   # вкладки частей
        tabs = [Btn(("👉 " if i == ap else "") + p["name"][:16], callback_data=f"xa:{d}:mz:ap:{i}")
                for i, p in enumerate(parts)]
        for i in range(0, len(tabs), 3):
            rows.append(tabs[i:i + 3])
    rows.append([Btn(f"📏 {MZ_NAMES[f]}: {mz_fmt(ref[f])}", callback_data=f"xa:{d}:mz:f:{f}") for f in MZ_FIELDS])
    if buf is not None:   # цифры: целые метры 1–9, потом десятые и сотые — на этом же экране
        st = mz_stage(buf)
        if st:
            labels = {"m": [str(i) for i in range(1, 10)] + ["0"],
                      "t": [f"0,{i}" for i in range(1, 10)] + ["0,0"],
                      "h": [f"0,0{i}" for i in range(1, 10)] + ["0,00"]}[st]
            digits = [1, 2, 3, 4, 5, 6, 7, 8, 9, 0]
            for i in range(0, 10, 5):
                rows.append([Btn(labels[j], callback_data=f"xa:{d}:mz:k:{digits[j]}") for j in range(i, i + 5)])
        ctl = []
        if st == "m":
            ctl.append(Btn("➕10 м", callback_data=f"xa:{d}:mz:k:p"))
        ctl.append(Btn("⌫ Стереть", callback_data=f"xa:{d}:mz:k:b"))
        if st:
            ctl.append(Btn("▶ Дальше", callback_data=f"xa:{d}:mz:k:n"))
        rows.append(ctl)
    if ap > 0:
        rows.append([Btn("🔗 Стык с основной", callback_data=f"xa:{d}:mz:f:joint"),
                     Btn("✏️ Название части", callback_data=f"xa:{d}:mz:f:pname"),
                     Btn("🗑 Убрать часть", callback_data=f"xa:{d}:mz:rp")])
    if len(parts) < MZ_MAX_PARTS:
        rows.append([Btn("➕ Добавить часть комнаты", callback_data=f"xa:{d}:mz:addp")])
    rows += [[Btn(f"{'✅' if mz['door'] else '⬜'} Вычитать дверь {fnum(mz['door_w'])}×{fnum(mz['door_h'])}",
                  callback_data=f"xa:{d}:mz:t:door"),
              Btn("✏️ Свой размер", callback_data=f"xa:{d}:mz:f:door")],
             [Btn(f"{'✅' if mz['win'] else '⬜'} Вычитать окно {fnum(mz['win_w'])}×{fnum(mz['win_h'])}",
                  callback_data=f"xa:{d}:mz:t:win"),
              Btn("✏️ Свой размер", callback_data=f"xa:{d}:mz:f:win")],
             [Btn("➕ Добавить вычет", callback_data=f"xa:{d}:mz:f:extra"),
              Btn("🚪 Открытый проход", callback_data=f"xa:{d}:mz:f:open")],
             [Btn("❓ Что это: проём", callback_data="hint:opening")]]
    for i, e in enumerate(mz["extra"]):
        rows.append([Btn(f"🗑 Убрать вычет: {e['name']}"[:55], callback_data=f"xa:{d}:mz:del:{i}")])
    if calc.mz_complete(mz):
        rows.append([Btn("✅ Посчитать" if est.get("pm") else "✅ Далее — к работам", callback_data=f"xa:{d}:mz:ok")])
    elif multi:
        rows.append([Btn("ℹ️ Заполните размеры всех частей, чтобы идти дальше", callback_data=f"xa:{d}:mz:hint")])
    if est.get("pm"):
        rows.append([Btn("Без замера — количество вручную", callback_data=f"xa:{d}:mz:skip")])
    rows.append([Btn("✖️ Отмена", callback_data=f"w:{d}:cancel")])
    await show(update, context, text, rows,
               await_input={"kind": "mz", "d": d, "field": field or "len"})


def mz_next_field(est: dict) -> None:
    """После набранного числа переходим к следующему пустому размеру этой же части."""
    ref = part_ref(est["mz"], active_part(est))
    est["mz_field"] = next((f for f in MZ_FIELDS if not ref[f]), None)
    est["mz_buf"] = None


def mz_set_value(est: dict, field: str, value) -> None:
    ref = part_ref(est["mz"], active_part(est))
    if field == "joint":
        ref["joint"] = value if value and value > 0 else (0.0 if value == 0 else None)
    else:
        ref[field] = value if value and value > 0 else None
    est.pop("result", None)


def mz_key(est: dict, k: str) -> None:
    """Нажата кнопка ввода цифрами: k — цифра, p (+10 м), b (стереть), n (дальше)."""
    field = mz_field_now(est)
    if field not in ("len", "wid", "hei", "joint"):
        return
    est["mz_field"] = field            # пока число набирается, поле не «убегает» к следующему пустому
    buf = mz_buf_for(est, field)
    if k == "n":                       # оставить набранное как есть и перейти к следующему размеру
        mz_next_field(est)
        return
    if k == "p":
        if buf["ip"] is None and buf["plus"] < 190:
            buf["plus"] += 10
    elif k == "b":
        for slot in ("h", "t", "ip"):
            if buf[slot] is not None:
                buf[slot] = None
                break
        else:
            buf["plus"] = max(buf["plus"] - 10, 0)
    elif k.isdigit():
        n = int(k)
        st = mz_stage(buf)
        if st == "m":
            buf["ip"] = buf["plus"] + n
        elif st == "t":
            buf["t"] = n
        elif st == "h":
            buf["h"] = n
    set_to = mz_value_of(buf) if (buf["ip"] is not None or buf["plus"]) else None
    mz_set_value(est, field, set_to)
    if mz_stage(buf) == "":    # число набрано — идём к следующему размеру
        mz_next_field(est)


async def mz_input(update: Update, context: ContextTypes.DEFAULT_TYPE, field: str, text: str) -> None:
    """Текст на экране замера: числа для выбранного поля (или сразу три), размеры двери/окна, свой вычет, название части."""
    est = context.user_data["est"]
    mz = est["mz"]
    ap = active_part(est)
    nums = find_numbers(text)
    if field in ("door", "win"):
        if not nums or any(not 0 < n <= 10 for n in nums[:2]):
            await show_measure(update, context, "⚠️ Не понял размеры. Напишите ширину и высоту, например 0,9×2,1.")
            return
        mz[f"{field}_w"] = nums[0]
        mz[f"{field}_h"] = nums[1] if len(nums) > 1 else mz[f"{field}_h"]
        mz[field] = True
        est["mz_field"] = None
    elif field == "extra":
        name = NUM_RE.split(text)[0].strip(" ,.:;-×xх*") or "Вычет"
        if len(nums) < 2 or any(not 0 < n <= 10 for n in nums[:2]):
            await show_measure(update, context, "⚠️ Нужны название и два размера, например: ниша 0,5×1,2.")
            return
        mz["extra"].append({"name": name[:30], "w": nums[0], "h": nums[1], "part": ap})
        est["mz_field"] = None
    elif field == "open":
        if not nums or any(not 0 < n <= 10 for n in nums[:2]):
            await show_measure(update, context, "⚠️ Не понял размеры. Напишите ширину и высоту прохода, например 0,9×2,1.")
            return
        mz["extra"].append({"name": "открытый проход", "w": nums[0], "h": nums[1] if len(nums) > 1 else OPEN_PASS_H,
                            "part": ap, "open": True})
        est["mz_field"] = None
        est.pop("result", None)
    elif field == "pname":
        name = text.strip()[:30]
        if not name:
            return
        if ap == 0:
            mz["name0"] = name
        else:
            mz["parts"][ap - 1]["name"] = name
        est["mz_field"] = None
        est.pop("result", None)
    elif field == "joint":
        if not nums or not 0 <= nums[0] <= 200:
            await show_measure(update, context, "⚠️ Не понял число. Напишите длину стыка в метрах, например 1,2 (0 — стен нет вообще).")
            return
        mz_set_value(est, "joint", nums[0])
        est["mz_field"] = None
    else:
        if not nums or any(not 0 < n <= 1000 for n in nums):
            await show_measure(update, context, "⚠️ Не понял число. Напишите размер в метрах, например 3,2.")
            return
        start = MZ_FIELDS.index(field)
        assigned = {MZ_FIELDS[start + i]: n for i, n in enumerate(nums[:len(MZ_FIELDS) - start])}
        big = next(((f, v) for f, v in assigned.items() if mz_level(est, f, v)), None)
        if big:  # необычно большое число — не запрещаем, а переспросим, вдруг это опечатка
            est["mz_pending"] = {"vals": assigned, "ask": big[0]}
            await show_mz_confirm(update, context)
            return
        part_ref(mz, ap).update(assigned)
        est["mz_field"] = None
        est.pop("result", None)
    est["mz_buf"] = None
    await show_measure(update, context)


async def show_mz_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    est = context.user_data["est"]
    d = est["id"]
    pend = est["mz_pending"]
    value = pend["vals"][pend["ask"]]
    await show(update, context, dim_confirm_text(pend["ask"], value, "ask"),
               [[Btn("✅ Да, верно", callback_data=f"xa:{d}:mz:yes"), Btn("✏️ Исправить", callback_data=f"xa:{d}:mz:fix")]])


def mz_remove_part(est: dict, idx: int) -> None:
    """Убирает добавленную часть: её работы и вычеты уходят вместе с ней, номера остальных частей сдвигаются."""
    mz = est["mz"]
    mz["parts"].pop(idx - 1)
    mz["extra"] = [e for e in mz["extra"] if e.get("part", 0) != idx]
    for e in mz["extra"]:
        if e.get("part", 0) > idx:
            e["part"] -= 1
    est["lines"] = [l for l in est["lines"] if l.get("part") != idx]
    for l in est["lines"]:
        if l.get("part") is not None and l["part"] > idx:
            l["part"] -= 1
    est["part"] = None
    est["mz_part"], est["mz_field"], est["mz_buf"] = 0, None, None
    est.pop("result", None)


async def mz_action(update: Update, context: ContextTypes.DEFAULT_TYPE, p: list) -> None:
    """Кнопки экрана замера: xa:<смета>:mz:f:<поле> | k:<цифра> | t:door|win | del:<номер> | ap:<часть> | addp | rp | ok | redo."""
    est = context.user_data["est"]
    mz = est["mz"] = est.get("mz") or new_mz()
    mz.setdefault("parts", [])
    sub = p[2]
    note = ""
    if sub == "f" and p[3] in MZ_FIELDS + ("door", "win", "extra", "open", "joint", "pname"):
        if p[3] in ("joint", "pname") and active_part(est) == 0:
            p[3] = "len"
        est["mz_field"], est["mz_buf"] = p[3], None
    elif sub == "k":
        mz_key(est, p[3])
    elif sub == "t" and p[3] in ("door", "win"):
        mz[p[3]] = not mz[p[3]]
        est.pop("result", None)
    elif sub == "del" and 0 <= int(p[3]) < len(mz["extra"]):
        mz["extra"].pop(int(p[3]))
        est.pop("result", None)
    elif sub == "ap" and 0 <= int(p[3]) <= len(mz["parts"]):
        est["mz_part"], est["mz_field"], est["mz_buf"] = int(p[3]), None, None
    elif sub == "addp" and len(mz["parts"]) + 1 < MZ_MAX_PARTS:
        mz["parts"].append({"name": f"Часть {len(mz['parts']) + 2}", "len": None, "wid": None,
                            "hei": mz.get("hei"), "joint": None})
        est["mz_part"], est["mz_field"], est["mz_buf"] = len(mz["parts"]), None, None
        est.pop("result", None)
        note = "➕ Часть добавлена. Задайте её длину и ширину; высота взята как у основной, её можно поменять."
    elif sub == "rp" and active_part(est) > 0:
        gone = part_name(mz, active_part(est))
        mz_remove_part(est, active_part(est))
        note = f"🗑 Часть «{esc(gone)}» убрана."
    elif sub == "hint":
        note = "ℹ️ У каждой части должны быть длина, ширина и высота. Заполните их или уберите лишнюю часть."
    elif sub == "yes" and est.get("mz_pending"):
        part_ref(mz, active_part(est)).update(est.pop("mz_pending")["vals"])
        est["mz_field"], est["mz_buf"] = None, None
        est.pop("result", None)
    elif sub == "fix" and est.get("mz_pending"):
        est["mz_field"] = est.pop("mz_pending")["ask"]
    elif sub == "ok" and est_geom(est):
        est["mz_done"] = True
        est["mz_buf"] = None
        refresh_auto_qty(est)
        if est.get("pm"):   # «Прайсы»: работы уже выбраны, сразу считаем
            await croom_finish(update, context)
        else:
            await show_constructor(update, context)
        return
    elif sub == "skip" and est.get("pm"):   # без замера: количество везде 1, поправить можно в итоге
        est["mz_done"] = True
        await croom_finish(update, context)
        return
    elif sub == "redo":
        est["mz_done"] = False
        est["mz_field"], est["mz_buf"] = None, None
    await show_measure(update, context, note)


async def x_similar(update: Update, context: ContextTypes.DEFAULT_TYPE, title: str) -> bool:
    """Свою работу назвали: подсказываем похожие из базы (по нажатию подставятся единица и цена).
    False — похожих нет, продолжаем обычный ввод."""
    uid = update.effective_user.id
    est = context.user_data["est"]
    d = est["id"]
    found = [it for it in search_items(uid, title)[0] if it[0] not in catalog.CONSTRUCTOR_HIDDEN][:5]
    if not found:
        return False
    rows = item_number_rows(d, found)
    rows.append([Btn(f"✍️ Нет, «{title}» — новая работа"[:55], callback_data=f"xa:{d}:nu")])
    rows.append([Btn("⬅️ Назад", callback_data=f"xa:{d}:sb")] + x_cancel(est))
    await show(update, context, f"🔎 Похоже на работы из вашей базы:\n\n{item_lines_text(found)}\n\n"
                                f"Нажмите номер подходящей — подставлю единицу и цену. "
                                f"Если такой нет, добавьте «{esc(title)}» как новую.", rows,
               await_input={"kind": "x_title", "d": d})
    return True


async def x_ask(update: Update, context: ContextTypes.DEFAULT_TYPE, stage: str, note: str = "") -> None:
    """Шаги ввода строки допработы: title → unit → price → qty (или amount, name)."""
    est = context.user_data["est"]
    d = est["id"]
    tmp = est["tmp"]
    rows: list = []
    if stage == "title":
        text = "✍️ Напишите название работы:"
        if tmp.get("query"):  # пришли из поиска: можно взять слово из поиска как название
            rows.append([Btn(f"Название: {tmp['query'].capitalize()}"[:55], callback_data=f"xa:{d}:tq")])
        if est["type"] == "croom" and tmp.get("own"):   # свой прайс можно загрузить сразу файлом, вместо работ по одной
            text += "\nИли загрузите сразу много своих работ файлом Excel."
            rows.append([Btn("📥 Загрузить прайс файлом", callback_data=f"xa:{d}:pfx")])
    elif stage == "unit":
        text = f"✍️ <b>{esc(tmp['title'])}</b>\nВ чём считаем? Нажмите кнопку или напишите свою единицу."
        codes = list(UNITS)
        for i in range(0, len(codes), 3):
            rows.append([Btn(UNITS[c], callback_data=f"xa:{d}:u:{c}") for c in codes[i:i + 3]])
    elif stage == "price":
        text = f"✍️ <b>{esc(tmp['title'])}</b>\nЦена за 1 {esc(tmp['unit'])} (числом):"
        if est["type"] == "croom" and tmp.get("orig"):
            text += f"\nСейчас в «Мои цены»: {fnum(tmp['orig'])}."
        ph = pool.hint(tmp["title"], tmp["unit"], db.get_user(update.effective_user.id)["currency"])
        if ph:
            text += f"\n💡 {ph}"
    elif stage == "qty":
        text = f"✍️ <b>{esc(tmp['title'])}</b>\nСколько {esc(tmp['unit'])}? (числом)"
        g = est_geom(est, scope_of(est)) if est["type"] == "croom" else None
        quick = [Btn("1", callback_data=f"xa:{d}:q:1")]
        if g and tmp["unit"] == "м²":   # площадь можно взять из замера одной кнопкой
            quick += [Btn(f"Пол {fnum(g['floor'])}", callback_data=f"xa:{d}:q:{g['floor']:g}"),
                      Btn(f"Стены {fnum(g['walls'])}", callback_data=f"xa:{d}:q:{g['walls']:g}")]
        elif g and tmp["unit"] == "пог.м":
            quick.append(Btn(f"Периметр {fnum(g['perim'])}", callback_data=f"xa:{d}:q:{g['perim']:g}"))
        if g and g.get("open") and tmp["unit"] == "шт":   # «Объект без стен»: число балок и колонн одной кнопкой
            if g["beams"]:
                quick.append(Btn(f"Балок {g['beams']}", callback_data=f"xa:{d}:q:{g['beams']}"))
            if g["cols"]:
                quick.append(Btn(f"Колонн {g['cols']}", callback_data=f"xa:{d}:q:{g['cols']}"))
        rows.append(quick)
        if est.get("room") == "small":   # «Мелкие работы»: единица из прайса, её можно переключить
            text += f"\nЕдиница из прайса: {esc(tmp['unit'])}. Если считаете по-другому, переключите."
            rows.append([Btn(f"🔁 Единица: {tmp['unit']}", callback_data=f"xa:{d}:uc")])
        if est["type"] == "croom":  # цену можно поменять: подставленная из «Мои цены» или только что введённая
            src = " (из «Мои цены»)" if tmp.get("key") and tmp["price"] == tmp.get("orig") else ""
            text += f"\nЦена: {fnum(tmp['price'])} за 1 {esc(tmp['unit'])}{src}."
            rows.append([Btn("💲 Изменить цену", callback_data=f"xa:{d}:pe")])
    elif stage == "amount":
        text = f"💰 <b>{esc(tmp['title'])}</b>\nНапишите сумму числом:"
    else:  # name
        text = "✅ Как назвать эту допработу? Напишите название или нажмите кнопку."
        rows.append([Btn("Допработы", callback_data=f"xa:{d}:name")])
    if est["type"] == "croom":
        rows.append([Btn("⬅️ Назад", callback_data=f"xa:{d}:sb")] + x_cancel(est))
    else:
        rows.append([Btn("⬅️ Назад", callback_data=f"xa:{d}:back")])
    await show(update, context, note + text, rows, await_input={"kind": "x_" + stage, "d": d})


async def x_step_back(update: Update, context: ContextTypes.DEFAULT_TYPE, stage: str) -> None:
    """Конструктор комнаты, кнопка «Назад» на шаге ввода: на один шаг назад, с первого — туда, откуда пришли."""
    est = context.user_data["est"]
    tmp = est["tmp"]
    if stage == "price" and tmp.get("pe"):  # цену меняли с экрана количества — возвращаемся к нему
        tmp.pop("pe")
        await x_ask(update, context, "qty")
        return
    if tmp.get("own"):  # своя работа: название → единица → цена → количество
        prev = {"unit": "title", "price": "unit", "qty": "price"}.get(stage)
        if prev:
            await x_ask(update, context, prev)
        else:
            est["tmp"] = {}
            await show_extra(update, context)
        return
    if "title" not in tmp:  # шаг уже неактуален
        est["tmp"] = {}
        await show_extra(update, context)
        return
    src, query = tmp.get("from"), tmp.get("query")  # работа из прайса: назад — к списку, где её выбрали
    est["tmp"] = {}
    if src:
        await x_action(update, context, ["xa", "g", src])
    else:
        await x_search(update, context, query or None)


async def x_add_line(update: Update, context: ContextTypes.DEFAULT_TYPE, qty: float) -> None:
    est = context.user_data["est"]
    tmp = est["tmp"]
    line = {"title": tmp["title"], "unit": tmp["unit"], "price": tmp["price"], "qty": qty}
    note = "✅ Строка добавлена.\n\n"
    if est["type"] == "croom":
        # ключ прайса нужен, чтобы плитка попала в «Плиточника», а цена — в нужный раздел «Мои цены»
        key = tmp.get("key")
        line["key"] = key
        scope = scope_of(est)
        line["part"] = scope
        if key and market.item(key):
            line["section"] = market.SECTION_OF_THEME.get(market.item(key)["theme"], "custom")
        line["pend"] = bool(tmp.get("own") or (key and tmp["price"] != tmp.get("orig")))
        est.pop("result", None)  # состав работ изменился: прежний расчёт устарел
        est["flt"] = {}          # новая работа должна быть видна в общем списке
        # у работы из прайса уже могла быть строка: количество тогда просто заменяется введённым
        est["lines"] = [l for l in est["lines"] if not (key and l.get("key") == key and line_in_scope(l, scope))]
        note = "✅ Работа добавлена."
        if line["pend"]:
            note += " 💡 Новую работу или цену можно сохранить в «Мои цены» кнопкой ниже."
    else:
        # своя работа (не из прайса) — пометим, чтобы кнопка «Сохранить» запомнила её в «Мои цены»
        if tmp.get("own") and tmp.get("unit") != "сумма":
            line["own"] = True
    est["lines"].append(line)
    est["tmp"] = {}
    await show_extra(update, context, note)


async def x_finish(update: Update, context: ContextTypes.DEFAULT_TYPE, name: str) -> None:
    est = context.user_data["est"]
    est["name"] = name
    est["result"] = calc.build_extra(name, est["lines"])
    est["result"]["currency"] = db.get_user(update.effective_user.id)["currency"]
    obj = est["obj"]
    if obj and db.get_object(update.effective_user.id, obj):
        await save_current(update, context, obj)
    else:
        await ask_where_to_save(update, context)


async def croom_finish(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    """Конструктор комнаты: считаем смету по выбранным работам и показываем итог."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    est = context.user_data["est"]
    if not est["lines"]:
        await show_extra(update, context)
        return
    est["result"] = croom_result(est, user)
    await show_croom_result(update, context, note)


def croom_result(est: dict, user) -> dict:
    """Результат комнаты из конструктора по выбранным работам, с наценкой и скидкой сметы."""
    result = calc.build_custom_room(est["room_name"], est["icon"], est["lines"], min_for(user, est),
                                    apply_min=est.get("kind") != "extra", geom=est_geom(est))
    result = mark_days(adjusted(result, est, user), user, est)
    result["currency"] = user["currency"]
    return result


# --- Минимум по дням (кусок 3) ----------------------------------------------------------
DAYS_MAX = 365


def days_button(est: dict, user):
    """Кнопка «Дней работы» на итоге: только если у мастера включён «Минимум по дням» и задана сумма за день."""
    if not (user["day_min_on"] and (user["day_rate"] or 0) > 0):
        return None
    days = est.get("days")
    label = f"📅 Дней работы: {fnum(days)}" if days else "📅 Указать дни работы (минимум по дням)"
    return [Btn(label, callback_data=f"dy:{est['id']}:ask")]


async def dy_action(update: Update, context: ContextTypes.DEFAULT_TYPE, p: list) -> None:
    """Кнопки дней работы: dy:<смета>:ask | n:<число дней> (0 — без минимума по дням)."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    est = context.user_data["est"]
    d = est["id"]
    sub = p[1]
    if est.get("kind") == "extra":
        return
    if sub == "ask":
        rate = user["day_rate"] or 0
        quick = [Btn(str(n), callback_data=f"dy:{d}:n:{n}") for n in (1, 2, 3, 5, 7, 10)]
        await show(update, context,
                   f"📅 <b>Дней работы</b>\nМинимум заказа: {money(user, rate)} за день. Один день — {money(user, rate)}, "
                   f"два — {money(user, rate * 2)}, от трёх дней умножается на число дней. Если смета получится "
                   "дешевле, итог поднимется до минимума (не прибавится к нему).\n\n"
                   f"Сейчас дней: <b>{fnum(est['days']) if est.get('days') else 'не указано'}</b>. "
                   "Нажмите число или напишите его (можно 1,5).",
                   [quick[:3], quick[3:], [Btn("🚫 Без минимума по дням", callback_data=f"dy:{d}:n:0")],
                    [Btn("⬅️ К смете", callback_data=f"adj:{d}:res")]], user=user,
                   await_input={"kind": "days", "d": d})
    elif sub == "n" and len(p) > 2:
        await dy_set(update, context, float(p[2]))


async def dy_set(update: Update, context: ContextTypes.DEFAULT_TYPE, value: float) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    est = context.user_data["est"]
    est["days"] = round(value, 1) if value > 0 else None
    context.user_data["await"] = None
    adj_rebuild(est, uid, user)
    if est.get("type") == "croom":
        await show_croom_result(update, context)
    else:
        await show_result(update, context)


# --- Наценка и скидка (кусок 3) ---------------------------------------------------------
ADJ_MAX = {"markup": 100.0, "discount": 50.0}


def adj_of(est: dict) -> dict:
    return est.setdefault("adj", {"markup": 0, "discount": 0, "discount_on": True})


def adj_button(est: dict) -> list:
    """Кнопка на итоговом экране: что сейчас стоит, видно по подписи."""
    a = est.get("adj") or {}
    now = []
    if a.get("markup"):
        now.append(f"наценка {fnum(a['markup'])}%")
    if a.get("discount") and a.get("discount_on", True):
        now.append(f"скидка {fnum(a['discount'])}%")
    return [Btn("🏷 Наценка и скидка" + (f" ({', '.join(now)})" if now else ""), callback_data=f"adj:{est['id']}:open")]


def adj_rebuild(est: dict, uid: int, user) -> None:
    """Пересчитывает итог сметы с учётом наценки и скидки (старые сохранённые сметы это не затрагивает)."""
    if est.get("type") == "croom":
        est["result"] = croom_result(est, user)
    else:
        recalc(est, uid, user)


async def show_adjust(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    user = db.get_user(update.effective_user.id)
    est = context.user_data["est"]
    d = est["id"]
    a = adj_of(est)
    mk, ds, on = a["markup"], a["discount"], a.get("discount_on", True)
    text = (note + "\n\n" if note else "") + "🏷 <b>Наценка и скидка</b>\n\n"
    text += (f"Наценка: <b>{fnum(mk)}%</b>" + (" — уже вшита в цены строк, клиент её не видит" if mk else "") + "\n")
    text += (f"Скидка: <b>{fnum(ds)}%</b>" + (" — отдельной строкой в смете" if ds and on else
                                              " — отключена" if ds else "") + "\n\n")
    text += ("<i>Наценка вшивается в цены строк, поэтому клиент видит просто цену. Скидка показывается отдельной "
             "строкой и считается от суммы с наценкой. Минимальная сумма выезда проверяется после скидки. "
             "Это действует только на эту смету.</i>")
    rows = [[Btn("➕ Наценка, %", callback_data=f"adj:{d}:mk"), Btn("➖ Скидка, %", callback_data=f"adj:{d}:ds")]]
    if ds:
        rows.append([Btn("✅ Скидка включена" if on else "⬜ Скидка отключена", callback_data=f"adj:{d}:tg")])
    if mk and a.get("ask") == "later":
        rows.append([Btn(f"⬆️ Поднять и мои цены на {fnum(mk)}%", callback_data=f"adj:{d}:askup")])
    if mk or ds:
        rows.append([Btn("🧹 Убрать наценку и скидку", callback_data=f"adj:{d}:reset")])
    rows.append([Btn("📄 К смете", callback_data=f"adj:{d}:res")])
    await show(update, context, text, rows, user=user)


async def show_adjust_ask(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """После наценки: «Поднять и ваши цены?» — Да, только для этого объекта, решить позже."""
    user = db.get_user(update.effective_user.id)
    est = context.user_data["est"]
    d = est["id"]
    mk = adj_of(est)["markup"]
    await show(update, context,
               f"💬 <b>Поднять и ваши цены?</b>\nНаценка {fnum(mk)}% вшита в эту смету. Хотите поднять на {fnum(mk)}% и "
               "свои цены в «Мои цены», чтобы следующие сметы считались так же?\n\n"
               "<i>«Да» поднимет все ваши цены на этот процент (цены, которые вы не указывали, не меняются). "
               "Уже сохранённые сметы не пересчитываются.</i>",
               [[Btn(f"✅ Да, поднять на {fnum(mk)}%", callback_data=f"adj:{d}:up:y")],
                [Btn("📁 Только для этого объекта", callback_data=f"adj:{d}:up:o")],
                [Btn("⏳ Решить позже", callback_data=f"adj:{d}:up:l")]], user=user)


async def adj_action(update: Update, context: ContextTypes.DEFAULT_TYPE, p: list) -> None:
    """Кнопки наценки и скидки: adj:<смета>:open|mk|ds|tg|reset|askup|up:y|o|l|res."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    est = context.user_data["est"]
    d = est["id"]
    a = adj_of(est)
    sub = p[1]
    if est.get("kind") == "extra":
        await show_result(update, context, "Наценка и скидка для допработ не используются.")
        return
    if "result" not in est:
        adj_rebuild(est, uid, user)
    if sub == "open":
        await show_adjust(update, context)
    elif sub in ("mk", "ds"):
        field = "markup" if sub == "mk" else "discount"
        what = ("наценку, %. Она вшивается в цены строк, клиент её не видит" if field == "markup"
                else "скидку, %. Она покажется отдельной строкой")
        await show(update, context,
                   f"✍️ Напишите {what}.\nНапример: 10 или 7,5 (0 — убрать). Не больше {fnum(ADJ_MAX[field])}.",
                   [[Btn("⬅️ Назад", callback_data=f"adj:{d}:open")]], user=user,
                   await_input={"kind": "adj", "d": d, "field": field})
    elif sub == "tg":
        a["discount_on"] = not a.get("discount_on", True)
        adj_rebuild(est, uid, user)
        await show_adjust(update, context)
    elif sub == "reset":
        est["adj"] = {"markup": 0, "discount": 0, "discount_on": True}
        adj_rebuild(est, uid, user)
        await show_adjust(update, context, "🧹 Наценка и скидка убраны.")
    elif sub == "askup" and a["markup"]:
        await show_adjust_ask(update, context)
    elif sub == "up" and len(p) > 2:
        mk = a["markup"]
        if p[2] == "y" and mk > 0:
            f = 1 + mk / 100
            n = db.scale_prices(uid, f)
            for l in est.get("lines") or []:      # цены строк конструктора и правки цен в этой смете поднимаем так же,
                l["price"] = round(l["price"] * f, 2)   # чтобы итог не просел
            for k in list(est.get("price_over") or {}):
                est["price_over"][k] = round(est["price_over"][k] * f, 2)
            for m in est.get("manual") or []:
                m["price"] = round(m["price"] * f, 2)
            a["markup"], a["ask"] = 0, "done"   # теперь процент уже в ваших ценах, второй раз не добавляем
            adj_rebuild(est, uid, user)
            await show_adjust(update, context, f"✅ Ваши цены подняты на {fnum(mk)}% (изменено цен: {n}). "
                                               "Смета пересчитана по новым ценам.")
        elif p[2] == "o":
            a["ask"] = "object"
            await show_adjust(update, context, "📁 Хорошо: наценка только в этой смете, ваши цены не менялись.")
        else:
            a["ask"] = "later"
            await show_adjust(update, context, "⏳ Решите позже: кнопка «Поднять и мои цены» останется здесь.")
    elif sub == "res":
        adj_rebuild(est, uid, user)
        if est.get("type") == "croom":
            await show_croom_result(update, context)
        else:
            await show_result(update, context)


async def adj_input(update: Update, context: ContextTypes.DEFAULT_TYPE, field: str, text: str) -> None:
    """Число процентов для наценки или скидки (0 — убрать)."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    est = context.user_data["est"]
    a = adj_of(est)
    value = parse_number(text)
    if value is None or value < 0 or value > ADJ_MAX[field]:
        context.user_data["await"] = {"kind": "adj", "d": est["id"], "field": field}
        await update.message.reply_text(f"⚠️ Нужно число от 0 до {fnum(ADJ_MAX[field])}, например 10 или 7,5.")
        return
    a[field] = round(value, 2)
    if field == "discount":
        a["discount_on"] = True
    else:
        a["ask"] = None if value > 0 else "done"
    adj_rebuild(est, uid, user)
    if field == "markup" and value > 0:
        await show_adjust_ask(update, context)
    else:
        await show_adjust(update, context)


async def show_croom_result(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    user = db.get_user(update.effective_user.id)
    est = context.user_data["est"]
    d = est["id"]
    if "result" not in est:
        await croom_finish(update, context)
        return
    title = ("Допработа · " if est.get("kind") == "extra" else "") + est["room_name"]
    text = (f"🧾 <b>Смета: {esc(title)}</b>\n\n" + (note + "\n\n" if note else "") + note_text(est.get("note"))
            + calc.format_text(est["result"], user["currency"]))
    calc_est = est.get("room") == "calc"      # расчёт из Excel или текста: свои цены, они действуют только в этой смете
    rows = []
    if calc_est and est.get("pool") is None and not est.get("edit_id"):   # вопрос про общий прайс, пока без ответа
        text += ("\n\n🌐 <b>Добавить услуги и цены в общий прайс, анонимно?</b>\nУйдут только название услуги, единица и "
                 "цена. Метраж, суммы, имя, адрес и клиент не сохраняются.")
        rows.append([Btn("🌐 Да, анонимно", callback_data=f"xa:{d}:pool:y"), Btn("Нет", callback_data=f"xa:{d}:pool:n")])
    rows += missing_price_rows(est, f"xa:{d}:mp:")
    rows += [[Btn("💾 Сохранить изменения" if est.get("edit_id") else "💾 Сохранить", callback_data=f"save:{d}"),
              Btn("📤 Поделиться", callback_data=f"sh:d{d}")],
             [Btn("💲 Изменить цену и количество", callback_data=f"xa:{d}:el"),
              Btn("📝 Заметка", callback_data=f"nt:d{d}")]]
    if calc_est and est.get("lines"):
        rows.append([Btn("💾 Сохранить эти цены в «Мои цены»", callback_data=f"xa:{d}:cps")])
    elif any(l.get("pend") for l in est["lines"]):
        rows.append([Btn("💾 Сохранить новые цены в «Мои цены»", callback_data=f"xa:{d}:keepr")])
    if est.get("kind") != "extra":
        if days_button(est, user):
            rows.append(days_button(est, user))
        rows.append(adj_button(est))
    if calc_est and not est.get("edit_id"):
        rows.append([Btn("⬅️ Назад к списку", callback_data="xc:back"), Btn("🏠 В меню", callback_data="menu")])
    else:
        rows.append([Btn("⬅️ Назад к работам", callback_data=f"xa:{d}:back"), Btn("🏠 В меню", callback_data="menu")])
    rows.insert(len(rows) - 1, feedback_row(est_ref_of(est)))   # «Верно» / «Есть ошибка» над строкой навигации
    for hr in reversed(hint_rows(text, 5)):   # «Что это?» к непонятным словам в смете
        rows.insert(len(rows) - 2, hr)
    await estimate_shown(update, context)
    await show_long(update, context, text, rows, user=user)


async def show_line_list(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    """Итог конструктора: какую строку поправить (количество или цену)."""
    est = context.user_data["est"]
    d = est["id"]
    n = len(est["lines"])
    lines = [f"{i + 1}. {esc(cut_title(l['title'], n))} — {fnum(l['qty'])} {esc(l['unit'])} × "
             f"{fnum(l['price']) if l['price'] > 0 else 'нет цены'}" for i, l in enumerate(est["lines"])]
    rows = number_rows([Btn(str(i + 1), callback_data=f"xa:{d}:ei:{i}") for i in range(len(est["lines"]))])
    rows.append([Btn("⬅️ К смете", callback_data=f"w:{d}:results")])
    await show(update, context, note + "✏️ <b>Какую строку поправить?</b>\nНажмите номер. Можно изменить количество "
                                       "или цену, либо убрать работу.\n\n" + "\n".join(lines), rows)


async def show_line_edit(update: Update, context: ContextTypes.DEFAULT_TYPE, i: int) -> None:
    est = context.user_data["est"]
    d = est["id"]
    if not 0 <= i < len(est["lines"]):
        await show_line_list(update, context)
        return
    l = est["lines"][i]
    price = f"{fnum(l['price'])} за {esc(l['unit'])}" if l["price"] > 0 else "не указана"
    mark = " (бот посчитал по замеру)" if l.get("auto") else ""
    await show(update, context, f"✏️ <b>{esc(l['title'])}</b>\nКоличество: {fnum(l['qty'])} {esc(l['unit'])}{mark}\n"
                                f"Цена: {price}",
               [[Btn("🔢 Количество", callback_data=f"xa:{d}:eq:{i}"), Btn("💲 Цена", callback_data=f"xa:{d}:ep:{i}")],
                [Btn("🗑 Убрать работу", callback_data=f"xa:{d}:ed:{i}")],
                [Btn("⬅️ К строкам", callback_data=f"xa:{d}:el")]])


async def ask_line_value(update: Update, context: ContextTypes.DEFAULT_TYPE, i: int, what: str, note: str = "") -> None:
    """what: 'qty' | 'price' | 'mprice' (цена для работы без цены — сразу в «Мои цены»)."""
    est = context.user_data["est"]
    d = est["id"]
    if not 0 <= i < len(est["lines"]):
        await show_line_list(update, context)
        return
    l = est["lines"][i]
    ask = {"qty": f"Сколько {esc(l['unit'])}? (числом)",
           "price": f"Цена за 1 {esc(l['unit'])} (числом):",
           "mprice": f"На эту работу цена не указана. Напишите цену за 1 {esc(l['unit'])} — она сохранится в «Мои цены»:"}[what]
    back = f"xa:{d}:ei:{i}" if what != "mprice" else f"w:{d}:results"
    rows = []
    ms = market.stats(l.get("key") or "", l["title"], l["unit"]) if what != "qty" else None
    if ms:   # подсказка цены по рынку Челябинска; решение за человеком
        ask += f"\n💡 {market.hint(ms)}"
        rows.append([Btn(f"Взять среднюю по рынку: {fnum(ms['avg'])} ₽", callback_data=f"xa:{d}:mavg:{i}:{what}")])
    rows.append([Btn("⬅️ Отмена", callback_data=back)])
    await show(update, context, f"{note}✏️ <b>{esc(l['title'])}</b>\n{ask}", rows,
               await_input={"kind": f"x_l{what}", "d": d, "idx": i})


async def set_line_price(update: Update, context: ContextTypes.DEFAULT_TYPE, i: int, value: float, what: str) -> None:
    """Цена строки итога конструктора. what='mprice' — цена для работы без цены: сразу в «Мои цены»."""
    est = context.user_data["est"]
    line = est["lines"][i]
    line["price"], line["pend"] = value, True
    if what == "mprice":
        save_pending_prices(update.effective_user.id, est, only=i)
    est.pop("result", None)
    await croom_finish(update, context, "✅ Цена сохранена в «Мои цены»." if what == "mprice" else "✅ Строка поправлена.")


async def x_action(update: Update, context: ContextTypes.DEFAULT_TYPE, p: list) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    est = context.user_data["est"]
    d = est["id"]
    tmp = est["tmp"]
    sub = p[1]
    croom = est["type"] == "croom"
    small = est.get("room") == "small"   # «Мелкие работы»: поиск и разделы как у допработы, итог как у комнаты
    if sub in ("xl", "xi", "xt", "xq", "xp", "xd") and not croom:   # «Изменить» в допработе
        await x_edit_line(update, context, p)
        return
    if sub == "op" and croom and est.get("room") == "open":   # «Объект без стен»: замер
        await open_action(update, context, p)
        return
    if sub == "mz" and croom:  # экран замера
        await mz_action(update, context, p)
    elif sub == "ps" and croom:  # для какой части комнаты выбираем работы: a — вся комната, число — номер части
        est["part"] = None if p[2] == "a" else int(p[2])
        await show_constructor(update, context)
    elif sub == "t" and croom:  # галочка у работы из списка: добавить или убрать (⬜ ↔ ✅ на той же строке)
        item = lookup_item(uid, p[2])
        if item:
            scope = scope_of(est)
            have = [l for l in est["lines"] if l.get("key") == item[0] and line_in_scope(l, scope)]
            if have:
                est["lines"] = [l for l in est["lines"] if not (l.get("key") == item[0] and line_in_scope(l, scope))]
            else:
                qty, auto = auto_qty(est, item[0], item[2], item[1], scope)
                line = {"title": item[1], "unit": item[2], "price": item[3], "qty": qty,
                        "key": item[0], "pend": False, "auto": auto, "part": scope}
                mk = market.item(item[0])
                if mk:   # раздел итога для работы из прайсов фирм — по её теме
                    line["section"] = market.SECTION_OF_THEME.get(mk["theme"], "custom")
                est["lines"].append(line)
            est.pop("result", None)
        await show_constructor(update, context)
    elif sub == "tl" and croom:  # снять галочку со своей работы (без ключа прайса)
        if 0 <= int(p[2]) < len(est["lines"]):
            est["lines"].pop(int(p[2]))
            est.pop("result", None)
        await show_constructor(update, context)
    elif sub == "pool" and croom and est.get("room") == "calc":   # общий прайс: да или нет
        await calc_pool_answer(update, context, p[2] == "y")
    elif sub == "cps" and croom and est.get("room") == "calc":    # «Сохранить эти цены»: сначала показываем, что изменится
        await calc_prices_ask(update, context)
    elif sub == "cpsok" and croom and est.get("room") == "calc":
        await calc_prices_save(update, context)
    elif sub == "pfx":  # «Загрузить прайс файлом» с экрана своей работы
        est["tmp"] = {}
        await pf_start(update, context, f"xa:{d}:back")
    elif sub == "pg" and croom:
        est.setdefault("flt", {})["pg"] = int(p[2])
        await show_constructor(update, context)
    elif sub == "fx" and croom:
        est["flt"] = {}
        est["tmp"] = {}
        await show_constructor(update, context)
    elif sub == "pf":  # прайс файлом
        await pf_start(update, context, f"xa:{d}:back")
    elif sub == "el" and croom:
        await show_line_list(update, context)
    elif sub == "ei" and croom:
        await show_line_edit(update, context, int(p[2]))
    elif sub in ("eq", "ep", "mp") and croom:
        await ask_line_value(update, context, int(p[2]), {"eq": "qty", "ep": "price", "mp": "mprice"}[sub])
    elif sub == "mavg" and croom and 0 <= int(p[2]) < len(est["lines"]):   # «Взять среднюю по рынку»
        l = est["lines"][int(p[2])]
        ms = market.stats(l.get("key") or "", l["title"], l["unit"])
        if ms:
            await set_line_price(update, context, int(p[2]), float(ms["avg"]), p[3])
    elif sub == "ed" and croom:
        if 0 <= int(p[2]) < len(est["lines"]):
            est["lines"].pop(int(p[2]))
            est.pop("result", None)
        if est["lines"]:
            await croom_finish(update, context, "🗑 Работа убрана.")
        else:
            await show_constructor(update, context, "🗑 Работа убрана.")
    elif sub == "nu":  # похожая работа не подошла: добавляем как новую
        await x_ask(update, context, "unit")
    elif sub == "uc" and small and "title" in tmp:   # «Мелкие работы»: переключить единицу м² → пог.м → шт
        cycle = [UNITS["m2"], UNITS["pm"], UNITS["pc"]]
        i = cycle.index(tmp["unit"]) if tmp["unit"] in cycle else -1
        tmp["unit"] = cycle[(i + 1) % len(cycle)]
        await x_ask(update, context, "qty", f"🔁 Единица теперь: {tmp['unit']}. Цену за эту единицу поправьте кнопкой «Изменить цену».\n")
    elif sub == "my" and croom and not small:  # поиск: просто пишите слово в ответ, список отфильтруется
        est["flt"], est["tmp"] = {}, {}
        await show_constructor(update, context, "🔍 Напишите название работы в ответ, например «розетка».")
    elif sub == "my":  # поиск по всем разделам (допработа по строкам)
        est["tmp"] = {}
        await x_search(update, context, None)
    elif sub == "grp" and croom and not small:  # «Из разделов»: темы прайса
        est["flt"], est["tmp"] = {}, {}
        await show_themes(update, context)
    elif sub == "grp":  # допработа по строкам: разделы прайса
        names = list(catalog.GROUPS) + [f"🧰 {s['name']}" for s in db.list_sections(uid)[:SEC_LIST_MAX]]
        rows = [[Btn(g, callback_data=f"xa:{d}:g:{i}")] for i, g in enumerate(names)]
        rows.append([Btn("⬅️ Назад к поиску", callback_data=f"xa:{d}:my")])
        await show(update, context, "📂 Выберите раздел вашего прайса:", rows)
    elif sub == "g" and croom and not small:  # тема выбрана: в общем списке только её работы
        est["flt"] = {"th": int(p[2]), "pg": 0}
        est["tmp"] = {}
        await show_constructor(update, context)
    elif sub == "g":
        prices = db.get_prices(uid)
        idx = int(p[2])
        if idx < len(catalog.GROUPS):
            group = catalog.GROUPS[idx]
            found = [(k, it["title"], it["unit"], prices.get(k, 0)) for k, it in catalog.ITEM_BY_KEY.items()
                     if it["group"] == group and k not in catalog.HIDDEN_DUPLICATES]
        else:   # свой раздел мастера
            secs = db.list_sections(uid)[:SEC_LIST_MAX]
            k = idx - len(catalog.GROUPS)
            group = secs[k]["name"] if 0 <= k < len(secs) else "Мои работы"
            found = section_entries(uid, secs[k]["id"]) if 0 <= k < len(secs) else []
        cut = ""
        if len(found) > XA_LIST_MAX:   # в сообщении Телеграма не больше ста кнопок: остальное найдёт поиск
            cut = f"\nПоказаны первые {XA_LIST_MAX} из {len(found)}. Остальные найдёт поиск: напишите слово из названия."
            found = found[:XA_LIST_MAX]
        rows = item_number_rows(d, found)
        rows += hint_rows("\n".join(it[1] for it in found))
        rows.append([Btn("⬅️ К разделам", callback_data=f"xa:{d}:grp")] + x_cancel(est))
        est["tmp"] = {"from": str(idx)}  # чтобы «Назад» с ввода количества вернуло в этот раздел
        await show(update, context, f"📂 <b>{esc(group)}</b>\nНажмите номер нужной работы:{cut}\n\n{item_lines_text(found)}",
                   rows, user=user,
                   await_input={"kind": "x_search", "d": d})
    elif sub == "i":
        item = lookup_item(uid, p[2])
        if item:
            _, title, unit, price = item
            rate = (est.get("rates") or {}).get(p[2])    # допработа к смете «В работе»: расценка как в самой смете
            if rate:
                price = rate
            # key/orig: откуда работа и какая цена в «Мои цены» (чтобы заметить изменённую цену); from/query: куда вернуться
            est["tmp"] = {"title": title, "unit": unit, "price": price, "key": p[2], "orig": price,
                          "from": tmp.get("from", ""), "query": tmp.get("query", "")}
            await x_ask(update, context, "qty" if price > 0 else "price",
                        "" if price > 0 else "⚠️ В вашем прайсе нет цены на эту работу.\n")
        else:
            await x_search(update, context, None)
    elif sub == "own":  # своя работа: название → единица → цена → количество
        est["tmp"] = {"own": True, "query": tmp.get("query", "")}
        await x_ask(update, context, "title")
    elif sub == "tq":  # название = слово из поиска
        tmp["title"] = tmp.get("query", "").capitalize() or "Работа"
        await x_ask(update, context, "unit")
    elif sub == "keep" and not croom:   # «Сохранить»: свои работы допработы → «Мои цены» (по текущим названию, цене, единице)
        saved = []
        for l in est["lines"]:
            if l.get("own"):
                db.add_custom_item(uid, l["title"], l["unit"], l["price"])
                l.pop("own")
                saved.append(l["title"])
        if saved:
            names = "«" + "», «".join(esc(t) for t in saved) + "»"
            await show_extra(update, context, f"✅ Сохранено в «Мои цены» (раздел подобран по названию): {names}. "
                                              "Теперь поиск найдёт их.\n\n")
        else:
            await show_extra(update, context)
    elif sub == "keepl" and est["type"] == "croom":  # конструктор: новые работы и изменённые цены → «Мои цены»
        n = save_pending_prices(uid, est)
        await show_extra(update, context, f"✅ Сохранено в «Мои цены»: {n}. Теперь эти работы найдёт поиск.\n\n")
    elif sub == "keepr" and est["type"] == "croom":  # то же самое, но с экрана итога
        n = save_pending_prices(uid, est)
        await show_croom_result(update, context, f"✅ Сохранено в «Мои цены»: {n}.")
    elif sub == "pe" and est["type"] == "croom" and "title" in tmp:  # изменить цену выбранной работы
        tmp["pe"] = True
        await x_ask(update, context, "price")
    elif sub == "sb" and est["type"] == "croom":  # «Назад» на шаге ввода
        await x_step_back(update, context, ((context.user_data.get("await") or {}).get("kind") or "")[2:])
    elif sub == "sum" and est["type"] == "extra":
        est["tmp"] = {"unit": "сумма", "kind": "sum"}
        await x_ask(update, context, "title")
    elif sub == "u" and p[2] in UNITS and "title" in tmp:
        tmp["unit"] = UNITS[p[2]]
        await x_ask(update, context, "price")
    elif sub == "q" and {"title", "unit", "price"} <= set(tmp):
        await x_add_line(update, context, float(p[2]))
    elif sub == "del":
        i = int(p[2])
        if 0 <= i < len(est["lines"]):
            est["lines"].pop(i)
            est.pop("result", None)
        await show_extra(update, context, "🗑 Строка убрана.\n\n")
    elif sub == "fin":
        if not est["lines"]:
            await show_extra(update, context)
        elif est["type"] == "croom" and est.get("pm") and not est.get("mz_done"):
            est["pm_go"] = True   # «Прайсы»: работы выбраны, теперь замер (или без замера)
            await show_extra(update, context)
        elif est["type"] == "croom":
            await croom_finish(update, context)
        elif est.get("parent"):   # допработы к смете «В работе» называются одинаково, имя не спрашиваем
            await x_finish(update, context, est.get("name") or "Допработы")
        else:
            await x_ask(update, context, "name")
    elif sub == "name":
        await x_finish(update, context, "Допработы")
    else:  # back и всё непонятное — к списку строк
        est["tmp"] = {}
        await show_extra(update, context)


# --- Прайс файлом (Excel) ----------------------------------------------------------
PF_SAMPLE = 5   # сколько услуг показываем в «Нашёл N работ»


async def pf_start(update: Update, context: ContextTypes.DEFAULT_TYPE, back: str) -> None:
    """«Загрузить прайс файлом»: короткая инструкция (телефон и компьютер) и выбор — таблица Excel или PDF."""
    context.user_data["pf_back"] = back
    pick = "«Таблица Excel» или «PDF»" if pricefile.pdf_available() else "«Таблица Excel»"
    await show(update, context,
               "📥 <b>Загрузить прайс файлом</b>\n"
               "Файл — три колонки: <b>Услуга</b>, <b>Единица</b>, <b>Цена</b>. Строка, где заполнено только название, "
               "начинает группу: услуги под ней попадут в неё. Если групп в файле нет, я разложу услуги по названию.\n\n"
               "📱 <b>С телефона</b>\n"
               f"1. Нажмите ниже {pick}. Excel: я пришлю шаблон, скачайте его.\n"
               "2. Откройте шаблон (Excel, Google Таблицы, «Мой офис») и заполните три колонки: Услуга, Единица, Цена.\n"
               "3. Сохраните файл (.xlsx).\n"
               "4. Нажмите на файле «Поделиться» и выберите Телеграм, затем этого бота. Или в этом чате: скрепка 📎 → «Файл» "
               "(не «Фото») → ваш файл.\n"
               "5. Я напишу «Нашёл N работ» — подтвердите.\n\n"
               "💻 <b>С компьютера</b>\n"
               f"1. Нажмите ниже {pick}. Excel: скачайте шаблон.\n"
               "2. Заполните три колонки: Услуга, Единица, Цена.\n"
               "3. Сохраните файл (.xlsx).\n"
               "4. Перетащите файл в это окно чата (или скрепка → «Файл») и отправьте.\n"
               "5. Я напишу «Нашёл N работ» — подтвердите.\n\n"
               + ("📄 <b>PDF</b> я читаю по тем же колонкам (нужен PDF с текстом, не скан). После чтения всегда пишу "
                  "«Нашёл N работ» и жду подтверждения.\n" if pricefile.pdf_available() else ""),
               [[Btn("📊 Таблица Excel", callback_data="pf:fmt:x")]
                + ([Btn("📄 PDF", callback_data="pf:fmt:p")] if pricefile.pdf_available() else []),
                [Btn("⬅️ Назад", callback_data=back)]], edit=False)


async def pf_format(update: Update, context: ContextTypes.DEFAULT_TYPE, fmt: str) -> None:
    """Выбор вида файла. Excel — шлём шаблон; PDF — просим ту же таблицу из трёх колонок."""
    back = context.user_data.get("pf_back") or "price:list"
    if fmt == "x":
        await update.effective_chat.send_document(
            InputFile(io.BytesIO(pricefile.build_template()), filename="shablon_prajsa.xlsx"),
            caption="Шаблон прайса: три колонки — Услуга, Единица, Цена. В образце два раздела (Стены, Пол): "
                    "строка с одним названием начинает раздел.")
        text = ("📊 Заполните шаблон и пришлите файл .xlsx мне в этот чат. Образец (Стены, Пол) удалите и впишите "
                "свои услуги.")
    else:
        text = ("📄 Пришлите PDF, где есть таблица из тех же трёх колонок: <b>Услуга</b>, <b>Единица</b>, <b>Цена</b> "
                "(заголовки обязательны). Строка с одним названием начинает раздел. Проще всего заполнить шаблон Excel "
                "и сохранить его как PDF. PDF-скан (фото) я прочитать не смогу: нужен PDF, в котором выделяется текст.")
    await show(update, context, text, [[Btn("⬅️ Назад", callback_data="pf:back")]], edit=False,
               await_input={"kind": "pricefile", "back": back, "fmt": fmt})


async def on_document(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Файл от человека: если ждём прайс — разбираем его, иначе как любое другое не-текстовое сообщение."""
    ud = context.user_data
    aw = ud.get("await")
    user = db.get_user(update.effective_user.id)
    if not (user and user["ready"] and aw and aw.get("kind") in ("pricefile", "xcalc")):
        await on_other_message(update, context)
        return
    if await entry_block(update, context, user):
        return
    doc = update.message.document
    name = (doc.file_name or "").lower()
    if aw.get("kind") == "xcalc":    # калькулятор: заполненный шаблон Excel
        await xc_on_file(update, context, doc, name)
        return
    is_pdf = name.endswith(".pdf")
    if not (is_pdf or name.endswith(".xlsx")) or (is_pdf and not pricefile.pdf_available()):
        await update.effective_chat.send_message("⚠️ Нужен файл Excel (.xlsx)"
                                                 + (" или PDF с таблицей из колонок Услуга, Единица, Цена."
                                                    if pricefile.pdf_available() else " с колонками Услуга, Единица, Цена."))
        return
    if (doc.file_size or 0) > pricefile.MAX_BYTES:
        await update.effective_chat.send_message("⚠️ Файл слишком большой для прайса (больше 5 МБ).")
        return
    try:
        data = bytes(await (await doc.get_file()).download_as_bytearray())
        res = pricefile.parse_pdf(data) if is_pdf else pricefile.parse_xlsx(data)
    except Exception:
        log.exception("Не удалось прочитать файл с прайсом")
        await update.effective_chat.send_message("⚠️ Не получилось прочитать файл. Заполните шаблон и сохраните его как "
                                                 + ("PDF." if is_pdf else ".xlsx."))
        return
    back = aw.get("back", "menu")
    if res["error"] == "no_columns":   # колонки не угадываем
        await update.effective_chat.send_message(pricefile.NO_COLUMNS_TEXT)
        return
    if res["error"]:
        await update.effective_chat.send_message("⚠️ Не нашёл ни одной услуги. Нужны название и цена больше нуля "
                                                 "в каждой строке.")
        return
    items = res["items"]
    ud["pf"] = {"items": [list(i) for i in items]}
    ud["await"] = None
    notes = []
    if res["groups"]:
        notes.append(f"Разделов в файле: {len(res['groups'])} ({esc(', '.join(res['groups'][:6]))}"
                     + ("…" if len(res["groups"]) > 6 else "") + ")")
    else:
        notes.append("Разделов в файле нет — разложу услуги по названию")
    if res["skipped"]:
        notes.append(f"Пропущено строк без названия или цены: {res['skipped']}")
    if res["dups"]:
        notes.append(f"Повторов в самом файле: {res['dups']} (взял последнюю цену)")
    if res["truncated"]:
        notes.append(f"Прочитал только первые {pricefile.MAX_ROWS} строк")
    sample = "\n".join(f"• {esc(t)} — {fnum(p)}/{esc(u)}" for t, u, p, _g in items[:PF_SAMPLE])
    more = f"\n… и ещё {len(items) - PF_SAMPLE}" if len(items) > PF_SAMPLE else ""
    same = db.count_import_matches(update.effective_user.id, [tuple(i) for i in items])
    if same:   # часть услуг уже есть: «Нашёл N работ» и сразу вопрос, что делать (название и единица — без учёта регистра и «ё»)
        await pf_ask_duplicates(update, context, items, same,
                                f"📥 Нашёл {len(items)} работ.\n\n{sample}{more}\n\n" + "\n".join(notes) + "\n\n", edit=False)
        return
    await show(update, context, f"📥 Нашёл {len(items)} работ, добавить?\n\n{sample}{more}\n\n" + "\n".join(notes),
               [[Btn("✅ Добавить", callback_data="pf:ok"), Btn("✖️ Отмена", callback_data=f"pf:no:{back}")]],
               edit=False)


async def pf_ask_duplicates(update: Update, context: ContextTypes.DEFAULT_TYPE, items: list, same: int,
                            head: str = "", edit: bool = True) -> None:
    """Загружаемый прайс совпал с уже имеющимися услугами: «Из N работ M уже есть. Что сделать?» и три кнопки."""
    fresh = len(items) - same
    await show(update, context,
               f"{head}Из {len(items)} работ {same} уже есть. Что сделать?\n\n"
               f"🔄 <b>Заменить цены из файла</b> — у {same} совпавших цена станет из файла, новые ({fresh}) добавлю.\n"
               "✋ <b>Оставить старые</b> — ничего не менять, файл не загружать.\n"
               f"➕ <b>Добавить только новые</b> — добавлю {fresh}, у совпавших останутся прежние цены.",
               [[Btn("🔄 Заменить цены из файла", callback_data="pf:mode:replace")],
                [Btn("✋ Оставить старые", callback_data="pf:mode:keep")],
                [Btn("➕ Добавить только новые", callback_data="pf:mode:new")]],
               user=db.get_user(update.effective_user.id), edit=edit)


async def pf_apply(update: Update, context: ContextTypes.DEFAULT_TYPE, items: list, mode: str) -> None:
    """Загружает услуги в «Мои цены» (режим replace — с заменой цен совпавших, new — только новые) и пишет итог."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    res = db.import_custom_items(uid, [tuple(i) for i in items], mode)
    parts = [f"добавлено новых: {res['added']}"]
    if res["updated"]:
        parts.append(f"цены обновлены: {res['updated']}")
    if res["kept"]:
        parts.append(f"прежние цены оставлены: {res['kept']}")
    secs = ", ".join(f"{esc(s['name'])} — {s['n']}" for s in db.list_sections(uid)[:12])
    await show(update, context, "✅ Загрузил: " + ", ".join(parts) + ".\n"
               + (f"Мои услуги по разделам: {secs}." if secs else "") + "\nИх найдёт поиск в конструкторе.",
               [[Btn("💰 Мои цены", callback_data="price:list"), Btn("🏠 В меню", callback_data="menu")]], user=user)


async def pf_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE, p: list) -> None:
    """pf:ok — подтвердили «Нашёл N работ»; pf:mode:<replace|keep|new> — что делать с уже имеющимися; pf:no — отмена."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    ud = context.user_data
    pf = ud.get("pf")
    items = pf["items"] if pf else None
    sub = p[1]
    if sub == "fmt":
        await pf_format(update, context, p[2])
        return
    if sub == "back":   # назад из шага «пришлите файл» к инструкции
        await pf_start(update, context, ud.get("pf_back") or "price:list")
        return
    if sub == "ok" and items:
        same = db.count_import_matches(uid, [tuple(i) for i in items])
        if same == 0:
            ud.pop("pf", None)
            await pf_apply(update, context, items, "replace")
            return
        await pf_ask_duplicates(update, context, items, same)
    elif sub == "mode" and items:
        ud.pop("pf", None)
        if p[2] == "keep":
            await show(update, context, "Оставил всё как было: ничего не изменилось.",
                       [[Btn("💰 Мои цены", callback_data="price:list"), Btn("🏠 В меню", callback_data="menu")]], user=user)
        else:
            await pf_apply(update, context, items, "replace" if p[2] == "replace" else "new")
    elif sub in ("ok", "mode"):   # бот перезапускался, данных файла уже нет
        await show(update, context, "Файл уже не помню (бот перезапускался). Пришлите его ещё раз.",
                   [[Btn("📥 Загрузить прайс файлом", callback_data="price:file")]], user=user)
    else:
        ud.pop("pf", None)
        await show(update, context, "Загрузка отменена, ничего не добавлено.",
                   [[Btn("⬅️ Назад", callback_data=":".join(p[2:]) or "menu")]], user=user)


# --- Поделиться (PDF) -----------------------------------------------------------
async def ask_share(update: Update, context: ContextTypes.DEFAULT_TYPE, which: str) -> None:
    """which: 'd12' — открытая смета №12, '34' — сохранённая смета №34. Сначала спрашиваем вид сметы."""
    user = db.get_user(update.effective_user.id)
    back = f"w:{which[1:]}:results" if which.startswith("d") else f"est:{which}"
    await show(update, context,
               "📤 <b>Поделиться сметой</b>\nВыберите вид PDF:\n\n"
               "📋 <b>Подробная</b> — услуга, метраж, цена за единицу и сумма по строке.\n"
               "✂️ <b>Короткая</b> — только услуги и общая сумма, без метража и расценок.",
               [[Btn("📋 Подробная", callback_data=f"shp:{which}:d"), Btn("✂️ Короткая", callback_data=f"shp:{which}:s")],
                [Btn("⬅️ Назад", callback_data=back)]], user=user)


async def send_pdf(update: Update, context: ContextTypes.DEFAULT_TYPE, which: str, view: str) -> None:
    """view: 'detailed' (подробная) или 'short' (короткая). Заметки в PDF не попадают."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    if which.startswith("d"):
        est = await activate(update, context, int(which[1:]))
        if not est:
            return
        if "result" not in est:
            await send_menu(update, context)
            return
        result = est["result"]
        if est["type"] == "extra":
            title = est.get("name") or "Допработа"
        elif est["type"] == "croom":
            title = est["room_name"]
        else:
            title = estimate_title(est)
        obj = db.get_object(uid, est["obj"]) if est.get("obj") else None
        object_name = obj["name"] if obj else ""
        back = f"w:{est['id']}:results"
    else:
        row = db.get_estimate(uid, int(which))
        if not row:
            await send_menu(update, context)
            return
        result, title, object_name = json.loads(row["result"]), row["title"], row["object_name"]
        if row["kind"] != "extra":   # допработы к смете идут в тот же PDF отдельным блоком, итог общий
            result = calc.combine_results(result, [json.loads(c["result"]) for c in db.list_children(uid, row["id"])])
        back = f"est:{which}"
    cur = result.get("currency", user["currency"])
    try:
        place = " · ".join(x for x in (user["city"], catalog.CURRENCIES[cur]["name"]) if x)  # без флага: в PDF нет такого шрифта
        data = pdf_report.build_pdf(result, cur, title, object_name, place, view)
    except Exception:
        log.exception("Не удалось собрать PDF")
        await update.effective_chat.send_message("😔 Не получилось собрать PDF. Подробности в консоли бота.")
        return
    short = view == "short"
    caption = "Смета: " + ("короткая (услуги и общая сумма)" if short else "подробная (метраж, цены, суммы)")
    await update.effective_chat.send_document(
        InputFile(io.BytesIO(data), filename="smeta_kratkaya.pdf" if short else "smeta_podrobnaya.pdf"), caption=caption)
    await show(update, context, "📄 PDF отправлен.", [[Btn("⬅️ К смете", callback_data=back),
                                                      Btn("🏠 В меню", callback_data="menu")]], user=user, edit=False)


# =============================================================================
# Своё помещение (ангар, склад, мастерская, кафе…)
# =============================================================================
async def ask_own_room(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = db.get_user(update.effective_user.id)
    await show(update, context, "➕ <b>Своё помещение</b>\nНапишите название: ангар, склад, мастерская, кафе, магазин… "
                                "Дальше обычный конструктор: замер и работы. Название сохранится в смете.",
               [[Btn("⬅️ Назад", callback_data="menu")]], user=user, await_input={"kind": "roomname"})


async def start_small(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Режим «Мелкие работы» (кусок 3): без замера. Выбираем работы из прайса, пишем количество, «Добавить ещё» или «Готово»."""
    ud = context.user_data
    obj, kind = ud.pop("cur_obj", None), ud.pop("cur_kind", None)
    est = new_draft(update, context, "croom", obj, kind or "main")
    est.update(room="small", room_name="Мелкие работы", icon="🔧", lines=[], name="", mz=None, mz_done=True, flt={})
    await show_small(update, context)


async def show_small(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    """Экран режима «Мелкие работы»: что уже выбрано и что делать дальше."""
    uid = update.effective_user.id
    user = db.get_user(uid)
    est = context.user_data["est"]
    d = est["id"]
    text = (note + "\n\n" if note else "") + "🔧 <b>Мелкие работы</b>\n"
    rows = []
    if est["lines"]:
        total = 0
        out = []
        for i, l in enumerate(est["lines"], 1):
            s = round(round(l["qty"], 2) * l["price"])
            total += s
            price = f"{fnum(l['price'])}/{esc(l['unit'])}" if l["price"] > 0 else "цена не указана"
            out.append(f"{i}. {esc(l['title'])}: {fnum(l['qty'])} {esc(l['unit'])} × {price}")
        text += "\n" + "\n".join(out) + "\n"
        text += "\nМожно добавить ещё работу или нажать «Готово». Чтобы найти работу, просто напишите слово."
        rows.append([Btn("➕ Добавить ещё", callback_data=f"xa:{d}:my"), Btn("✅ Готово", callback_data=f"xa:{d}:fin")])
        rows.append([Btn("📂 Из разделов", callback_data=f"xa:{d}:grp"), Btn("✍️ Своя работа", callback_data=f"xa:{d}:own")])
        for i, l in enumerate(est["lines"]):
            rows.append([Btn(f"🗑 Убрать: {i + 1}. {l['title']}"[:55], callback_data=f"xa:{d}:del:{i}")])
    else:
        text += ("\nСчитаем маленький заказ без замера комнаты: выберите работу из своего прайса и напишите, сколько "
                 "её нужно. Единицу (м², пог. м, шт.) бот берёт из прайса, её можно переключить.\n\n"
                 "Напишите слово (например «розетка») или откройте разделы прайса.")
        rows.append([Btn("🔍 Найти работу", callback_data=f"xa:{d}:my"), Btn("📂 Из разделов", callback_data=f"xa:{d}:grp")])
        rows.append([Btn("✍️ Своя работа", callback_data=f"xa:{d}:own")])
    rows += hint_rows("\n".join(l["title"] for l in est["lines"]))
    rows.append([Btn("✖️ Отмена", callback_data=f"w:{d}:cancel")])
    await show(update, context, text, rows, user=None, await_input={"kind": "x_search", "d": d})


async def start_own_room(update: Update, context: ContextTypes.DEFAULT_TYPE, name: str) -> None:
    """Название своего помещения получено: открываем конструктор (сначала замер, потом общий список работ)."""
    ud = context.user_data
    obj, kind = ud.pop("cur_obj", None), ud.pop("cur_kind", None)
    est = new_draft(update, context, "croom", obj, kind or "main")
    est.update(room="own", room_name=name[:40], icon="🏭", lines=[], name="", mz=new_mz(), mz_done=False, flt={})
    await show_extra(update, context)


# =============================================================================
# Калькулятор из Excel или текста
# =============================================================================
XC_INTRO = (
    "🧮 <b>Калькулятор из Excel</b>\nПосчитаю смету по вашему списку работ, цены берутся из вашего списка.\n\n"
    "📄 <b>Excel</b>: нажмите «Шаблон Excel», заполните (название работы, единица, количество, цена) и пришлите файл сюда.\n"
    "✍️ <b>Текст</b>: напишите работы сообщением, по строке на работу, например:\n"
    "<code>плитка 18 м² 3000\nшпаклёвка стен 40 м² 350\nрозетки 5 шт 800</code>\n\n"
    "Цены из файла или текста действуют только в этой смете и не меняют «Мои цены». "
    "Новый файл или текст заменяет список целиком."
)


def xc_state(context) -> dict:
    return context.user_data.setdefault("xc", {"lines": [], "bad": [], "src": "text"})


async def show_xcalc(update: Update, context: ContextTypes.DEFAULT_TYPE, note: str = "") -> None:
    user = db.get_user(update.effective_user.id)
    xc = xc_state(context)
    lines, bad = xc["lines"], xc["bad"]
    text = XC_INTRO
    if lines or bad:
        total = sum(round(l["qty"] * l["price"]) for l in lines)
        text = f"🧮 <b>Калькулятор из Excel</b>\n"
        if lines:
            text += f"Понял работ: <b>{len(lines)}</b> · {money(user, total)}\n"
            for l in lines[:12]:
                text += (f"• {esc(l['title'])}: {fnum(l['qty'])} {esc(l['unit'])} × {fnum(l['price'])} = "
                         f"{money(user, round(l['qty'] * l['price']))}\n")
            if len(lines) > 12:
                text += f"… и ещё {len(lines) - 12}\n"
        if bad:
            text += (f"\n⚠️ <b>Не понял строки ({len(bad)})</b>:\n"
                     + "\n".join(f"• {esc(b[:80])}" for b in bad[:15]) + (f"\n… и ещё {len(bad) - 15}" if len(bad) > 15 else "")
                     + "\n\nПоправьте их и пришлите список ещё раз целиком (текстом или новым файлом). "
                       "Формат строки: <code>название количество единица цена</code>.")
        elif lines:
            text += "\nМожно считать. Или пришлите другой список: он заменит этот."
    rows = []
    if lines:
        rows.append([Btn(f"✅ Посчитать ({len(lines)})" + (" без непонятых строк" if bad else ""), callback_data="xc:go")])
    rows.append([Btn("📄 Шаблон Excel", callback_data="xc:tpl")])
    if lines or bad:
        rows.append([Btn("🗑 Очистить список", callback_data="xc:clr")])
    rows.append([Btn("⬅️ В меню", callback_data="menu")])
    await show(update, context, (note + "\n\n" if note else "") + text, rows, user=user, await_input={"kind": "xcalc"})


async def xc_template(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.effective_chat.send_document(
        InputFile(io.BytesIO(xcalc.build_template()), filename="kalkulyator_shablon.xlsx"),
        caption="Шаблон: название работы, единица, количество, цена. Заполните и пришлите файл сюда.")
    await show_xcalc(update, context)


async def xc_set(update: Update, context: ContextTypes.DEFAULT_TYPE, items: list, bad: list, src: str) -> None:
    xc = xc_state(context)
    xc["lines"], xc["bad"], xc["src"] = items[:xcalc.MAX_ROWS], bad, src
    if not items and not bad:
        await show_xcalc(update, context, "⚠️ Не нашёл ни одной работы.")
        return
    await show_xcalc(update, context, "" if items else "⚠️ Ни одну строку не удалось разобрать.")


async def xc_on_file(update: Update, context: ContextTypes.DEFAULT_TYPE, doc, name: str) -> None:
    """Заполненный шаблон калькулятора: читаем, показываем найденное и строки, которые не поняли."""
    chat = update.effective_chat
    if not name.endswith(".xlsx"):
        await chat.send_message("⚠️ Нужен файл Excel с расширением .xlsx — тот шаблон, который я прислал. "
                                "Фото и PDF смет я не читаю: пришлите таблицу или текст.")
        return
    if (doc.file_size or 0) > xcalc.MAX_BYTES:
        await chat.send_message("⚠️ Файл слишком большой (больше 1 МБ).")
        return
    try:
        data = bytes(await (await doc.get_file()).download_as_bytearray())
        items, bad = xcalc.parse_file(data)
    except Exception:
        log.exception("Не удалось прочитать файл калькулятора")
        await chat.send_message("⚠️ Не получилось прочитать файл. Заполните шаблон и сохраните его как .xlsx.")
        return
    await xc_set(update, context, items, bad, "file")


async def xc_calculate(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Считает смету по списку калькулятора: это обычная смета комнаты со своими ценами, её можно сохранить и отправить."""
    ud = context.user_data
    xc = xc_state(context)
    if not xc["lines"]:
        await show_xcalc(update, context, "⚠️ Список пуст.")
        return
    new_lines = [{"title": l["title"], "unit": l["unit"], "price": l["price"], "qty": round(l["qty"], 2), "key": None,
                  "pend": False, "auto": False, "section": "calc", "part": None} for l in xc["lines"]]
    est = ud.get("est")
    obj, kind = ud.pop("cur_obj", None), ud.pop("cur_kind", None)
    if (est and est.get("type") == "croom" and est.get("room") == "calc" and not est.get("edit_id")
            and ud.get("draft_id") == est["id"]):
        if obj is not None:
            est["obj"], est["kind"] = obj, kind or "main"
    else:
        est = new_draft(update, context, "croom", obj, kind or "main")
        est["pool"] = None
    if est.get("lines") != new_lines:
        est["pool"] = None                      # список изменился: вопрос про общий прайс задаём заново
    est.update(room="calc", room_name="Расчёт из Excel" if xc["src"] == "file" else "Расчёт по тексту", icon="🧮",
               lines=new_lines, name="", mz=None, mz_done=True, flt={})
    est.pop("result", None)
    await croom_finish(update, context)


def calc_price_plan(uid: int, est: dict):
    """Что сделает «Сохранить эти цены»: обновит цены каталога (название и единица совпали) и добавит новые работы."""
    updates, news = [], []
    cat = [(k, it) for k, it in catalog.ITEM_BY_KEY.items() if k not in catalog.HIDDEN_DUPLICATES]
    for l in est["lines"]:
        key_norm = pool.norm_key(pool.clean_title(l["title"]) or l["title"])
        hit = next((k for k, it in cat if it["unit"] == l["unit"] and pool.norm_key(it["title"]) == key_norm), None)
        (updates if hit else news).append((hit, l["title"], l["unit"], l["price"]))
    return updates, news


async def calc_prices_ask(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    user = db.get_user(uid)
    est = context.user_data["est"]
    d = est["id"]
    updates, news = calc_price_plan(uid, est)
    text = ("💾 <b>Сохранить эти цены в «Мои цены»?</b>\n"
            f"Обновятся цены в вашем прайсе: {len(updates)}\n"
            + "".join(f"• {esc(catalog.ITEM_BY_KEY[k]['title'])} → {fnum(p)}/{esc(u)}\n" for k, t, u, p in updates[:8])
            + f"Добавятся новые работы в «Мои цены» (раздел подберу по названию): {len(news)}\n"
            + "".join(f"• {esc(t)} — {fnum(p)}/{esc(u)}\n" for k, t, u, p in news[:8])
            + "\nСохранённые сметы при смене цен не пересчитываются.")
    await show(update, context, text, [[Btn("✅ Сохранить", callback_data=f"xa:{d}:cpsok"),
                                       Btn("Нет", callback_data=f"w:{d}:results")]], user=user)


async def calc_prices_save(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    est = context.user_data["est"]
    updates, news = calc_price_plan(uid, est)
    for k, t, u, p in updates:
        db.set_price(uid, k, p)
    for k, t, u, p in news:
        db.add_custom_item(uid, t, u, p)
    await show_croom_result(update, context, f"✅ Цены сохранены в «Мои цены»: обновлено {len(updates)}, "
                                             f"новых работ {len(news)}.")


async def calc_pool_answer(update: Update, context: ContextTypes.DEFAULT_TYPE, yes: bool) -> None:
    """Ответ на «Добавить услуги и цены в общий прайс, анонимно?». Да — уходят только название, единица и цена."""
    uid = update.effective_user.id
    est = context.user_data["est"]
    est["pool"] = "y" if yes else "n"
    if not yes:
        await show_croom_result(update, context, "Хорошо, в общий прайс ничего не отправлено.")
        return
    stat = pool.submit([(l["title"], l["unit"], l["price"]) for l in est["lines"]], db.get_user(uid))
    note = (f"🌐 Спасибо! Анонимно добавлено в общий прайс: {stat['added']}"
            + (f", на проверку: {stat['pending']}" if stat["pending"] else "")
            + (f", отброшено (цена сильно отличается от обычной или название не разобрать): {stat['dropped']}"
               if stat["dropped"] else "") + ".")
    await show_croom_result(update, context, note)


# =============================================================================
# Команды владельца: «новые названия» и «статистика»
# =============================================================================
PN_SHOWN = 10


async def show_pending(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Команда владельца «новые названия»: названия из загруженных смет, которых нет в каталоге (в общий прайс не попали)."""
    groups = db.pending_groups()
    if not groups:
        await update.effective_chat.send_message("Новых названий на проверку нет.")
        return
    await update.effective_chat.send_message(
        f"🆕 <b>Новые названия</b> на проверку: {len(groups)}"
        + (f", показаны первые {PN_SHOWN}" if len(groups) > PN_SHOWN else "")
        + "\nВ общий прайс они не попадают, пока вы не объедините их с существующей услугой или не одобрите.",
        parse_mode=ParseMode.HTML)
    for g in groups[:PN_SHOWN]:
        sym = catalog.CURRENCIES.get(g["currency"], {"symbol": g["currency"]})["symbol"]
        price = (f"{fnum(g['pmin'])}" if g["pmin"] == g["pmax"] else f"{fnum(g['pmin'])}–{fnum(g['pmax'])}")
        best = pool.suggest(g["title"], 1)
        similar = f"\nПохоже на: «{esc(best[0][1])}» ({round(best[0][2] * 100)}%)" if best and best[0][2] >= 0.5 else ""
        await update.effective_chat.send_message(
            f"<b>{esc(g['title'])}</b> · {esc(g['unit'])}\nЗагрузок: {g['n']} · цена {price} {sym}{similar}",
            reply_markup=InlineKeyboardMarkup([
                [Btn("🔗 Объединить с существующей", callback_data=f"pn:m:{g['id']}")],
                [Btn("✅ Одобрить", callback_data=f"pn:ok:{g['id']}"), Btn("🗑 Отклонить", callback_data=f"pn:no:{g['id']}")]]),
            parse_mode=ParseMode.HTML)


async def show_merge_choices(update: Update, context: ContextTypes.DEFAULT_TYPE, row_id: int, query: str = "") -> None:
    rows_ = db.pending_rows(row_id)
    if not rows_:
        await update.effective_chat.send_message("Эта группа уже обработана.")
        return
    title = rows_[0]["title"]
    if query:
        q = pool.norm_key(query).split()
        found = [(ref, t, pool.similarity(query, t)) for ref, t in pool.known_names()
                 if any(w in pool.norm_key(t) for w in q)][:8]
    else:
        found = pool.suggest(title, 8)
    btns = [[Btn(f"{t} ({round(s * 100)}%)"[:60], callback_data=f"pn:mt:{row_id}:{ref}")] for ref, t, s in found]
    btns.append([Btn("🔎 Искать по слову", callback_data=f"pn:s:{row_id}"), Btn("⬅️ Назад", callback_data="pn:l")])
    await show(update, context, f"🔗 С какой услугой объединить «{esc(title)}»?\nЕё загрузки перейдут под выбранное название.",
               btns, await_input=None)


async def cb_pending(update: Update, context: ContextTypes.DEFAULT_TYPE, p: list) -> None:
    q = update.callback_query
    if not is_owner(update.effective_user.id):
        return
    sub = p[1]
    if sub == "l":
        await show_pending(update, context)
    elif sub == "m":
        await show_merge_choices(update, context, int(p[2]))
    elif sub == "s":
        await show(update, context, "🔎 Напишите слово: найду среди каталога и одобренных названий.",
                   [[Btn("⬅️ Назад", callback_data=f"pn:m:{p[2]}")]], await_input={"kind": "pnsearch", "id": int(p[2])})
    elif sub == "mt":
        res = pool.merge_pending(int(p[2]), p[3])
        msg = (f"🔗 Объединено с «{esc(res[0])}»: в общий прайс добавлено {res[1]['added']}"
               + (f", отброшено {res[1]['dropped']} (цена в разы от обычной)" if res[1]["dropped"] else "") + "."
               if res else "Эта группа уже обработана.")
        await update.effective_chat.send_message(msg, parse_mode=ParseMode.HTML)
    elif sub == "ok":
        res = pool.approve_pending(int(p[2]))
        msg = (f"✅ Одобрено: «{esc(res[0])}». В общий прайс добавлено {res[1]['added']}"
               + (f", отброшено {res[1]['dropped']}" if res[1]["dropped"] else "") + "."
               if res else "Эта группа уже обработана.")
        await update.effective_chat.send_message(msg, parse_mode=ParseMode.HTML)
    elif sub == "no":
        db.pending_delete(int(p[2]))
        await update.effective_chat.send_message("🗑 Название отклонено, его загрузки удалены.")


async def show_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Команда владельца «статистика»: тихий счётчик (людям не показывается)."""
    s = db.stats_summary()
    votes = db.vote_counts()
    text = ("📊 <b>Статистика</b>\n"
            f"Пользователей: {s['users']} (прошли настройку: {s['ready']}, в списке ожидания: {s['waitlist']})\n"
            f"Начато смет: {s['started']}\n"
            f"Завершено (сохранено) смет: {s['saved']}\n"
            f"Смет в базе сейчас: {s['estimates_now']}, из них в статусе «Завершена»: {s['done_now']}\n"
            f"Новых названий на проверку: {s['pending']}\n"
            f"Бесплатные места: занято {s['joined']} из {db.free_limit()}, срок кончился у {s['expired']}\n"
            f"Приглашения: зашли по ссылкам {s['invited']}, посчитали смету {s['invited_counted']}, "
            f"бонусов начислено {s['bonus_paid']}\n"
            f"Под сметами: «Верно» — {votes.get('ok', 0)}, «Есть ошибка» — {votes.get('bug', 0)} "
            f"(новых ошибок в «пожеланиях»: {s['bugs_new']})")
    top = db.popular_works(15)
    if top:
        text += "\n\n<b>Популярные работы</b> (в сохранённых сметах):\n" + "\n".join(
            f"{i}. {esc(r['key'])} — {r['n']}" for i, r in enumerate(top, 1))
    await update.effective_chat.send_message(text, parse_mode=ParseMode.HTML)


async def cmd_newnames(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if is_owner(update.effective_user.id):
        await show_pending(update, context)


async def cmd_stats(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    if is_owner(update.effective_user.id):
        await show_stats(update, context)


# --- Команды владельца: прайс, ники, подсказки ----------------------------------------
def sections_report_text(rep: dict) -> str:
    """Итог разовой уборки в «Мои цены» (удалённые дубли и раскладка по разделам)."""
    def moved_line(moved: dict) -> str:
        return ", ".join(f"{esc(k)} — {v}" for k, v in sorted(moved.items(), key=lambda kv: -kv[1])) or "ничего"
    me, ot = rep["owner"], rep["others"]
    out = ["🧹 <b>Порядок в «Мои цены»</b> (разово после обновления)",
           f"<b>У вас:</b> удалено точных дублей (название, единица и цена совпали): <b>{me['removed']}</b>.",
           f"Разложено по разделам: {moved_line(me['moved'])}.",
           f"Без раздела осталось: <b>{me['left']}</b>" + (" — список пришлю по команде «без раздела»." if me["left"] else ".")]
    if me["same_name_other_price"]:
        out.append(f"Одинаковые название и единица, но разная цена: {me['same_name_other_price']} — не удалял, решите сами.")
    if ot["removed"] or ot["moved"] or ot["left"]:
        out.append(f"У остальных мастеров: удалено дублей {ot['removed']}, разложено {ot['moved']}, без раздела {ot['left']}.")
    if rep.get("backup"):
        out.append(f"Копия базы перед уборкой: {esc(rep['backup'])} (папка backups).")
    return "\n".join(out)


async def notify_sections_report(app: Application) -> None:
    """При запуске: если разовая уборка в «Мои цены» только что прошла, владельцу приходит отчёт."""
    owner = load_env("OWNER_ID")
    rep = db.take_sections_report()
    if not rep or not owner.isdigit():
        return
    try:
        await app.bot.send_message(int(owner), sections_report_text(rep), parse_mode=ParseMode.HTML)
    except Exception:
        log.exception("Не удалось отправить владельцу отчёт об уборке в «Мои цены»")


async def send_unsorted(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Команда владельца «без раздела»: его собственные услуги, которые бот не уверен, куда положить (файл Excel)."""
    uid = update.effective_user.id
    rows = db.list_section_items(uid, 0)
    if not rows:
        await update.effective_chat.send_message("У вас нет услуг «Без раздела»: всё разложено.")
        return
    from openpyxl import Workbook
    from openpyxl.styles import Font
    wb = Workbook()
    ws = wb.active
    ws.title = "Без раздела"
    ws.append([pricefile.HEAD_SERVICE, pricefile.HEAD_UNIT, pricefile.HEAD_PRICE])
    for cell in ws[1]:
        cell.font = Font(bold=True)
    for r in rows:
        ws.append([r["title"], r["unit"], r["price"]])
    ws.column_dimensions["A"].width = 60
    buf = io.BytesIO()
    wb.save(buf)
    shown = rows[:UNSORTED_SHOWN]   # список текстом, по левому краю; всё остальное (и цены) — в файле
    lines = [f"{i}. {esc(r['title'])} — {fnum(r['price'])}/{esc(r['unit'])}" for i, r in enumerate(shown, 1)]
    text = (f"📋 <b>Услуги без раздела: {len(rows)}</b> (не уверен, куда их положить — проверьте).\n\n" + "\n".join(lines)
            + (f"\n… и ещё {len(rows) - len(shown)}: они в файле ниже." if len(rows) > len(shown) else "")
            + "\n\nРазложить: «Мои цены» → «Без раздела» → «Разделить» (можно выбрать существующую группу или назвать новую).")
    for chunk in split_text(text):
        await update.effective_chat.send_message(chunk, parse_mode=ParseMode.HTML)
    await update.effective_chat.send_document(InputFile(io.BytesIO(buf.getvalue()), filename="bez_razdela.xlsx"))


UNSORTED_SHOWN = 150


async def run_assign_sections(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Команда владельца «разложить»: услуги «Без раздела» раскладываются по группам по названию (правила в sections.py).
    Услуги, которые уже лежат в группах, не двигаются. Перед этим — копия базы. Сомнительные остаются «Без раздела»."""
    uid = update.effective_user.id
    send = update.effective_chat.send_message
    n = len(db.list_section_items(uid, 0))
    if not n:
        await send("Все ваши услуги уже в группах, «Без раздела» пусто.")
        return
    path = db.backup_file("before_assign")
    if not path:
        await send("⚠️ Копию базы сделать не получилось, поэтому ничего не двигаю.")
        return
    res = db.assign_sections(uid)
    moved = ", ".join(f"{esc(k)} — {v}" for k, v in sorted(res["moved"].items(), key=lambda kv: -kv[1])) or "ничего"
    await send(f"🧩 <b>Разложил по группам</b> (было «Без раздела»: {n}).\nПереложено: {moved}.\n"
               f"Осталось «Без раздела» (не уверен): <b>{res['left']}</b>.\nКопия базы до этого: {esc(path.name)} (папка backups).",
               parse_mode=ParseMode.HTML)
    if res["left"]:
        await send_unsorted(update, context)


async def show_duplicates_check(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Команда владельца «дубли»: считает копии его услуг (одинаковые название, единица и цена), ничего не удаляя.
    Удаление — отдельной кнопкой, после копии базы."""
    uid = update.effective_user.id
    c = db.count_duplicates(uid)
    other = (f"\nУслуг с тем же названием, но другой ценой: {c['same_name_other_price']} — их не трогаю." if c["same_name_other_price"] else "")
    if not c["extra"]:
        await update.effective_chat.send_message(f"🔎 Проверил ваши услуги: всего {c['items']}. Дублей нет, удалять нечего.{other}")
        return
    await update.effective_chat.send_message(
        f"🔎 Ваших услуг: {c['items']}. Найдено дублей (одинаковые название, единица и цена): <b>{c['extra']}</b>.{other}\n"
        f"Если удалить, останется {c['items'] - c['extra']}: по одной услуге из каждой группы копий. "
        "Перед удалением я сделаю копию базы; сметы, где была удалённая копия, переключатся на оставшуюся.",
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup([[Btn("🧹 Удалить дубли", callback_data="dup:ok"), Btn("Не надо", callback_data="dup:no")]]))


async def run_duplicates_cleanup(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Кнопка «Удалить дубли» (только владелец): копия базы → удаление → отчёт «найдено / удалено / осталось»."""
    uid = update.effective_user.id
    q = update.callback_query
    before = db.count_duplicates(uid)
    if not before["extra"]:
        await q.edit_message_text(f"Дублей нет, удалять нечего (услуг: {before['items']}).")
        return
    path = db.backup_file("before_dedupe")
    if not path:
        await q.edit_message_text("⚠️ Копию базы сделать не получилось, поэтому ничего не удаляю.")
        return
    res = db.dedupe_custom_items(uid)
    after = db.count_duplicates(uid)
    await q.edit_message_text(f"✅ Дублей найдено: {before['extra']}, удалено: {res['removed']}. "
                              f"Услуг было {before['items']}, стало {after['items']}.\nКопия базы до удаления: {path.name}")


async def owner_extra_commands(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str, low: str) -> bool:
    """«без раздела», «дубли», «активные», «резерв», «подарить ник <номер> <ник>», «итоги разделов», «подсказки».
    True — команда была, обработана."""
    send = update.effective_chat.send_message
    if low == "без раздела":
        await send_unsorted(update, context)
    elif low in ("разложить", "разложить по группам"):
        await run_assign_sections(update, context)
    elif low in ("дубли", "проверка дублей"):
        await show_duplicates_check(update, context)
    elif low == "итоги разделов":
        rep = db.sections_report()
        await send(sections_report_text(rep) if rep else "Уборка в «Мои цены» ещё не запускалась.", parse_mode=ParseMode.HTML)
    elif low == "активные":
        rows = db.active_users(15)
        lines = [f"{i}. {esc(db.user_label(r['user_id']))} · смет: {r['n_est']} · своих работ: {r['n_items']}"
                 for i, r in enumerate(rows, 1)]
        await send("🔥 <b>Самые активные</b> (по сохранённым сметам)\n" + ("\n".join(lines) or "Пока никого.")
                   + "\n\nПодарить красивый ник: «подарить ник НОМЕР Прораб». Список ников: «резерв».", parse_mode=ParseMode.HTML)
    elif low == "резерв" or low.startswith("резерв добавить "):
        if low.startswith("резерв добавить "):
            nick = re.sub(r"\s+", " ", text.strip().lstrip("/")[len("резерв добавить "):]).strip()
            note = (f"✅ «{esc(nick)}» добавлен в резерв.\n\n" if db.add_reserved_nick(nick)
                    else f"⚠️ «{esc(nick)}» не добавлен: он уже в резерве или его занял человек.\n\n")
        else:
            note = ""
        lines = []
        for r in db.list_reserved_nicks():
            who = (f"подарен: {esc(db.user_label(r['gifted_to']))}" if r["gifted_to"] else "свободен")
            lines.append(f"• {esc(r['nick'])} — {who}")
        await send(note + "💎 <b>Красивые ники</b> (случайно не выдаются, занять самому нельзя)\n" + "\n".join(lines)
                   + "\n\nДобавить: «резерв добавить Бригадир». Подарить: «подарить ник НОМЕР Прораб».", parse_mode=ParseMode.HTML)
    elif low.startswith("подарить ник"):
        parts = text.strip().split(None, 3)    # подарить ник 123456 Прораб
        if len(parts) < 4 or not parts[2].isdigit():
            await send("Напишите так: подарить ник НОМЕР_ПОЛЬЗОВАТЕЛЯ Ник\nНапример: подарить ник 123456 Прораб")
            return True
        target, nick = int(parts[2]), re.sub(r"\s+", " ", parts[3]).strip()
        res = db.gift_nick(target, nick)
        msg = {"ok": f"🎁 Ник «{esc(nick)}» подарен: {esc(db.user_label(target))}.",
               "no_user": "Пользователя с таким номером нет.",
               "not_reserved": "Такого ника нет в резерве. Список — «резерв»; добавить — «резерв добавить Ник».",
               "gifted": "Этот ник уже подарен другому человеку."}[res]
        await send(msg, parse_mode=ParseMode.HTML)
        if res == "ok":
            try:   # человеку сообщаем о подарке
                await context.bot.send_message(target, f"🎁 Вам подарили особый ник: <b>{esc(nick)}</b>. Спасибо, что пользуетесь ботом!",
                                               parse_mode=ParseMode.HTML)
            except Exception:
                await send("(Человеку сообщить не удалось — возможно, он не запускал бота или остановил его.)")
    elif low == "подсказки":
        lines = [f"<b>{esc(h[1])}</b>: {esc(h[3])}" for h in hints.HINTS]
        drafts = [f"<b>{esc(h[1])}</b>: {esc(h[3])}" + (f"\n⚠️ <i>проверить: {esc(h[4])}</i>" if len(h) > 4 else "")
                  for h in hints.DRAFT_HINTS]
        text = "📖 <b>Подсказки «Что это?»</b> — показываются людям:\n\n" + "\n\n".join(lines)
        if drafts:
            text += ("\n\n📝 <b>Черновики</b> (людям НЕ показываются, ждут вашей проверки):\n\n" + "\n\n".join(drafts))
        for chunk in split_text(text):
            await send(chunk, parse_mode=ParseMode.HTML)
    else:
        return False
    return True


# =============================================================================
# Обработчик кнопок
# =============================================================================
WIZARD_CMDS = {"sep", "stage", "bk", "a", "m", "md", "w", "ed", "save", "sv", "pc", "aw", "xa", "dm", "adj", "dy"}


async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    q = update.callback_query
    p = (q.data or "").split(":")
    cmd = p[0]
    uid = update.effective_user.id
    ud = context.user_data

    # --- Первичная настройка и настройки (профиль может быть ещё не готов)
    if cmd == "cc" and p[1] in catalog.COUNTRIES:
        await q.answer()
        await choose_country(update, context, p[1])
        return
    user = db.get_user(uid)
    if not user:  # профиля нет — начинаем сначала
        await q.answer()
        await start_onboarding(update, context)
        return
    if cmd == "settings":
        await q.answer()
        await show_settings(update, context)
        return
    if cmd == "set":
        await q.answer()
        if p[1] == "country":
            await show(update, context, "🌍 Выберите страну:", country_rows(), user=user)
        elif p[1] == "city":
            await show(update, context, "🏙 Напишите ваш город:", [[Btn("⬅️ Назад", callback_data="settings")]],
                       user=user, await_input={"kind": "city"})
        elif p[1] == "nick" and user["ready"]:
            await ask_nick(update, context, entry=False)
        elif p[1] == "daymin" and user["ready"]:
            if user["day_min_on"]:   # выключаем; сумма за день остаётся запомненной
                db.update_user(uid, day_min_on=0)
                await show_settings(update, context, "📅 Минимум по дням выключен. Смета считается по минимальному выезду.")
            elif (user["day_rate"] or 0) > 0:
                db.update_user(uid, day_min_on=1)
                await show_settings(update, context, "📅 Минимум по дням включён. В смете появится кнопка «Дней работы».")
            else:
                await ask_day_rate(update, context)
        elif p[1] == "dayrate" and user["ready"]:
            await ask_day_rate(update, context)
        elif p[1] == "lang":
            suggested = catalog.COUNTRIES[user["country"]]["langs"]
            rows = [[Btn(("⭐ " if code in suggested else "") + name, callback_data=f"lg:{code}")]
                    for code, name in catalog.LANGS.items()]
            await show(update, context, "🗣 Выберите язык (⭐ — подходит для вашей страны):", rows, user=user)
        elif p[1] == "cur":
            suggested = catalog.COUNTRIES[user["country"]]["currency"]
            rows = [[Btn(("⭐ " if code == suggested else "") + c["name"], callback_data=f"cu:{code}")]
                    for code, c in catalog.CURRENCIES.items()]
            await show(update, context, "💱 Выберите валюту (⭐ — для вашей страны):", rows, user=user)
        return
    if cmd == "lg" and p[1] in catalog.LANGS:
        await q.answer()
        db.update_user(uid, lang=p[1])
        await show_settings(update, context)
        return
    if cmd == "cu" and p[1] in catalog.CURRENCIES:
        await q.answer()
        db.update_user(uid, currency=p[1])
        note = "⚠️ Цены в прайсе не пересчитываются сами — проверьте их в «Мои цены»." if user["ready"] else ""
        await show_settings(update, context, note)
        return
    if cmd == "done":
        await q.answer()
        if not user["city"]:
            await show(update, context, "🏙 Сначала напишите ваш город:", [], user=user, await_input={"kind": "city"})
        else:
            await finish_onboarding(update, context)
        return
    if not user["ready"]:  # остальное доступно после первичной настройки
        await q.answer()
        await show_settings(update, context)
        return

    # --- Вход: подписка, политика, ник, тестовый режим (идут до проверки входа и срока)
    if cmd == "sub":
        await sub_check(update, context)
        return
    if cmd == "pol":
        await q.answer()
        if p[1] == "ok" and not user["policy_ok"]:
            db.update_user_fields(uid, policy_ok=db.now().strftime(db.DATE_FMT))
            await entry_continue(update, context)
        elif p[1] == "ok":
            await entry_continue(update, context)
        else:
            await show_policy_consent(update, context)
        return
    if cmd == "polv":
        await q.answer()
        await show_policy_full(update, context, p[1] if len(p) > 1 else "m")
        return
    if cmd == "nick" and p[1] == "skip":
        await q.answer()
        await skip_nick(update, context)
        return
    if cmd == "wl":
        await q.answer()
        if user["joined"] is not None:
            db.update_user_fields(uid, welcomed=1)
        await entry_continue(update, context)
        return
    if cmd == "wish":   # «Пожелания» открыты всегда, даже когда срок теста кончился
        await q.answer()
        await ask_wish(update, context)
        return
    if await entry_block(update, context, user, p):   # вход не пройден или срок кончился: дальше не пускаем
        await q.answer()
        return

    # --- Навигация
    if cmd == "menu":
        await q.answer()
        await send_menu(update, context)
        return
    if cmd == "fb":
        await cb_feedback(update, context, p)
        return
    if cmd == "help":
        await q.answer()
        await show_help(update, context)
        return
    if cmd == "pf":
        await q.answer()
        await pf_confirm(update, context, p)
        return
    if cmd == "dup" and is_owner(uid):   # «дубли» у владельца: p[1] — ok (удалить) или no
        await q.answer()
        if p[1] == "ok":
            await run_duplicates_cleanup(update, context)
        else:
            await q.edit_message_text("Хорошо, ничего не удаляю.")
        return
    if cmd == "pm" and p[1] == "start":
        await q.answer()
        await start_prices(update, context)
        return
    if cmd == "hint":   # «Что это?»: короткое объяснение всплывающим окном, экран не меняется
        await q.answer(hints.explain(p[1])[:200] or "Подсказки к этому слову пока нет.", show_alert=True)
        return
    if cmd == "faq":
        await q.answer()
        await show_faq(update, context, int(p[1]) if len(p) > 1 and p[1].isdigit() else None)
        return
    if cmd == "inv":
        await q.answer()
        await show_invite(update, context)
        return

    # --- Цены
    if cmd == "price":
        await q.answer()
        if p[1] == "list":
            await show_price_groups(update, context)
        elif p[1] == "g":
            await show_price_group(update, context, int(p[2]), int(p[3]) if len(p) > 3 else 0)
        elif p[1] in ("s", "sm", "smt", "smok", "sp", "spto", "spt", "spp", "spall", "spnone", "spgo"):
            await price_section_action(update, context, p)
        elif p[1] == "file":
            await pf_start(update, context, "price:list")
        elif p[1] == "e" and (p[2] in catalog.ITEM_BY_KEY or custom_id(p[2]) is not None):
            rows = []
            if p[2] in catalog.ITEM_BY_KEY:
                item = catalog.ITEM_BY_KEY[p[2]]
            else:  # своя работа
                item = db.get_custom_item(uid, custom_id(p[2]))
                if not item:
                    await show_price_groups(update, context)
                    return
                item = {"title": item["title"], "unit": item["unit"], "note": ""}
                rows.append([Btn("🗑 Убрать из «Мои цены»", callback_data=f"price:cdel:{custom_id(p[2])}")])
            cur_price = price_of(uid, p[2])
            now = "не указана" if cur_price <= 0 else f"{fnum(cur_price)} за {item['unit']}"
            note = f"\n{item['note']}" if item.get("note") else ""
            rows.append([Btn("⬅️ Отмена", callback_data=price_back(ud, p[2], uid))])
            await show(update, context, f"✏️ <b>{esc(item['title'])}</b>\nСейчас: {now}.{note}\n\n"
                                        "Напишите новую цену числом:",
                       rows, user=user, await_input={"kind": "price", "key": p[2]})
        elif p[1] == "cdel" and db.get_custom_item(uid, int(p[2])):
            item = db.get_custom_item(uid, int(p[2]))
            await show(update, context, f"🗑 Убрать «{esc(item['title'])}» из «Мои цены»? "
                                        "В уже сохранённых сметах эта работа останется.",
                       [[Btn("Да, убрать", callback_data=f"price:cdelok:{p[2]}"),
                         Btn("Нет", callback_data=f"price:e:c{p[2]}")]], user=user)
        elif p[1] == "cdelok":
            db.delete_custom_item(uid, int(p[2]))
            pv = ud.get("pv") or []
            if len(pv) == 3 and pv[0] == "s":   # вернуться в раздел, где была услуга (если он ещё есть)
                await show_price_page(update, context, "s", pv[1], pv[2])
            else:
                await show_price_groups(update, context)
        elif p[1] == "min":
            await show(update, context, f"💶 <b>Минимальный выезд</b>\nСейчас: {money(user, user['min_total'])}.\n"
                                        "Если смета получится дешевле, она будет поднята до этой суммы.\n\n"
                                        "Напишите новую сумму числом:",
                       [[Btn("⬅️ Отмена", callback_data="price:list")]], user=user,
                       await_input={"kind": "min"})
        return

    # --- Своё помещение, калькулятор, заметки, команды владельца
    if cmd == "room" and p[1] == "own":
        await q.answer()
        await ask_own_room(update, context)
        return
    if cmd == "small" and p[1] == "start":   # режим «Мелкие работы»
        await q.answer()
        await start_small(update, context)
        return
    if cmd == "open" and p[1] == "start":    # режим «Объект без стен»
        await q.answer()
        await start_open(update, context)
        return
    if cmd == "xc":
        await q.answer()
        sub = p[1]
        if sub == "tpl":
            await xc_template(update, context)
        elif sub == "go":
            await xc_calculate(update, context)
        elif sub == "clr":
            ud["xc"] = {"lines": [], "bad": [], "src": "text"}
            await show_xcalc(update, context)
        elif sub == "back":
            await show_xcalc(update, context)
        else:
            ud["xc"] = {"lines": [], "bad": [], "src": "text"}   # вход из меню: чистый список
            await show_xcalc(update, context)
        return
    if cmd == "nt" and len(p) >= 2:
        await q.answer()
        target = p[1]
        if target[:1] == "d" and target[1:].isdigit() and not await activate(update, context, int(target[1:])):
            return
        if len(p) > 2 and p[2] == "x" and note_target(user, context, target):   # удалить заметку
            await save_note(update, context, user, target, "")
        else:
            await show_note(update, context, user, target)
        return
    if cmd == "pn":
        await q.answer()
        await cb_pending(update, context, p)
        return

    # --- Открытые сметы
    if cmd == "drl":
        await q.answer()
        await show_drafts(update, context)
        return
    if cmd == "dr":
        await q.answer()
        if await activate(update, context, int(p[1])):
            await resume_est(update, context)
        return
    if cmd == "drdel":
        await q.answer()
        row = db.get_draft(uid, int(p[1]))
        if not row:
            await show_drafts(update, context)
            return
        await show(update, context, f"🔄 Точно сбросить смету «{esc(row['title'])}»? Все ответы пропадут.",
                   [[Btn("Да, сбросить", callback_data=f"drdelok:{p[1]}"), Btn("Нет", callback_data="drl")]], user=user)
        return
    if cmd == "drdelok":
        await q.answer()
        drop_draft(update, context, int(p[1]))
        await show_drafts(update, context)
        return

    # --- Объекты
    if cmd == "obj":
        await q.answer()
        await cb_object(update, context, user, p)
        return
    if cmd == "tiler":
        await q.answer()
        await show_tiler(update, context)
        return
    if cmd == "est":
        await q.answer()
        await cb_estimate(update, context, user, p)
        return

    # --- Кнопки из сообщений старой версии бота (без номера сметы) больше не работают
    if (cmd in WIZARD_CMDS or cmd in ("sh", "shp")) and not (p[1].isdigit() or (p[1][:1] == "d" and p[1][1:].isdigit())):
        await q.answer("Эта кнопка устарела — откройте меню.", show_alert=True)
        await send_menu(update, context)
        return

    # --- Поделиться
    if cmd == "sh":
        await q.answer()
        await ask_share(update, context, p[1])
        return
    if cmd == "shp":
        await q.answer("Готовлю PDF…")
        await send_pdf(update, context, p[1], "short" if p[2] in ("s", "0") else "detailed")
        return

    # --- Новая смета: ничего старого не сбрасывается, открытые сметы остаются
    if cmd == "room" and p[1] in ROOM_NAME:
        await q.answer()
        await start_room(update, context, p[1])
        return
    if cmd == "crm" and p[1] in ROOM_NAME and p[1] not in READY_ROOMS:
        await q.answer()
        await start_croom(update, context, p[1])
        return

    # --- Кнопки мастера: в них всегда номер сметы (p[1])
    if cmd in WIZARD_CMDS:
        est = await activate(update, context, int(p[1]))
        if est is None:
            return
        p = [cmd] + p[2:]
        await cb_wizard(update, context, user, cmd, p, est)
        return
    await q.answer()


async def cb_object(update: Update, context: ContextTypes.DEFAULT_TYPE, user, p: list) -> None:
    uid, ud = user["user_id"], context.user_data
    sub = p[1]
    if sub == "list":
        await show_objects(update, context)
    elif sub == "closed":
        await show_closed_objects(update, context)
    elif sub == "st" and p[2] in STATUS_NAME:   # сметы по статусам, по всем объектам
        await show_status_list(update, context, p[2])
    elif sub == "flt" and p[3] in dict(OBJ_FILTERS):   # статусы смет внутри объекта
        flt = ud.setdefault("obj_flt", {}) or {}
        flt[p[2]] = p[3]
        ud["obj_flt"] = flt
        await show_object(update, context, int(p[2]))
    elif sub == "new":
        await show(update, context, "🏠 Напишите адрес или имя клиента для нового объекта:",
                   [[Btn("⬅️ Отмена", callback_data="obj:list")]], user=user,
                   await_input={"kind": "objname", "then": "list"})
    elif sub == "unlink":
        ud.pop("cur_obj", None)
        ud.pop("cur_kind", None)
        await send_menu(update, context)
    elif sub == "add":
        ud["cur_obj"], ud["cur_kind"] = int(p[2]), "main"
        await send_menu(update, context)
    elif sub == "xadd":
        await show(update, context, "➕ <b>Допработа</b>\nОсновная смета объекта не изменится — допработа считается отдельно. "
                                    "Что добавляем?",
                   [[Btn("🧰 Небольшие работы (по строкам)", callback_data=f"obj:xline:{p[2]}")],
                    [Btn("🏠 Новая комната (отдельная смета)", callback_data=f"obj:xroom:{p[2]}")],
                    [Btn("⬅️ Назад", callback_data=f"obj:{p[2]}")]], user=user)
    elif sub == "xline":
        obj = db.get_object(uid, int(p[2]))
        if obj and (obj["status"] or "open") == "open":
            new_draft(update, context, "extra", obj["id"], "extra").update(lines=[], name="")
            await show_extra(update, context)
        else:
            await show_objects(update, context)
    elif sub == "xroom":
        ud["cur_obj"], ud["cur_kind"] = int(p[2]), "extra"
        await send_menu(update, context)
    elif sub == "ren":
        await show(update, context, "✏️ Напишите новое название объекта:",
                   [[Btn("⬅️ Отмена", callback_data=f"obj:{p[2]}")]], user=user,
                   await_input={"kind": "objren", "id": int(p[2])})
    elif sub == "done":
        await show(update, context, "✅ Завершить объект? Новые сметы и допработы добавлять будет нельзя, "
                                    "пока вы не вернёте его в работу. Все сметы останутся.",
                   [[Btn("Да, завершить", callback_data=f"obj:doneok:{p[2]}"), Btn("Нет", callback_data=f"obj:{p[2]}")]],
                   user=user)
    elif sub == "doneok":
        if db.get_object(uid, int(p[2])):
            db.set_object_status(int(p[2]), "done")
        await show_object(update, context, int(p[2]))
    elif sub == "reopen":
        if db.get_object(uid, int(p[2])):
            db.set_object_status(int(p[2]), "open")
        await show_object(update, context, int(p[2]))
    elif sub == "del":
        await show(update, context, "🗑 Удалить объект вместе со всеми сметами внутри?",
                   [[Btn("Да, удалить", callback_data=f"obj:delok:{p[2]}"), Btn("Нет", callback_data=f"obj:{p[2]}")]],
                   user=user)
    elif sub == "delok":
        if db.get_object(uid, int(p[2])):
            db.delete_object(int(p[2]))
        await show_objects(update, context)
    elif sub.isdigit():
        await show_object(update, context, int(sub))


async def cb_estimate(update: Update, context: ContextTypes.DEFAULT_TYPE, user, p: list) -> None:
    uid = user["user_id"]
    sub = p[1]
    if sub.isdigit():
        await show_saved_estimate(update, context, int(sub))
        return
    est_id = int(p[2])
    row = db.get_estimate(uid, est_id)
    if not row:
        await show_objects(update, context)
        return
    st = est_status(row)
    if sub == "st":
        await show_status_menu(update, context, est_id)
        return
    if sub in ("sts", "stok"):
        await set_status(update, context, est_id, "done" if sub == "stok" else p[3], confirmed=sub == "stok")
        return
    # --- всё, что меняет смету: в архиве нельзя, у сметы «В работе» основные строки защищены
    if st == "done":
        await show_saved_estimate(update, context, est_id,
                                  "🗄 Смета в архиве, изменить её нельзя. Нажмите «Вернуть для доработки», если нужно править.")
        return
    if sub in ("addw", "pc", "del", "delok") and is_protected(row):
        await show_saved_estimate(update, context, est_id,
                                  "🛠 Смета «В работе»: основные строки защищены. Новые работы — кнопкой «Доп. работы», "
                                  "правка самой сметы — кнопкой «Изменить».")
        return
    if sub == "xw":
        if is_protected(row):
            await start_extra_for(update, context, row)
        else:
            await show_saved_estimate(update, context, est_id,
                                      "➕ «Доп. работы» доступны у сметы в статусе «В работе». У открытой сметы правьте строки напрямую.")
    elif sub == "edit" and is_protected(row):   # правка защищённой сметы: сначала подтверждение
        await show(update, context, f"✏️ Смета «{esc(row['title'])}» в работе, её основные строки защищены. "
                                    "Изменить саму смету всё равно?",
                   [[Btn("Да, изменить", callback_data=f"est:editok:{est_id}"), Btn("Нет", callback_data=f"est:{est_id}")]],
                   user=user)
    elif sub in ("edit", "editok"):
        est = await load_saved_into_draft(update, context, est_id)
        if est:
            if est["type"] in ("extra", "croom"):
                await show_extra(update, context)
            else:
                await advance(update, context)  # сначала доспросит новые вопросы (если они появились), потом экран правок
    elif sub in ("addw", "pc"):
        est = await load_saved_into_draft(update, context, est_id)
        if est and est["type"] == "room":
            recalc(est, uid, user)
            if sub == "addw":
                est["tmp"] = {}
                await aw_ask(update, context, "title")
            else:
                await show_price_list(update, context)
    elif sub == "del":
        more = " вместе с её допработами" if db.list_children(uid, est_id) else ""
        await show(update, context, f"🗑 Удалить эту смету{more}?",
                   [[Btn("Да, удалить", callback_data=f"est:delok:{est_id}"), Btn("Нет", callback_data=f"est:{est_id}")]],
                   user=user)
    elif sub == "delok":
        db.delete_estimate(uid, est_id)
        if row["kind"] == "extra" and row["parent_id"]:
            await show_saved_estimate(update, context, row["parent_id"], "🗑 Допработа удалена.")
        else:
            await show_object(update, context, row["object_id"])


async def cb_wizard(update: Update, context: ContextTypes.DEFAULT_TYPE, user, cmd: str, p: list, est: dict) -> None:
    """Кнопки мастера. p = [команда, ...параметры] (номер сметы уже снят)."""
    q = update.callback_query
    ud = context.user_data
    uid = user["user_id"]

    if cmd == "bk" and p[1] == "sep":
        await q.answer()
        await ask_sep(update, context)
    elif cmd == "sep":
        await q.answer()
        est["sep"] = p[1]
        await ask_stage(update, context)
    elif cmd == "stage":
        await q.answer()
        est["stage"] = p[1]
        est["rooms"] = make_rooms(est["sep"] or "one")
        est["ri"] = 0
        await advance(update, context)
    elif cmd == "w":
        await q.answer()
        if p[1] == "cancel":
            await send_menu(update, context,
                            intro="Смета не потеряна: её можно продолжить кнопкой «Продолжить смету».\n\n")
        elif p[1] == "back":
            await wizard_back(update, context)
        elif p[1] == "results":
            if est.get("type") == "extra" or (est.get("type") == "croom" and "result" not in est):
                await show_extra(update, context)
            elif est.get("type") == "croom":
                await show_croom_result(update, context)
            else:
                await show_result(update, context)
    elif cmd == "a":  # ответ кнопкой: a:<вопрос>:<значение>
        step = expected_step(est) if est.get("rooms") else None
        if not step or step.key != p[1]:
            await q.answer("Этот вопрос уже неактуален.")
            await resume_est(update, context)
            return
        await q.answer()
        value = ":".join(p[2:])
        room = est["rooms"][est["ri"]]
        if step.kind == "num":
            value = parse_number(value)
            if value is None:
                return
        elif step.kind == "yn":
            if value not in ("y", "n"):
                return
        elif step.kind == "choice":
            if value not in dict(flow.resolve(step.options, room["a"], ctx_of(est, room))):
                return
        await submit_answer(update, context, step, value)
    elif cmd == "dm":  # «Вы ввели N метров, это верно?»: dm:<смета>:yes | fix
        pend = est.pop("dim_pending", None)
        step = expected_step(est) if est.get("rooms") else None
        if not pend or not step or step.key != pend["key"]:
            await q.answer("Этот вопрос уже неактуален.")
            await resume_est(update, context)
            return
        await q.answer()
        if p[1] == "yes":
            await submit_answer(update, context, step, pend["value"])   # человек подтвердил: берём как введено
        else:
            await ask_step(update, context, step)                       # исправить: тот же вопрос ещё раз
    elif cmd in ("m", "md"):  # вопрос с несколькими вариантами
        step = expected_step(est) if est.get("rooms") else None
        if not step or step.key != p[1] or step.kind != "multi":
            await q.answer("Этот вопрос уже неактуален.")
            await resume_est(update, context)
            return
        await q.answer()
        if cmd == "m":
            sel = est["multi"]
            sel.remove(p[2]) if p[2] in sel else sel.append(p[2])
            await ask_step(update, context, step)
        else:
            room = est["rooms"][est["ri"]]
            order = [v for v, _ in flow.resolve(step.options, room["a"], ctx_of(est, room))]
            await submit_answer(update, context, step, [v for v in order if v in est["multi"]])
    elif cmd == "ed":
        await q.answer()
        if p[1] == "menu":
            est["editing"] = True
            await show_edit_menu(update, context)
        elif p[1] == "done":
            await finish_estimate(update, context)
        else:
            est["ri"] = int(p[1])
            est["edit_key"] = p[2]
            est["multi_key"] = None
            step = expected_step(est)
            if step:
                await ask_step(update, context, step)
    elif cmd == "save":
        await q.answer()
        if "result" not in est:
            await (croom_finish(update, context) if est["type"] == "croom" else finish_estimate(update, context))
        elif est.get("obj") and db.get_object(uid, est["obj"]):
            await save_current(update, context, est["obj"])
        else:
            await ask_where_to_save(update, context)
    elif cmd == "sv":
        await q.answer()
        if p[1] == "new":
            await show(update, context, "🏠 Напишите адрес или имя клиента для нового объекта:",
                       [[Btn("⬅️ Отмена", callback_data=f"w:{est['id']}:results")]], user=user,
                       await_input={"kind": "objname", "then": "save", "d": est["id"]})
        elif db.get_object(uid, int(p[1])):
            await save_current(update, context, int(p[1]))
    elif cmd == "pc":
        await q.answer()
        await pc_action(update, context, p)
    elif cmd == "adj":
        await q.answer()
        await adj_action(update, context, p)
    elif cmd == "dy":
        await q.answer()
        await dy_action(update, context, p)
    elif cmd == "aw":
        await q.answer()
        await aw_action(update, context, p)
    elif cmd == "xa":
        await q.answer()
        await x_action(update, context, p)
    else:
        await q.answer()


# =============================================================================
# Обработчик текста
# =============================================================================
async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    uid = update.effective_user.id
    text = (update.message.text or "").strip()
    ud = context.user_data
    user = db.get_user(uid)
    aw = ud.get("await")

    if not user:
        await start_onboarding(update, context)
        return
    low = text.lower().lstrip("/").strip()
    if is_owner(uid) and low in ("пожелания", "новые пожелания", "новые", "новые названия", "статистика", "настройки"):
        # команды владельца (кириллицей, без «/» тоже)
        if low == "пожелания":
            await show_wishes(update, context)
        elif low in ("новые пожелания", "новые"):
            await show_new_wishes(update, context)
        elif low == "статистика":
            await show_stats(update, context)
        elif low == "настройки":
            await owner_settings(update, context, text)
        else:
            await show_pending(update, context)
        return
    if is_owner(uid) and low.startswith("настройка "):
        await owner_settings(update, context, text)
        return
    if is_owner(uid) and not (aw and aw.get("kind") in ("nick", "wish", "bug", "city", "note", "secname")) \
            and await owner_extra_commands(update, context, text, low):
        return
    # Вход не пройден или срок кончился: дальше не пускаем (ник, пожелание, ошибка и город — часть самого входа)
    if user["ready"] and not (aw and aw.get("kind") in ("nick", "wish", "bug", "city")):
        if await entry_block(update, context, user):
            return
    if not aw:
        # Бот ждёт кнопку, а человек написал текст: остаёмся на том же экране и показываем его заново.
        if not user["ready"]:
            await show_settings(update, context)
        elif not await resend_last(update, context, "👆 Тут нужно выбрать вариант кнопкой."):
            await send_menu(update, context)
        return

    kind = aw["kind"]
    if kind == "city":
        db.update_user(uid, city=text[:60])
        await show_settings(update, context)
        return
    if not user["ready"]:
        await show_settings(update, context)
        return
    if kind == "nick":
        await save_nick(update, context, text, bool(aw.get("entry")))
        return
    if kind == "wish":
        if text:
            await save_wish(update, context, text)
        return
    if kind == "bug":
        if text:
            await save_bug(update, context, text, aw["ref"])
        return
    if kind == "secname":   # название нового раздела («Разделить» в «Мои цены»)
        if text:
            await save_section_name(update, context, text)
        return
    if kind == "xcalc":     # калькулятор: список работ текстом, по строке на работу
        items, bad = xcalc.parse_text(update.message.text or "")
        await xc_set(update, context, items, bad, "text")
        return
    if kind == "roomname":
        if text:
            await start_own_room(update, context, text)
        return
    if kind == "note":
        await save_note(update, context, user, aw["t"], text)
        return
    if kind == "pnsearch" and is_owner(uid):
        await show_merge_choices(update, context, aw["id"], text)
        return

    # Ответы, привязанные к смете: если это уже другая смета — не трогаем её, показываем актуальное
    est = None
    if "d" in aw:
        est = ud.get("est")
        if not est or est.get("id") != aw["d"]:
            ud["await"] = None
            if not await resend_last(update, context, "👆 Этот вопрос уже неактуален."):
                await send_menu(update, context)
            return

    if kind == "num":
        step = expected_step(est) if est.get("rooms") else None
        if not step or step.key != aw["key"]:
            ud["await"] = None
            if not await resend_last(update, context, "👆 Этот вопрос уже неактуален."):
                await send_menu(update, context)
            return
        value = parse_number(text)
        room = est["rooms"][est["ri"]]
        top = flow.step_max(step, room["a"], ctx_of(est, room))
        if value is None or value < 0 or (step.positive and value <= 0) or value > top + 1e-9:
            hint = "больше нуля" if step.positive else "не меньше нуля"
            await ask_step(update, context, step,
                           note=f"⚠️ Не понял число. Нужно число {hint} и не больше {fnum(top)}, "
                                "например 1,53.\n\n")
            return
        value = round(value, 2)
        if step.key in DIM_WORD:   # длина, ширина, высота: слишком большое не запрещаем, а переспрашиваем
            level = dim_level(step.key, value, bath_kind=room["kind"])
            if level:
                est["dim_pending"] = {"key": step.key, "value": value, "level": level}
                await show_dim_confirm(update, context)
                return
        await submit_answer(update, context, step, value)
    elif kind == "txt":
        step = expected_step(est) if est.get("rooms") else None
        if not step or step.key != aw["key"]:
            ud["await"] = None
            if not await resend_last(update, context, "👆 Этот вопрос уже неактуален."):
                await send_menu(update, context)
            return
        if not text:
            return
        await submit_answer(update, context, step, text[:60])
    elif kind == "mz":
        if est.get("type") != "croom":
            ud["await"] = None
            await resend_last(update, context, "👆 Этот вопрос уже неактуален.")
            return
        await mz_input(update, context, aw.get("field") or "len", text)
    elif kind == "op":    # «Объект без стен»: длины, площадь, высота, балки и колонны, проём
        if est.get("type") != "croom" or est.get("room") != "open":
            ud["await"] = None
            await resend_last(update, context, "👆 Этот вопрос уже неактуален.")
            return
        await open_input(update, context, aw.get("field") or "", text)
    elif kind == "adj":   # наценка или скидка, %
        await adj_input(update, context, aw.get("field") or "markup", text)
    elif kind == "days":   # дни работы для минимума по дням
        value = parse_number(text)
        if value is None or value < 0 or value > DAYS_MAX:
            await update.message.reply_text(f"⚠️ Нужно число дней от 0 до {DAYS_MAX}, например 2 или 1,5 (0 — без минимума).")
            return
        await dy_set(update, context, value)
    elif kind == "price":
        value = parse_number(text)
        if value is None or value < 0:
            await update.message.reply_text("⚠️ Нужно число не меньше нуля, например 1500.")
            return
        if custom_id(aw["key"]) is not None:  # своя работа: цена хранится отдельно, в общую базу не уходит
            db.set_custom_price(uid, custom_id(aw["key"]), value)
        else:
            db.set_price(uid, aw["key"], value)
        await reopen_price_view(update, context, aw["key"])
    elif kind == "dayrate":   # сумма минимума за день (настройки)
        value = parse_number(text)
        if value is None or value <= 0:
            await update.message.reply_text("⚠️ Нужно число больше нуля, например 3000.")
            return
        db.update_user(uid, day_rate=value, day_min_on=1)
        await show_settings(update, context, f"📅 Минимум по дням включён: {money(db.get_user(uid), value)} за день.")
    elif kind == "min":
        value = parse_number(text)
        if value is None or value < 0:
            await update.message.reply_text("⚠️ Нужно число не меньше нуля, например 5000.")
            return
        db.update_user(uid, min_total=value)
        await show_price_groups(update, context)
    elif kind == "objname":
        name = text[:80]
        if not name:
            return
        object_id = db.create_object(uid, name)
        if aw.get("then") == "save" and ud.get("est") and ud["est"].get("id") == aw.get("d"):
            await save_current(update, context, object_id)
        elif aw.get("then") == "save":
            await show_objects(update, context)
        else:
            await show_objects(update, context)
    elif kind == "objren":
        if text:
            db.rename_object(aw["id"], text[:80])
        await show_object(update, context, aw["id"])
    elif kind == "pc_price":
        value = parse_number(text)
        if value is None or value < 0:
            await update.message.reply_text("⚠️ Нужно число не меньше нуля, например 3500.")
            return
        await apply_new_price(update, context, aw["key"], value, keep=bool(aw.get("keep")))
    elif kind.startswith("aw_"):
        tmp = est["tmp"]
        if kind == "aw_title":
            tmp["title"] = text[:80]
            await aw_ask(update, context, "unit")
        elif kind == "aw_unit":
            tmp["unit"] = text[:12]
            await aw_ask(update, context, "price")
        else:
            value = parse_number(text)
            ok = value is not None and value >= 0 and (kind == "aw_price" or value > 0)
            if not ok:
                await aw_ask(update, context, kind[3:], "⚠️ Нужно число" + (" больше нуля" if kind == "aw_qty" else "")
                             + ", например 1500.\n\n")
            elif kind == "aw_price":
                tmp["price"] = value
                await aw_ask(update, context, "qty")
            else:
                await aw_finish(update, context, value)
    elif kind.startswith("x_"):
        tmp = est["tmp"]
        if kind == "x_search" and est["type"] == "croom" and est.get("room") != "small":  # слово в ответ: общий список фильтруется
            est["flt"] = {"q": text[:60], "pg": 0}
            est["tmp"] = {"query": text[:60]}
            await show_constructor(update, context)
        elif kind == "x_search":
            await x_search(update, context, text)
        elif kind in ("x_lqty", "x_lprice", "x_lmprice"):   # правка строки в итоге конструктора
            value = parse_number(text)
            i = aw.get("idx", -1)
            if not 0 <= i < len(est["lines"]):
                await show_line_list(update, context)
            elif value is None or value < 0 or (kind == "x_lqty" and value <= 0):
                await ask_line_value(update, context, i, kind[3:], "⚠️ Нужно число" + (" больше нуля" if kind == "x_lqty" else "")
                                     + ", например 1500.\n\n")
            elif kind == "x_lqty":
                est["lines"][i]["qty"], est["lines"][i]["auto"] = value, False
                est.pop("result", None)
                await croom_finish(update, context, "✅ Строка поправлена.")
            else:
                await set_line_price(update, context, i, value, kind[3:])
        elif kind in ("x_etitle", "x_eqty", "x_eprice") and est["type"] == "extra":   # «Изменить» строку допработы
            await save_xline_value(update, context, kind, aw.get("idx", -1), text)
        elif kind == "x_title":
            tmp["title"] = text[:80]
            if tmp.get("own") and tmp.get("kind") != "sum" and await x_similar(update, context, tmp["title"]):
                return
            await x_ask(update, context, "amount" if tmp.get("kind") == "sum" else "unit")
        elif kind == "x_unit":
            tmp["unit"] = text[:12]
            await x_ask(update, context, "price")
        elif kind == "x_name":
            await x_finish(update, context, text[:60])
        else:
            value = parse_number(text)
            ok = value is not None and value >= 0 and (kind != "x_qty" or value > 0)
            if not ok:
                await x_ask(update, context, kind[2:], "⚠️ Нужно число, например 1500.\n\n")
            elif kind == "x_price":
                tmp["price"] = value
                tmp.pop("pe", None)
                await x_ask(update, context, "qty")
            elif kind == "x_amount":
                tmp["price"], tmp["qty"] = value, 1
                await x_add_line(update, context, 1)
            else:
                await x_add_line(update, context, value)
    else:
        ud["await"] = None
        await resend_last(update, context, "👆 Тут нужно выбрать вариант кнопкой.")


async def on_other_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Фото, стикеры, файлы и т.п.: тоже не уходим в меню, а показываем текущий экран."""
    user = db.get_user(update.effective_user.id)
    if user and user["ready"] and await entry_block(update, context, user):
        return
    if user and user["ready"] and context.user_data.get("last"):
        await resend_last(update, context, "👆 Я понимаю только кнопки и текст.")
    elif user and user["ready"]:
        await send_menu(update, context)


async def cmd_menu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = db.get_user(update.effective_user.id)
    if user and user["ready"]:
        await entry_continue(update, context)
    else:
        await cmd_start(update, context)


async def on_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Любая неожиданная ошибка: пишем в консоль и вежливо сообщаем пользователю."""
    err = context.error
    if isinstance(err, BadRequest) and "too old" in str(err):
        # Нажали кнопку в старом сообщении, пока бот был выключен: ответить уже нельзя, это не поломка.
        return
    log.error("Ошибка в обработчике", exc_info=err)
    if isinstance(update, Update) and update.effective_chat:
        try:
            await update.effective_chat.send_message("😔 Что-то пошло не так. Нажмите /menu, чтобы продолжить: "
                                                     "ваши сметы сохранены.")
        except Exception:
            pass


# =============================================================================
# Запуск
# =============================================================================
def build_app(token: str, request=None) -> Application:
    """request нужен только для проверок без сети (подставной Telegram)."""
    builder = Application.builder().token(token)
    if request is not None:
        builder = builder.request(request)
    app = builder.post_init(notify_sections_report).build()
    app.add_handler(TypeHandler(Update, load_session), group=-1)   # до всех: поднять память из базы
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("menu", cmd_menu))
    app.add_handler(CommandHandler("id", cmd_id))
    app.add_handler(CommandHandler("wishes", cmd_wishes))
    app.add_handler(CommandHandler("newwishes", cmd_newwishes))
    app.add_handler(CommandHandler("newnames", cmd_newnames))
    app.add_handler(CommandHandler("stats", cmd_stats))
    app.add_handler(CallbackQueryHandler(on_callback))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
    app.add_handler(MessageHandler(filters.Document.ALL, on_document))
    app.add_handler(MessageHandler(~filters.TEXT & ~filters.COMMAND & ~filters.StatusUpdate.ALL, on_other_message))
    app.add_handler(TypeHandler(Update, persist), group=1)         # после всех: записать состояние
    app.add_error_handler(on_error)
    return app


def main() -> None:
    logging.basicConfig(format="%(asctime)s %(levelname)s %(name)s: %(message)s", level=logging.INFO)
    # httpx пишет в лог полный адрес запроса, а в нём — токен бота. Глушим.
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)

    token = load_token()
    if not token:
        print("Не найден токен бота. Скопируйте .env.example в .env и впишите токен "
              "после TELEGRAM_BOT_TOKEN=")
        sys.exit(1)
    db.init_db()
    owner = load_env("OWNER_ID")
    n = db.recalc_trial_dates({int(owner)} if owner.isdigit() else set())   # однократно: срок = вход + 30 дней
    if n:
        log.info("Срок бесплатного теста пересчитан как вход + %s дней у %s чел.", db.trial_days(), n)
    rep = db.migrate_sections(int(owner) if owner.isdigit() else None)   # однократно: копия базы, дубли, разделы
    if rep:
        log.info("Уборка в «Мои цены»: у владельца удалено дублей %s, без раздела %s; копия базы: %s",
                 rep["owner"]["removed"], rep["owner"]["left"], rep["backup"] or "—")
    log.info("Бот запущен. Остановить: Ctrl+C")
    build_app(token).run_polling()


if __name__ == "__main__":
    main()
