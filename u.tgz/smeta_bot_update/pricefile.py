"""Загрузка прайса файлом: шаблон Excel, чтение таблицы Excel и PDF.

Файл — три колонки с заголовками «Услуга», «Единица», «Цена» (колонки ищутся по заголовкам, порядок не важен).
Строка, где заполнено только название (единица и цена пустые), — начало раздела: все услуги ниже относятся к нему
до следующей такой строки. Если заголовки не совпали, бот ничего не угадывает и просит исправить файл.
Модуль не зависит от Телеграма, поэтому проверяется отдельно.
"""
import io
import re

import sections

HEAD_SERVICE, HEAD_UNIT, HEAD_PRICE = "Услуга", "Единица", "Цена"
MAX_ROWS = 3000                 # строк в файле
MAX_BYTES = 5_000_000           # размер файла, байт
MAX_PDF_PAGES = 60
TITLE_MAX = 80
NO_COLUMNS_TEXT = "Не нашёл колонки Услуга, Единица, Цена, измените заголовки и отправьте снова."

UNIT_ALIASES = {"м2": "м²", "м²": "м²", "кв.м": "м²", "кв. м": "м²", "квм": "м²", "шт": "шт", "шт.": "шт", "штука": "шт",
                "пм": "пог.м", "пог.м": "пог.м", "пог. м": "пог.м", "п.м": "пог.м", "м.п": "пог.м", "м": "пог.м",
                "помещ.": "помещ.", "помещение": "помещ.", "компл.": "компл.", "комплект": "компл.",
                "точка": "точка", "т.": "точка"}


def norm_unit(raw) -> str:
    unit = str(raw).strip().lower() if raw not in (None, "") else "шт"
    return UNIT_ALIASES.get(unit, unit[:12])


def parse_price(value):
    """Цена из ячейки: число или текст вроде «1 500,50 ₽». Не число — None (бот ничего не угадывает)."""
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if value is None:
        return None
    t = str(value).lower().replace("\xa0", "").replace(" ", "").replace(",", ".")
    t = re.sub(r"(₽|руб(лей|\.)?|р\.?)$", "", t)
    return float(t) if re.fullmatch(r"\d+(?:\.\d+)?", t) else None


def _cell(v) -> str:
    return re.sub(r"\s+", " ", "" if v is None else str(v)).strip()


def _head_key(v) -> str:
    return re.sub(r"[\s:.]+", "", _cell(v).lower().replace("ё", "е"))


def find_columns(rows: list):
    """(номер строки заголовков, колонка услуги, единицы, цены) или None. Заголовки ищем в первых 20 строках."""
    for n, row in enumerate(rows[:20]):
        keys = [_head_key(c) for c in row]
        if {"услуга", "единица", "цена"} <= set(keys):
            return n, keys.index("услуга"), keys.index("единица"), keys.index("цена")
    return None


def parse_rows(rows: list) -> dict:
    """Строки таблицы → {'items': [(услуга, единица, цена, раздел или None)], 'skipped': число, 'groups': [названия],
    'dups': повторы внутри файла, 'truncated': обрезано ли, 'error': None | 'no_columns' | 'empty'}."""
    out = {"items": [], "skipped": 0, "groups": [], "dups": 0, "truncated": False, "error": None}
    cols = find_columns(rows)
    if not cols:
        out["error"] = "no_columns"
        return out
    hdr, ci_t, ci_u, ci_p = cols
    body = rows[hdr + 1:]
    if len(body) > MAX_ROWS:
        body, out["truncated"] = body[:MAX_ROWS], True
    group = None
    found: dict = {}
    need = max(ci_t, ci_u, ci_p) + 1
    for row in body:
        row = list(row) + [None] * (need - len(row))
        title, unit_raw, price_raw = _cell(row[ci_t]), _cell(row[ci_u]), row[ci_p]
        price_empty = price_raw is None or _cell(price_raw) == ""
        if not title and not unit_raw and price_empty:
            continue
        if {_head_key(title), _head_key(unit_raw)} == {"услуга", "единица"}:
            continue   # заголовки повторились на новой странице PDF
        if title and not unit_raw and price_empty:   # только название — начало раздела
            name = sections.clean_name(title)
            if name and len(title) <= 60:
                group = name
                if name not in out["groups"]:
                    out["groups"].append(name)
            else:
                out["skipped"] += 1
            continue
        price = parse_price(price_raw)
        if not title or price is None or price <= 0:
            out["skipped"] += 1
            continue
        item = (title[:TITLE_MAX], norm_unit(unit_raw), price, group)
        key = (sections.norm(item[0]), item[1])
        if key in found:
            out["dups"] += 1   # та же услуга дважды в файле: берём последнюю цену, место и раздел остаются прежними
            idx = found[key]
            out["items"][idx] = (out["items"][idx][0], item[1], price, out["items"][idx][3])
            continue
        found[key] = len(out["items"])
        out["items"].append(item)
    if not out["items"]:
        out["error"] = "empty"
    return out


def parse_xlsx(data: bytes) -> dict:
    """Читает Excel. Лист «Прайс», если такой есть; иначе первый лист, где нашлись нужные заголовки."""
    from openpyxl import load_workbook

    wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    sheets = sorted(wb.worksheets, key=lambda s: s.title != "Прайс")
    result = None
    for ws in sheets:
        rows = []
        for n, row in enumerate(ws.iter_rows(values_only=True)):
            if n > MAX_ROWS + 25:
                break
            rows.append(list(row))
        result = parse_rows(rows)
        if result["error"] != "no_columns":
            return result
    return result or {"items": [], "skipped": 0, "groups": [], "dups": 0, "truncated": False, "error": "no_columns"}


def pdf_available() -> bool:
    """Установлена ли библиотека чтения PDF (pdfplumber). Нет — кнопка «PDF» в боте не показывается."""
    try:
        import pdfplumber  # noqa: F401
        return True
    except ImportError:
        return False


def parse_pdf(data: bytes) -> dict:
    """Читает PDF с таблицей из тех же трёх колонок. Сначала таблицы с линиями, потом — выровненные пробелами."""
    import pdfplumber

    rows: list = []
    with pdfplumber.open(io.BytesIO(data)) as pdf:
        for page in pdf.pages[:MAX_PDF_PAGES]:
            tables = page.extract_tables()
            if not tables:
                tables = page.extract_tables({"vertical_strategy": "text", "horizontal_strategy": "text"})
            for t in tables:
                rows.extend(t)
    return parse_rows(rows)


def build_template() -> bytes:
    """Шаблон Excel: три колонки и образец с двумя разделами (строка с одним названием — начало раздела)."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    from openpyxl.worksheet.datavalidation import DataValidation

    wb = Workbook()
    ws = wb.active
    ws.title = "Прайс"
    ws.append([HEAD_SERVICE, HEAD_UNIT, HEAD_PRICE])
    for cell in ws[1]:
        cell.font = Font(bold=True)
    sample = [("Стены", None, None),
              ("Штукатурка стен", "м²", 450), ("Шпаклёвка стен под покраску", "м²", 300), ("Покраска стен", "м²", 200),
              ("Пол", None, None),
              ("Стяжка пола", "м²", 600), ("Укладка ламината", "м²", 400), ("Плинтус напольный", "пог.м", 150)]
    fill = PatternFill("solid", fgColor="E8F0FE")
    for row in sample:
        ws.append(list(row))
        if row[1] is None:   # название раздела: выделено, единицы и цены нет
            for cell in ws[ws.max_row]:
                cell.font = Font(bold=True)
                cell.fill = fill
    ws.column_dimensions["A"].width = 46
    ws.column_dimensions["B"].width = 12
    ws.column_dimensions["C"].width = 12
    dv = DataValidation(type="list", formula1='"м²,шт,пог.м,помещ.,компл.,точка"', allow_blank=True)
    ws.add_data_validation(dv)
    dv.add("B2:B3000")
    hint = wb.create_sheet("Подсказка")
    for row in ("Заполните лист «Прайс»: одна услуга в строке. Заголовки «Услуга», «Единица», «Цена» не меняйте.",
                "Услуга — любой текст (например: Установка розетки).",
                "Единица — м², шт, пог.м и т.д. (можно выбрать из списка).",
                "Цена — число, в вашей валюте.",
                "Раздел: строка, где заполнено только название (единицу и цену оставьте пустыми), — начало раздела.",
                "Все услуги ниже относятся к этому разделу, пока не встретится следующая такая строка.",
                "Разделов в файле нет — бот сам разложит услуги по названию.",
                "Образец в листе «Прайс» (Стены, Пол) удалите и впишите свои услуги.",
                "Сохраните файл (.xlsx) и пришлите его боту в чат."):
        hint.append([row])
    hint.column_dimensions["A"].width = 95
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
