"""Выгрузка сметы в PDF (библиотека fpdf2).

Для русских букв нужен шрифт с кириллицей. Ищем по порядку:
fonts/DejaVuSans.ttf в папке проекта, затем системные Arial / DejaVu.
Если у вас Linux-сервер без шрифтов, положите DejaVuSans.ttf в папку fonts/.
"""
from datetime import date
from pathlib import Path

from fpdf import FPDF

import calc
from calc import fmoney, fnum

_HERE = Path(__file__).parent
_FONT_CANDIDATES = [
    (_HERE / "fonts" / "DejaVuSans.ttf", _HERE / "fonts" / "DejaVuSans-Bold.ttf"),
    (Path(r"C:\Windows\Fonts\arial.ttf"), Path(r"C:\Windows\Fonts\arialbd.ttf")),
    (Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
     Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")),
    (Path("/Library/Fonts/Arial Unicode.ttf"), Path("/Library/Fonts/Arial Unicode.ttf")),
]


def _find_fonts() -> tuple[Path, Path]:
    for regular, bold in _FONT_CANDIDATES:
        if regular.exists():
            return regular, (bold if bold.exists() else regular)
    raise RuntimeError("Не найден шрифт с кириллицей для PDF. Положите DejaVuSans.ttf в папку fonts/.")


def build_pdf(result: dict, currency: str, title: str, object_name: str,
              place: str, view="detailed") -> bytes:
    """Собирает PDF сметы и возвращает его байты.

    view="detailed" — подробная: услуга, метраж, цена за единицу, сумма по строке, итоги по разделам.
    view="short" — короткая: только услуги и общая сумма (без метража и расценок).
    Заметки к смете и объекту в PDF не попадают: сюда передаётся только результат расчёта."""
    with_prices = view in ("detailed", True, 1, "1")
    short = not with_prices
    regular, bold = _find_fonts()
    pdf = FPDF(format="A4")
    pdf.set_margins(15, 15, 15)
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_font("Sans", "", str(regular))
    pdf.add_font("Sans", "B", str(bold))
    pdf.add_page()
    money = lambda x: fmoney(x, currency, pdf=True)

    # Шапка
    pdf.set_font("Sans", "B", 16)
    pdf.cell(0, 9, "Смета на отделочные работы", new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Sans", "", 10)
    info = [title]
    if object_name:
        info.append(f"Объект: {object_name}")
    info.append(f"{place} · {date.today():%d.%m.%Y}")
    for line in info:
        pdf.cell(0, 5.5, line, new_x="LMARGIN", new_y="NEXT")
    pdf.ln(3)

    # Колонки таблицы: подробная — четыре, короткая — одна (только услуги)
    cols = [95, 30, 25, 30] if with_prices else [180]
    width = sum(cols)

    for room in result["rooms"]:
        g = room["geom"]
        pdf.set_font("Sans", "B", 13)
        pdf.cell(0, 8, room["name"], new_x="LMARGIN", new_y="NEXT")
        pdf.set_font("Sans", "", 9)
        if g and not short:  # у допработы по строкам помещения нет; в короткой смете метража нет
            for line in calc.geom_lines(g, html=False):
                pdf.cell(0, 5, line, new_x="LMARGIN", new_y="NEXT")
        pdf.ln(1)
        if not room["lines"]:
            pdf.cell(0, 6, "Работы не выбраны.", new_x="LMARGIN", new_y="NEXT")
        for sec_key, sec_title in calc.SECTIONS.items():
            lines = [l for l in room["lines"] if l["section"] == sec_key]
            if not lines:
                continue
            # заголовок раздела
            pdf.set_font("Sans", "B", 10)
            pdf.set_fill_color(235, 235, 235)
            pdf.cell(width, 6.5, sec_title, fill=True, new_x="LMARGIN", new_y="NEXT")
            pdf.set_font("Sans", "", 10)
            for l in lines:
                if with_prices:
                    qty = f"{fnum(l['qty'])} {l['unit']}"
                    pdf.cell(cols[0], 6, l["title"])
                    pdf.cell(cols[1], 6, qty, align="R")
                    pdf.cell(cols[2], 6, fnum(l["price"]), align="R")
                    pdf.cell(cols[3], 6, money(l["sum"]), align="R", new_x="LMARGIN", new_y="NEXT")
                else:
                    pdf.cell(cols[0], 6, "• " + l["title"], new_x="LMARGIN", new_y="NEXT")
            if with_prices:
                pdf.set_font("Sans", "B", 10)
                pdf.cell(sum(cols[:3]), 6, "Итого по разделу", align="R")
                pdf.cell(cols[3], 6, money(sum(l["sum"] for l in lines)), align="R", new_x="LMARGIN", new_y="NEXT")
                pdf.set_font("Sans", "", 10)
            pdf.ln(1.5)
        if with_prices and len(result["rooms"]) > 1:
            pdf.set_font("Sans", "B", 11)
            pdf.cell(sum(cols[:3]), 7, f"Итого: {room['name']}", align="R")
            pdf.cell(cols[3], 7, money(room["total"]), align="R", new_x="LMARGIN", new_y="NEXT")
        pdf.ln(3)

    # Итог (в короткой смете это единственная сумма)
    if with_prices and result.get("discount"):   # скидка отдельной строкой
        pdf.set_font("Sans", "", 10)
        pdf.cell(0, 6, f"Скидка {fnum(result['discount_pct'])}%: −{money(result['discount'])}",
                 align="R", new_x="LMARGIN", new_y="NEXT")
    if with_prices and result["raised"]:
        pdf.set_font("Sans", "", 10)
        pdf.cell(0, 6, f"Расчёт {fnum(result['calc_total'])}, {calc.min_label(result)} {fnum(result['min_total'])}",
                 align="R", new_x="LMARGIN", new_y="NEXT")
    if result.get("missing"):   # итог неполный: предупреждаем прямо над суммой
        pdf.set_font("Sans", "", 10)
        pdf.cell(0, 6, calc.missing_warning(result["missing"]).replace("⚠️ ", ""), align="R",
                 new_x="LMARGIN", new_y="NEXT")
    pdf.set_font("Sans", "B", 14)
    if with_prices:
        pdf.cell(sum(cols[:3]), 9, "ИТОГО", align="R")
        pdf.cell(cols[3], 9, money(result["total"]), align="R", new_x="LMARGIN", new_y="NEXT")
    else:
        pdf.cell(width, 9, f"ИТОГО: {money(result['total'])}", align="R", new_x="LMARGIN", new_y="NEXT")
    if result.get("missing"):
        pdf.set_font("Sans", "", 9)
        pdf.multi_cell(0, 5, calc.missing_text(result["missing"], html=False).replace("⚠️ ", ""),
                       new_x="LMARGIN", new_y="NEXT")
    return bytes(pdf.output())
