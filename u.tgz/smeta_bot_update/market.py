"""Рыночные цены по Челябинску: подсказки «по рынку» в разделе «Прайсы» и работы из прайсов фирм.

Данные лежат в market_data.json (его собирает tools/build_market.py из Excel-файлов с прайсами фирм).
Эти цены только подсказка: в смету и в «Мои цены» сами они не попадают. Нет файла — подсказок просто нет.
"""
import json
import re
from pathlib import Path

_PATH = Path(__file__).with_name("market_data.json")

# Работы из прайсов фирм спрятаны из бота: в названиях остались метраж и суммы чужих смет. Пока их не разобрали
# (файл прайсы_разбор_для_проверки.xlsx), True вернёт их в раздел «Прайсы». Подсказки «по рынку» у работ каталога
# от этого не зависят.
SHOW_FIRM_ITEMS = False
_data = None
_index = None

# Раздел итога для работы из прайсов фирм (по теме)
SECTION_OF_THEME = {
    "Демонтаж": "prep", "Черновые работы": "prep", "Электрика": "elec", "Чистовые работы": "finish",
    "Плитка": "tile", "Потолки": "ceil", "Сантехника и монтаж": "mount", "Двери и окна": "doors", "Другое": "custom",
}


def data() -> dict:
    global _data, _index
    if _data is None:
        try:
            _data = json.loads(_PATH.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            _data = {"items": [], "catalog": {}}
        _index = {i["id"]: i for i in _data["items"]}
        _index.update({("t", i["title"].lower().strip(), i["unit"]): i for i in _data["items"]})
    return _data


def items() -> list:
    """Работы из прайсов фирм, которых нет в каталоге бота: [{'id', 'title', 'unit', 'theme', 'stats'}].

    Пока SHOW_FIRM_ITEMS выключен, в списках бота их нет (в market_data.json они остаются, item() их находит,
    так что уже сохранённые строки смет не ломаются)."""
    return data()["items"] if SHOW_FIRM_ITEMS else []


def item(item_id: str):
    data()
    return _index.get(item_id)


def stats(key: str, title: str = "", unit: str = ""):
    """Рыночная статистика работы: по ключу каталога, ключу работы из прайсов фирм или по названию и единице
    (так находится работа, которую человек уже сохранил в «Мои работы»). Нет данных — None."""
    d = data()
    if key in d["catalog"]:
        return d["catalog"][key]
    it = _index.get(key) or _index.get(("t", title.lower().strip(), unit))
    return it["stats"] if it else None


def _n(x) -> str:
    return f"{round(x):,}".replace(",", " ")


def hint(s: dict) -> str:
    """Полная подсказка: «по рынку от 300 до 500 ₽, ср. 400 ₽ · фирм: 3 · цены «от»»."""
    if s["min"] == s["max"]:
        core = f"от {_n(s['min'])} ₽" if s["from"] == "all" else f"{_n(s['min'])} ₽"
    else:
        core = f"от {_n(s['min'])} до {_n(s['max'])} ₽"
        if s["firms"] >= 2:
            core += f", ср. {_n(s['avg'])} ₽"
    tail = {"all": " · цены «от»", "some": " · часть цен «от»", "none": ""}[s["from"]]
    return f"по рынку {core} · фирм: {s['firms']}{tail}"


def short(s: dict) -> str:
    """Коротко, для кнопки: «рынок 300–500» (если все цены «от» — «рынок от 300–500»)."""
    rng = _n(s["min"]) if s["min"] == s["max"] else f"{_n(s['min'])}–{_n(s['max'])}"
    return f"рынок {'от ' if s['from'] == 'all' else ''}{rng}"


def basis_for(title: str, unit: str):
    """Как считать количество работы из прайсов фирм по замеру комнаты (None — вводится вручную)."""
    t = title.lower().replace("ё", "е")
    if unit == "м²":
        if re.search(r"потолк", t):
            return "ceil"
        if re.search(r"стен|обо[иея]|откос|штукатур|шпатл|шпакл", t) and not re.search(r"пол|потолк", t):
            return "walls"
        if re.search(r"пол|стяжк|ламинат|линолеум|паркет|наливн", t):
            return "floor"
        return None
    if unit == "пог.м" and re.search(r"плинтус", t):
        return "perim"
    return None
