"""Работа с SQLite (файл bot.db): профили, цены, объекты, сметы.

Каждая функция сама открывает и закрывает соединение — для бота такого
масштаба этого достаточно и не нужно думать о потоках.
"""
import json
import random
import re
import sqlite3
from datetime import datetime, timedelta, timezone
from pathlib import Path

import catalog
import sections

DB_PATH = Path(__file__).with_name("bot.db")

# «Красивые» ники: автоматически не выдаются, сами люди их тоже занять не могут. Владелец дарит их активным
# пользователям командой «подарить ник» (см. gift_nick).
RESERVED_NICKS = ["Мастер", "Прораб", "Смета", "Бригадир", "Отделочник", "Мастер отделки", "Мастер Смета",
                  "Главный прораб", "Штукатур", "Плиточник", "Маляр", "Электрик", "Сантехник", "Золотые руки",
                  "Мастер на все руки"]

# Настройки по умолчанию (лежат в таблице settings, их можно менять без правки кода)
DEFAULT_SETTINGS = {
    "free_limit": catalog.FREE_LIMIT,   # сколько человек входят бесплатно (считая приглашённых друзей)
    "trial_days": 30,                   # сколько дней длится бесплатный тест со дня входа
    "invite_bonus_days": 10,            # подарок пригласившему за каждого друга, посчитавшего смету
    "channel_username": "",             # общий канал: @имя (пусто — шаг подписки пропускается)
    "channel_link": "",                 # ссылка на канал для кнопки (пусто — соберём из имени)
    "bot_name": "Master_prorab_smeta_bot",  # название бота в тексте политики конфиденциальности
    # Проверка размеров комнаты: бот ничего не запрещает, а переспрашивает «Вы ввели N метров, это верно?»
    "dim_ask_bath": 3,                  # ванная и туалет: переспрос от этого размера (м) по длине или ширине
    "dim_strict_bath": 6,               # ванная и туалет: от этого размера (м) сообщение строже («очень большая»)
    "dim_ask_room": 8,                  # остальные комнаты: переспрос от этого размера (м) по длине или ширине
    "dim_ask_height": 4,                # высота потолка (м): переспрос от этого размера, для всех комнат
    "dim_ask_own": 200,                 # «своё помещение» (ангар, склад): длина и ширина, переспрос от (м)
    "dim_ask_own_height": 20,           # «своё помещение»: высота, переспрос от (м)
}
DATE_FMT = "%Y-%m-%d %H:%M:%S"


def now() -> datetime:
    """Текущее время по UTC (в проверках подменяется, чтобы «перемотать» срок)."""
    return datetime.now(timezone.utc).replace(tzinfo=None, microsecond=0)


def _conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def _run(sql: str, params: tuple = (), *, one: bool = False, many: bool = False):
    """Выполняет запрос. one — вернуть одну строку, many — список строк.
    Без этих флагов возвращает lastrowid (для INSERT)."""
    with _conn() as conn:  # with — сам делает commit
        cur = conn.execute(sql, params)
        if one:
            return cur.fetchone()
        if many:
            return cur.fetchall()
        return cur.lastrowid


def init_db() -> None:
    """Создаёт таблицы, если их ещё нет."""
    with _conn() as conn:
        conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
                user_id    INTEGER PRIMARY KEY,
                country    TEXT,
                city       TEXT DEFAULT '',
                lang       TEXT DEFAULT 'ru',
                currency   TEXT DEFAULT 'rub',
                min_total  REAL,
                ready      INTEGER DEFAULT 0,   -- 1 после первичной настройки
                invited_by INTEGER,
                created    TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS prices (
                user_id INTEGER,
                key     TEXT,
                value   REAL,
                PRIMARY KEY (user_id, key)
            );
            CREATE TABLE IF NOT EXISTS objects (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                name    TEXT,
                created TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS estimates (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                object_id  INTEGER,
                user_id    INTEGER,
                room       TEXT,
                title      TEXT,
                has_tile   INTEGER DEFAULT 0,   -- есть ли плиточные работы (для «Плиточника»)
                params     TEXT,                -- ответы пользователя (JSON), чтобы править смету
                result     TEXT,                -- готовый расчёт (JSON), как был на момент сохранения
                total      REAL,
                created    TEXT DEFAULT CURRENT_TIMESTAMP
            );
            -- Общая анонимная база цен: БЕЗ user_id и любых личных данных
            CREATE TABLE IF NOT EXISTS shared_prices (
                country  TEXT,
                city     TEXT,
                key      TEXT,
                value    REAL,
                currency TEXT,
                created  TEXT DEFAULT CURRENT_TIMESTAMP
            );
            -- Справочные цены по городам (ориентиры). В расчёт не идут, пока это только данные
            CREATE TABLE IF NOT EXISTS reference_prices (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                country   TEXT,
                city      TEXT,
                title     TEXT,
                unit      TEXT,
                price_min REAL,
                price_max REAL,
                currency  TEXT DEFAULT 'rub',
                UNIQUE (city, title)
            );
            -- Свои работы пользователя (которых нет в готовом прайсе): попадают в «Мои цены» и в поиск
            CREATE TABLE IF NOT EXISTS custom_items (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                title   TEXT,
                unit    TEXT,
                price   REAL
            );
            -- Открытые (незаконченные) сметы: человек может уйти и вернуться на тот же шаг
            CREATE TABLE IF NOT EXISTS drafts (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id   INTEGER,
                dtype     TEXT,                 -- room (расчёт комнаты) | extra (допработа по строкам)
                title     TEXT DEFAULT '',
                step      TEXT DEFAULT '',      -- на каком шаге остановились (для меню)
                object_id INTEGER,
                state     TEXT DEFAULT '{}',    -- всё состояние сметы (JSON)
                updated   TEXT
            );
            -- Что сейчас делает человек: активная смета, ждём ли текст, последний экран
            CREATE TABLE IF NOT EXISTS sessions (
                user_id INTEGER PRIMARY KEY,
                data    TEXT
            );
            -- Пожелания и замечания: что написали люди (дата, номер пользователя, текст)
            CREATE TABLE IF NOT EXISTS feedback (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                text    TEXT,
                created TEXT DEFAULT CURRENT_TIMESTAMP
            );
            -- Те, кому не хватило бесплатных мест: сообщим, когда бот откроется
            CREATE TABLE IF NOT EXISTS waitlist (
                user_id INTEGER PRIMARY KEY,
                created TEXT DEFAULT CURRENT_TIMESTAMP
            );
            -- Общий анонимный прайс из загруженных смет (калькулятор). Тут НЕТ user_id, метража, сумм, адресов и клиентов:
            -- только название услуги, единица и цена (плюс страна, город и валюта, чтобы не смешивать рубли с тенге).
            CREATE TABLE IF NOT EXISTS pool_names (      -- названия вне каталога, одобренные владельцем
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                title   TEXT,
                created TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS pool_prices (     -- цены, привязанные к названию каталога или одобренному названию
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                title    TEXT,
                unit     TEXT,
                price    REAL,
                country  TEXT,
                city     TEXT,
                currency TEXT,
                created  TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS pool_pending (    -- названия, которых нет в каталоге: ждут проверки владельцем
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                title    TEXT,
                norm     TEXT,
                unit     TEXT,
                price    REAL,
                country  TEXT,
                city     TEXT,
                currency TEXT,
                created  TEXT DEFAULT CURRENT_TIMESTAMP
            );
            -- Тихий счётчик для владельца: что начинают, сохраняют и какие работы выбирают (без имён и номеров людей)
            CREATE TABLE IF NOT EXISTS stat_events (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                kind    TEXT,
                key     TEXT DEFAULT '',
                created TEXT DEFAULT CURRENT_TIMESTAMP
            );
            -- Настройки бота (лимит бесплатных мест, срок, бонус, канал): число или текст по имени
            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT
            );
            -- Кнопки под сметой «Верно» / «Есть ошибка»: один голос человека на одну смету. Видно только владельцу
            CREATE TABLE IF NOT EXISTS est_votes (
                user_id INTEGER,
                ref     TEXT,
                vote    TEXT,
                created TEXT DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (user_id, ref)
            );
            -- Разделы своих работ мастера («Мои цены»): у каждого мастера свои; работа без раздела = «Без раздела»
            CREATE TABLE IF NOT EXISTS custom_sections (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                name    TEXT,
                UNIQUE (user_id, name)
            );
            -- «Красивые» ники, которые не выдаются случайно (дарит владелец)
            CREATE TABLE IF NOT EXISTS reserved_nicks (
                nick_norm TEXT PRIMARY KEY,
                nick      TEXT,
                gifted_to INTEGER,
                gifted_at TEXT
            );
            -- Геометрия объекта (этап 1.5): паспорт объекта — комнаты, точки, стены, проёмы.
            -- Спецификация: «дерево проекта/Спецификация_Геометрия_объекта.md». Старые сметы не трогаем:
            -- эти таблицы наполняются только новыми замерами.
            CREATE TABLE IF NOT EXISTS rooms (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                object_id   INTEGER NOT NULL,           -- objects.id
                name        TEXT NOT NULL,
                kind        TEXT,                       -- bath_full|bath_only|wc|room|own|open
                hei         REAL,                       -- высота потолка, м
                input_mode  TEXT,                       -- rect | lengths | arrows
                closed      INTEGER DEFAULT 0,          -- контур замкнут и проверен
                closing_gap REAL DEFAULT 0,             -- расхождение при замыкании до исправления, м
                created     TEXT DEFAULT CURRENT_TIMESTAMP
            );
            CREATE TABLE IF NOT EXISTS points (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                room_id INTEGER NOT NULL,               -- rooms.id
                ord     INTEGER NOT NULL,               -- порядок в контуре (0 = старт у входа)
                x       REAL,                           -- локальные координаты, м (режим «стрелки»)
                y       REAL,
                UNIQUE (room_id, ord)
            );
            CREATE TABLE IF NOT EXISTS walls (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                room_id     INTEGER NOT NULL,           -- rooms.id
                p_from      INTEGER NOT NULL,           -- points.id начала
                p_to        INTEGER NOT NULL,           -- points.id конца
                length      REAL NOT NULL,              -- как ввёл человек, м
                length_adj  REAL,                       -- после усреднения/подтяжки; NULL — равна length
                direction   INTEGER,                    -- 0..7 в режиме «стрелки», NULL в «длинах»
                kind        TEXT DEFAULT 'bearing',     -- bearing | partition
                shared_with INTEGER                     -- rooms.id соседней комнаты (после MVP)
            );
            CREATE TABLE IF NOT EXISTS openings (
                id      INTEGER PRIMARY KEY AUTOINCREMENT,
                wall_id INTEGER,                        -- walls.id; NULL — не привязан (перенос старых данных)
                room_id INTEGER NOT NULL,               -- rooms.id
                name    TEXT NOT NULL,                  -- дверь | окно | арка | своё (≤30 зн.)
                w       REAL NOT NULL,
                h       REAL NOT NULL,
                offset  REAL DEFAULT 0,                 -- отступ от угла p_from, м
                open    INTEGER DEFAULT 0,              -- 1 — открытый проход (без плинтуса)
                sill_h  REAL                            -- отметка низа окна (резерв)
            );
            CREATE TABLE IF NOT EXISTS duct_boxes (     -- Г-образные короба (раздел 10.6.1)
                id       INTEGER PRIMARY KEY AUTOINCREMENT,
                room_id  INTEGER NOT NULL,              -- rooms.id
                point_id INTEGER NOT NULL,              -- points.id угла установки
                orient   INTEGER NOT NULL,              -- 1..4 (┌ ┐ └ ┘)
                side_a   REAL NOT NULL,                 -- полка вдоль первой стены, м
                side_b   REAL NOT NULL,                 -- полка вдоль второй стены, м
                depth    REAL NOT NULL                  -- вылет от стены, м
            );
            """
        )
        _add_column(conn, "custom_items", "section_id", "INTEGER DEFAULT 0")   # 0 — без раздела
        _add_column(conn, "users", "joined", "TEXT")                    # дата входа (занял бесплатное место), UTC
        _add_column(conn, "users", "expires", "TEXT")                   # дата окончания бесплатного срока, UTC
        _add_column(conn, "users", "nick", "TEXT")                      # ник (настоящее имя не хранится и не показывается)
        _add_column(conn, "users", "nick_norm", "TEXT")                 # ник в нижнем регистре, для проверки уникальности
        _add_column(conn, "users", "policy_ok", "TEXT")                 # когда нажал «Согласен»
        _add_column(conn, "users", "sub_ok", "INTEGER DEFAULT 0")       # подписка на канал проверена
        _add_column(conn, "users", "welcomed", "INTEGER DEFAULT 0")     # показали текст про тестовый режим
        _add_column(conn, "users", "ref_code", "TEXT")                  # личный код для ссылки-приглашения
        _add_column(conn, "users", "first_calc", "TEXT")                # когда впервые посчитал смету
        _add_column(conn, "users", "bonus_paid", "INTEGER DEFAULT 0")   # бонус за этого друга пригласившему уже начислен
        _add_column(conn, "feedback", "kind", "TEXT DEFAULT 'wish'")    # wish — пожелание, bug — «Есть ошибка»
        _add_column(conn, "users", "day_rate", "REAL DEFAULT 0")        # минимум заказа за один день работы (кусок 3)
        _add_column(conn, "users", "day_min_on", "INTEGER DEFAULT 0")   # переключатель «Минимум по дням»
        _add_column(conn, "feedback", "est_ref", "TEXT DEFAULT ''")     # смета, к которой ошибка (d — черновик, e — сохранённая)
        _add_column(conn, "feedback", "seen", "INTEGER DEFAULT 0")      # владелец уже видел в списке «новые»
        # Добавляем новые колонки в старые таблицы (данные при этом не теряются)
        _add_column(conn, "objects", "status", "TEXT DEFAULT 'open'")   # open | done
        _add_column(conn, "objects", "note", "TEXT DEFAULT ''")         # заметка к объекту
        _add_column(conn, "estimates", "kind", "TEXT DEFAULT 'main'")   # main | extra (допработа)
        _add_column(conn, "estimates", "status", "TEXT DEFAULT 'open'") # open | work | done (архив)
        _add_column(conn, "estimates", "parent_id", "INTEGER")          # допработа к смете «В работе»
        _add_column(conn, "estimates", "note", "TEXT DEFAULT ''")       # заметка к смете (в PDF не попадает)
        conn.executemany(
            "INSERT OR IGNORE INTO reference_prices (country, city, title, unit, price_min, price_max) "
            "VALUES (?,?,?,?,?,?)", catalog.REFERENCE_PRICES)
    for key, value in DEFAULT_SETTINGS.items():   # недостающие настройки появляются со значением по умолчанию
        _run("INSERT OR IGNORE INTO settings (key, value) VALUES (?,?)", (key, str(value)))
    migrate_defaults()
    migrate_entry_dates()
    seed_reserved_nicks()


def migrate_entry_dates() -> None:
    """Однократно: у тех, кто уже пользовался ботом до появления сроков, дата входа = дата создания профиля,
    дата окончания = вход + срок теста. Метка в настройках не даёт сделать это второй раз (иначе человек,
    который в этот момент проходит вход, получил бы место без согласия и ника)."""
    if _run("SELECT 1 FROM settings WHERE key='migrated_entry_dates'", one=True):
        return
    _run("UPDATE users SET joined=created, expires=datetime(created, ?) WHERE joined IS NULL AND ready=1",
         (f"+{trial_days()} days",))
    _run("INSERT INTO settings (key, value) VALUES ('migrated_entry_dates', '1')")


def recalc_trial_dates(skip_ids=()) -> int:
    """Однократно (метка в настройках): у всех, кто уже вошёл, срок = дата входа + trial_days дней
    (30 по умолчанию), плюс подарочные дни за уже начисленных друзей (invite_bonus_days за каждого).
    skip_ids — те, кого не трогаем (владелец: у него срока нет). Возвращает, у скольких людей срок изменился."""
    if _run("SELECT 1 FROM settings WHERE key='recalc_trial_30'", one=True):
        return 0
    changed = 0
    bonus = bonus_days()
    for u in _run("SELECT user_id, joined, expires FROM users WHERE joined IS NOT NULL", many=True):
        if u["user_id"] in skip_ids:
            continue
        friends = _run("SELECT COUNT(*) AS n FROM users WHERE invited_by=? AND bonus_paid=1",
                       (u["user_id"],), one=True)["n"]
        new = (datetime.strptime(u["joined"], DATE_FMT)
               + timedelta(days=trial_days() + bonus * friends)).strftime(DATE_FMT)
        if new != u["expires"]:
            _run("UPDATE users SET expires=? WHERE user_id=?", (new, u["user_id"]))
            changed += 1
    _run("INSERT INTO settings (key, value) VALUES ('recalc_trial_30', '1')")
    return changed


def migrate_defaults() -> None:
    """Однократно приводит старые прайсы к новым значениям по умолчанию.

    Точка воды раньше создавалась с ценой 0, теперь по умолчанию 1500. Меняем только те строки, которые
    человек сам не правил (если правил, в общей базе есть запись об этом, и мы цену не трогаем)."""
    for u in _run("SELECT user_id, country, city, currency FROM users", many=True):
        touched = _run("SELECT 1 FROM shared_prices WHERE key='water_point' AND country=? AND city=? LIMIT 1",
                       (u["country"], u["city"]), one=True)
        if not touched:
            _run("UPDATE prices SET value=? WHERE user_id=? AND key='water_point' AND value=0",
                 (catalog.sample_price("water_point", u["currency"]), u["user_id"]))
        # Счётчик и фильтры воды раньше создавались без цены; теперь есть цены мастера. Трогаем только нули.
        for key in catalog.UPGRADED_DEFAULTS:
            _run("UPDATE prices SET value=? WHERE user_id=? AND key=? AND value=0",
                 (catalog.sample_price(key, u["currency"]), u["user_id"], key))
        # Заменённые стартовые цены (убрали заглушки, поставили расценки мастера): только там, где стоит прежний образец
        factor = catalog.CURRENCIES[u["currency"]]["factor"]
        for key, (old, new) in catalog.PRICE_MIGRATIONS.items():
            _run("UPDATE prices SET value=? WHERE user_id=? AND key=? AND value=?",
                 (catalog.scale_value(new, factor), u["user_id"], key, catalog.scale_value(old, factor)))


def _add_column(conn: sqlite3.Connection, table: str, column: str, decl: str) -> None:
    cols = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})")}
    if column not in cols:
        conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")


# --- Открытые сметы и сессия ---------------------------------------------------
_NOW = "strftime('%Y-%m-%d %H:%M:%f','now')"


def create_draft(user_id: int, dtype: str, object_id: int | None = None) -> int:
    return _run(f"INSERT INTO drafts (user_id, dtype, object_id, updated) VALUES (?,?,?,{_NOW})",
                (user_id, dtype, object_id))


def save_draft(user_id: int, draft_id: int, title: str, step: str, object_id: int | None, state: str) -> None:
    _run(f"UPDATE drafts SET title=?, step=?, object_id=?, state=?, updated={_NOW} WHERE id=? AND user_id=?",
         (title, step, object_id, state, draft_id, user_id))


def get_draft(user_id: int, draft_id: int):
    return _run("SELECT * FROM drafts WHERE id=? AND user_id=?", (draft_id, user_id), one=True)


def list_drafts(user_id: int):
    return _run("SELECT * FROM drafts WHERE user_id=? ORDER BY updated DESC, id DESC", (user_id,), many=True)


def delete_draft(user_id: int, draft_id: int) -> None:
    _run("DELETE FROM drafts WHERE id=? AND user_id=?", (draft_id, user_id))


def get_session(user_id: int) -> dict | None:
    row = _run("SELECT data FROM sessions WHERE user_id=?", (user_id,), one=True)
    return json.loads(row["data"]) if row else None


def save_session(user_id: int, data: dict) -> None:
    _run("INSERT INTO sessions (user_id, data) VALUES (?,?) "
         "ON CONFLICT(user_id) DO UPDATE SET data=excluded.data",
         (user_id, json.dumps(data, ensure_ascii=False)))


# --- Профиль -----------------------------------------------------------------
def get_user(user_id: int):
    return _run("SELECT * FROM users WHERE user_id=?", (user_id,), one=True)


def create_user(user_id: int, country: str, invited_by: int | None = None) -> None:
    c = catalog.COUNTRIES[country]
    _run(
        "INSERT OR IGNORE INTO users (user_id, country, lang, currency, invited_by) VALUES (?,?,?,?,?)",
        (user_id, country, c["langs"][0], c["currency"], invited_by),
    )


def update_user(user_id: int, **fields) -> None:
    """Обновляет поля профиля: update_user(5, city='Челябинск')."""
    allowed = {"country", "city", "lang", "currency", "min_total", "ready", "day_rate", "day_min_on"}
    cols = [k for k in fields if k in allowed]
    if not cols:
        return
    sql = "UPDATE users SET " + ", ".join(f"{k}=?" for k in cols) + " WHERE user_id=?"
    _run(sql, tuple(fields[k] for k in cols) + (user_id,))


def update_user_fields(user_id: int, **fields) -> None:
    """Служебные поля входа (ник, согласие, подписка…): отдельно от update_user, чтобы не открывать лишнее."""
    allowed = {"nick", "nick_norm", "policy_ok", "sub_ok", "welcomed", "ref_code", "joined", "expires"}
    cols = [k for k in fields if k in allowed]
    if cols:
        _run("UPDATE users SET " + ", ".join(f"{k}=?" for k in cols) + " WHERE user_id=?",
             tuple(fields[k] for k in cols) + (user_id,))


# --- Настройки и бесплатные места ----------------------------------------------------
def get_setting(key: str) -> str:
    row = _run("SELECT value FROM settings WHERE key=?", (key,), one=True)
    if row is not None and row["value"] is not None:
        return row["value"]
    return str(DEFAULT_SETTINGS.get(key, ""))


def set_setting(key: str, value) -> None:
    _run("INSERT INTO settings (key, value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
         (key, str(value)))


def _int_setting(key: str) -> int:
    try:
        return max(0, int(str(get_setting(key)).strip()))
    except ValueError:
        return int(DEFAULT_SETTINGS[key])


def float_setting(key: str) -> float:
    """Настройка-число (можно с запятой или точкой), больше нуля; при ошибке — значение по умолчанию."""
    try:
        value = float(str(get_setting(key)).strip().replace(",", "."))
        if value > 0:
            return value
    except ValueError:
        pass
    return float(DEFAULT_SETTINGS[key])


def free_limit() -> int:
    return _int_setting("free_limit")


def trial_days() -> int:
    return _int_setting("trial_days")


def bonus_days() -> int:
    return _int_setting("invite_bonus_days")


def joined_count() -> int:
    """Сколько людей уже заняли бесплатные места (прошли вход до конца)."""
    return _run("SELECT COUNT(*) AS n FROM users WHERE joined IS NOT NULL", one=True)["n"]


def seat_open() -> bool:
    return joined_count() < free_limit()


def take_seat(user_id: int, force: bool = False) -> bool:
    """Занимает бесплатное место: ставит дату входа и дату окончания (вход + срок теста).
    Если человек уже входил — True без изменений. Если мест нет (и не force) — False.
    Проверка и запись идут одной транзакцией, чтобы два человека не заняли последнее место вместе."""
    conn = sqlite3.connect(DB_PATH, isolation_level=None)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("BEGIN IMMEDIATE")
        row = conn.execute("SELECT joined FROM users WHERE user_id=?", (user_id,)).fetchone()
        if row is None:
            conn.execute("ROLLBACK")
            return False
        if row["joined"] is not None:
            conn.execute("ROLLBACK")
            return True
        taken = conn.execute("SELECT COUNT(*) AS n FROM users WHERE joined IS NOT NULL").fetchone()["n"]
        if not force and taken >= free_limit():
            conn.execute("ROLLBACK")
            return False
        start = now()
        conn.execute("UPDATE users SET joined=?, expires=? WHERE user_id=?",
                     (start.strftime(DATE_FMT), (start + timedelta(days=trial_days())).strftime(DATE_FMT), user_id))
        conn.execute("COMMIT")
        return True
    finally:
        conn.close()


def is_expired(user) -> bool:
    """Бесплатный срок человека кончился (дата окончания в прошлом)."""
    return bool(user["expires"]) and user["expires"] < now().strftime(DATE_FMT)


def add_waitlist(user_id: int) -> None:
    _run("INSERT OR IGNORE INTO waitlist (user_id) VALUES (?)", (user_id,))


# --- Ник -------------------------------------------------------------------------------
def nick_norm(nick: str) -> str:
    return re.sub(r"\s+", " ", nick.strip().lower().replace("ё", "е"))


def nick_taken(nick: str, except_user: int = 0) -> bool:
    return bool(_run("SELECT 1 FROM users WHERE nick_norm=? AND user_id<>?", (nick_norm(nick), except_user), one=True))


def set_nick(user_id: int, nick: str) -> bool:
    """Записывает ник, если он свободен. False — занят."""
    nick = re.sub(r"\s+", " ", nick.strip())
    if nick_taken(nick, user_id):
        return False
    update_user_fields(user_id, nick=nick, nick_norm=nick_norm(nick))
    return True


def user_label(user_id: int) -> str:
    """Для владельца: ник и номер в скобках, например «Мастер универсал (123456)». Нет ника — «без ника (123456)»."""
    row = _run("SELECT nick FROM users WHERE user_id=?", (user_id,), one=True)
    nick = (row["nick"] if row and row["nick"] else "") or "без ника"
    return f"{nick} ({user_id})"


# --- «Красивые» ники ----------------------------------------------------------------------
def seed_reserved_nicks() -> None:
    """Кладёт стандартные «красивые» ники в резерв. Если такой ник уже у кого-то есть — он считается подаренным ему."""
    for nick in RESERVED_NICKS:
        _run("INSERT OR IGNORE INTO reserved_nicks (nick_norm, nick) VALUES (?,?)", (nick_norm(nick), nick))
    for r in _run("SELECT n.nick_norm, u.user_id FROM reserved_nicks n JOIN users u ON u.nick_norm=n.nick_norm "
                  "WHERE n.gifted_to IS NULL", many=True):
        _run("UPDATE reserved_nicks SET gifted_to=?, gifted_at=? WHERE nick_norm=?",
             (r["user_id"], now().strftime(DATE_FMT), r["nick_norm"]))


def is_reserved_nick(nick: str) -> bool:
    """Ник из резерва, который ещё никому не подарен: занять его самому нельзя."""
    return bool(_run("SELECT 1 FROM reserved_nicks WHERE nick_norm=? AND gifted_to IS NULL", (nick_norm(nick),), one=True))


def list_reserved_nicks():
    return _run("SELECT * FROM reserved_nicks ORDER BY nick", many=True)


def add_reserved_nick(nick: str) -> bool:
    """Добавляет ник в резерв. False — такой уже есть в резерве или его уже занял человек."""
    nick = re.sub(r"\s+", " ", nick.strip())
    if not nick or _run("SELECT 1 FROM reserved_nicks WHERE nick_norm=?", (nick_norm(nick),), one=True) \
            or nick_taken(nick):
        return False
    _run("INSERT INTO reserved_nicks (nick_norm, nick) VALUES (?,?)", (nick_norm(nick), nick))
    return True


def gift_nick(user_id: int, nick: str) -> str:
    """Дарит ник из резерва человеку (его прежний ник освобождается). Возвращает 'ok', 'no_user', 'not_reserved'
    (такого ника в резерве нет) или 'gifted' (уже подарен другому)."""
    if not get_user(user_id):
        return "no_user"
    row = _run("SELECT * FROM reserved_nicks WHERE nick_norm=?", (nick_norm(nick),), one=True)
    if not row:
        return "not_reserved"
    if row["gifted_to"] not in (None, user_id):
        return "gifted"
    update_user_fields(user_id, nick=row["nick"], nick_norm=row["nick_norm"])
    _run("UPDATE reserved_nicks SET gifted_to=?, gifted_at=? WHERE nick_norm=?",
         (user_id, now().strftime(DATE_FMT), row["nick_norm"]))
    return "ok"


def active_users(limit: int = 15):
    """Самые активные: больше всего сохранённых смет (потом — больше своих работ). Для выбора, кому подарить ник."""
    return _run(
        "SELECT u.user_id, u.nick, "
        "(SELECT COUNT(*) FROM estimates e WHERE e.user_id=u.user_id) AS n_est, "
        "(SELECT COUNT(*) FROM custom_items c WHERE c.user_id=u.user_id) AS n_items, "
        "(SELECT MAX(e.created) FROM estimates e WHERE e.user_id=u.user_id) AS last "
        "FROM users u WHERE u.ready=1 ORDER BY n_est DESC, n_items DESC, u.user_id LIMIT ?", (limit,), many=True)


def auto_nick(user_id: int) -> str:
    """Свободный ник вроде «Мастер 482» (цифр больше, если трёхзначные закончились)."""
    for digits in (3, 4, 5):
        for _ in range(60):
            nick = f"Мастер {random.randint(10 ** (digits - 1), 10 ** digits - 1)}"
            if set_nick(user_id, nick):
                return nick
    nick = f"Мастер {user_id}"
    set_nick(user_id, nick)
    return nick


# --- Приглашения -----------------------------------------------------------------------
def ensure_ref_code(user_id: int) -> str:
    row = get_user(user_id)
    if row["ref_code"]:
        return row["ref_code"]
    alphabet = "abcdefghjkmnpqrstuvwxyz23456789"
    while True:
        code = "".join(random.choice(alphabet) for _ in range(8))
        if not _run("SELECT 1 FROM users WHERE ref_code=?", (code,), one=True):
            break
    update_user_fields(user_id, ref_code=code)
    return code


def user_by_ref(code: str):
    return _run("SELECT * FROM users WHERE ref_code=?", (code,), one=True) if code else None


def invite_stats(user_id: int) -> dict:
    """Сколько друзей зашли по ссылке и сколько из них посчитали смету."""
    one = lambda sql: _run(sql, (user_id,), one=True)[0]
    return {
        "entered": one("SELECT COUNT(*) FROM users WHERE invited_by=? AND joined IS NOT NULL"),
        "counted": one("SELECT COUNT(*) FROM users WHERE invited_by=? AND first_calc IS NOT NULL"),
    }


def mark_calculated(user_id: int):
    """Человек впервые посчитал смету. Если его пригласил друг и бонус за него ещё не начислен, добавляет
    пригласившему дни к сроку (один раз за каждого друга). Возвращает (номер пригласившего, дней) или None."""
    user = get_user(user_id)
    if not user or user["first_calc"]:
        return None
    _run("UPDATE users SET first_calc=? WHERE user_id=? AND first_calc IS NULL",
         (now().strftime(DATE_FMT), user_id))
    inviter = user["invited_by"]
    days = bonus_days()
    if not inviter or inviter == user_id or user["bonus_paid"] or days <= 0:
        return None
    boss = get_user(inviter)
    if not boss:
        return None
    # помечаем «выплачено» первым, условием в запросе: два одновременных расчёта не начислят бонус дважды
    with _conn() as conn:
        done = conn.execute("UPDATE users SET bonus_paid=1 WHERE user_id=? AND bonus_paid=0", (user_id,)).rowcount
    if not done:
        return None
    base = max(now(), datetime.strptime(boss["expires"], DATE_FMT)) if boss["expires"] else now()
    _run("UPDATE users SET expires=? WHERE user_id=?", ((base + timedelta(days=days)).strftime(DATE_FMT), inviter))
    return inviter, days


# --- Пожелания и ошибки ------------------------------------------------------------------
def add_feedback(user_id: int, text: str, kind: str = "wish", est_ref: str = "") -> int:
    return _run("INSERT INTO feedback (user_id, text, kind, est_ref) VALUES (?,?,?,?)",
                (user_id, text, kind, est_ref))


def list_feedback(limit: int = 50):
    """Пожелания, новые сверху. Возвращает (строки, всего записей)."""
    rows = _run("SELECT * FROM feedback ORDER BY id DESC LIMIT ?", (limit,), many=True)
    return rows, _run("SELECT COUNT(*) AS n FROM feedback", one=True)["n"]


def list_new_feedback():
    """Ещё не просмотренные владельцем, по дате: новые сверху."""
    return _run("SELECT * FROM feedback WHERE COALESCE(seen,0)=0 ORDER BY created DESC, id DESC", many=True)


def mark_feedback_seen(ids: list) -> None:
    for i in ids:
        _run("UPDATE feedback SET seen=1 WHERE id=?", (i,))


# --- «Верно» / «Есть ошибка» под сметой ---------------------------------------------------
def add_vote(user_id: int, ref: str, vote: str) -> bool:
    """Один голос на смету от одного человека. False — уже голосовал."""
    with _conn() as conn:
        return conn.execute("INSERT OR IGNORE INTO est_votes (user_id, ref, vote) VALUES (?,?,?)",
                            (user_id, ref, vote)).rowcount > 0


def vote_counts() -> dict:
    rows = _run("SELECT vote, COUNT(*) AS n FROM est_votes GROUP BY vote", many=True)
    return {r["vote"]: r["n"] for r in rows}


# --- Цены ---------------------------------------------------------------------
def ensure_prices(user_id: int) -> None:
    """Заполняет образцом недостающие цены (при первом запуске — все)."""
    user = get_user(user_id)
    existing = {r["key"] for r in _run("SELECT key FROM prices WHERE user_id=?", (user_id,), many=True)}
    for key in catalog.ITEM_BY_KEY:
        if key not in existing:
            _run(
                "INSERT INTO prices (user_id, key, value) VALUES (?,?,?)",
                (user_id, key, catalog.sample_price(key, user["currency"])),
            )
    if user["min_total"] is None:
        update_user(user_id, min_total=catalog.sample_min_total(user["currency"]))


def get_prices(user_id: int) -> dict:
    rows = _run("SELECT key, value FROM prices WHERE user_id=?", (user_id,), many=True)
    return {r["key"]: r["value"] for r in rows}


def scale_prices(user_id: int, factor: float) -> int:
    """Поднимает (factor > 1) или снижает цены мастера на процент: прайс и свои работы. Нулевые цены («укажите свою»)
    не трогаем. В общий анонимный прайс ничего не уходит. Возвращает, сколько цен изменено."""
    with _conn() as conn:
        a = conn.execute("UPDATE prices SET value=ROUND(value*?, 2) WHERE user_id=? AND value>0",
                         (factor, user_id)).rowcount
        b = conn.execute("UPDATE custom_items SET price=ROUND(price*?, 2) WHERE user_id=? AND price>0",
                         (factor, user_id)).rowcount
    return a + b


def set_price(user_id: int, key: str, value: float) -> None:
    """Сохраняет цену пользователя и анонимно дублирует её в общую базу."""
    _run(
        "INSERT INTO prices (user_id, key, value) VALUES (?,?,?) "
        "ON CONFLICT(user_id, key) DO UPDATE SET value=excluded.value",
        (user_id, key, value),
    )
    user = get_user(user_id)
    _run(
        "INSERT INTO shared_prices (country, city, key, value, currency) VALUES (?,?,?,?,?)",
        (user["country"], user["city"], key, value, user["currency"]),
    )


# --- Справочные цены и свои работы -----------------------------------------------
def reference_prices(city: str):
    """Ориентиры по городу (справочно, в расчёт не входят)."""
    return _run("SELECT * FROM reference_prices WHERE city=? ORDER BY id", (city,), many=True)


def _item_key(title: str, unit: str) -> tuple:
    """Ключ «та же услуга»: название (без регистра, пробелов и «ё») и единица."""
    return sections.norm(title), (unit or "").strip().lower()


def find_custom_item(user_id: int, title: str, unit: str):
    key = _item_key(title, unit)
    for r in _run("SELECT * FROM custom_items WHERE user_id=? ORDER BY id", (user_id,), many=True):
        if _item_key(r["title"], r["unit"]) == key:
            return r
    return None


def _section_id(conn: sqlite3.Connection, user_id: int, name: str) -> int:
    """Номер раздела по названию (без учёта регистра); нет такого — раздел создаётся."""
    key = sections.norm(name)
    for r in conn.execute("SELECT id, name FROM custom_sections WHERE user_id=?", (user_id,)).fetchall():
        if sections.norm(r["name"]) == key:
            return r["id"]
    return conn.execute("INSERT INTO custom_sections (user_id, name) VALUES (?,?)",
                        (user_id, sections.clean_name(name))).lastrowid


def _auto_section_id(conn: sqlite3.Connection, user_id: int, title: str, group: str | None = None) -> int:
    """Раздел для новой услуги: названный группой в файле, иначе по названию услуги; не уверен — 0 (без раздела)."""
    if group:
        existing = [r["name"] for r in conn.execute("SELECT name FROM custom_sections WHERE user_id=?", (user_id,))]
        return _section_id(conn, user_id, sections.match_existing(group, existing))
    name = sections.classify(title)
    return _section_id(conn, user_id, name) if name else 0


def add_custom_item(user_id: int, title: str, unit: str, price: float, group: str | None = None) -> int:
    """Сохраняет свою работу в «Мои цены». Такая же работа (название и единица) обновляется, а не дублируется.
    Новая работа попадает в раздел: group (из файла) или по названию; не уверены — «Без раздела»."""
    row = find_custom_item(user_id, title, unit)
    if row:
        _run("UPDATE custom_items SET price=? WHERE id=?", (price, row["id"]))
        return row["id"]
    with _conn() as conn:
        sid = _auto_section_id(conn, user_id, title, group)
        return conn.execute("INSERT INTO custom_items (user_id, title, unit, price, section_id) VALUES (?,?,?,?,?)",
                            (user_id, title, unit, price, sid)).lastrowid


def ensure_custom_item(user_id: int, title: str, unit: str, price: float) -> int:
    """Кладёт свою работу в «Мои цены», только если её там ещё нет (цену, которую человек уже поменял, не затираем)."""
    row = find_custom_item(user_id, title, unit)
    if row:
        return row["id"]
    return add_custom_item(user_id, title, unit, price)


def list_custom_items(user_id: int):
    return _run("SELECT * FROM custom_items WHERE user_id=? ORDER BY id", (user_id,), many=True)


def count_import_matches(user_id: int, items: list) -> int:
    """Сколько из загружаемых услуг (название + единица) уже есть у мастера. items: [(название, единица, цена, группа)]."""
    have = {_item_key(r["title"], r["unit"]) for r in list_custom_items(user_id)}
    return sum(1 for it in items if _item_key(it[0], it[1]) in have)


def import_custom_items(user_id: int, items: list, mode: str = "replace") -> dict:
    """Загрузка прайса. items: [(название, единица, цена, группа или None)].
    mode: 'replace' — у совпавших услуг меняем цену, новые добавляем; 'new' — добавляем только новые.
    Всё в одной транзакции: либо загрузилось всё, либо ничего. Возвращает {'added', 'updated', 'kept'}."""
    added = updated = kept = 0
    with _conn() as conn:
        index = {_item_key(r["title"], r["unit"]): r["id"]
                 for r in conn.execute("SELECT id, title, unit FROM custom_items WHERE user_id=?", (user_id,))}
        for title, unit, price, group in items:
            key = _item_key(title, unit)
            if key in index:
                if mode == "replace":
                    conn.execute("UPDATE custom_items SET price=? WHERE id=?", (price, index[key]))
                    if group:   # у услуги, которая была без раздела, появилась группа в файле
                        conn.execute("UPDATE custom_items SET section_id=? WHERE id=? AND COALESCE(section_id,0)=0",
                                     (_auto_section_id(conn, user_id, title, group), index[key]))
                    updated += 1
                else:
                    kept += 1
                continue
            sid = _auto_section_id(conn, user_id, title, group)
            index[key] = conn.execute("INSERT INTO custom_items (user_id, title, unit, price, section_id) "
                                      "VALUES (?,?,?,?,?)", (user_id, title, unit, price, sid)).lastrowid
            added += 1
    return {"added": added, "updated": updated, "kept": kept}


# --- Разделы своих работ -----------------------------------------------------------
def list_sections(user_id: int) -> list:
    """Разделы своих работ с числом услуг: [{'id', 'name', 'n'}]. Стандартные — в обычном порядке, потом остальные
    по алфавиту, «Без раздела» (id 0) — последним и только если в нём что-то есть. Пустые разделы не показываются."""
    rows = _run("SELECT s.id, s.name, (SELECT COUNT(*) FROM custom_items c WHERE c.user_id=s.user_id "
                "AND c.section_id=s.id) AS n FROM custom_sections s WHERE s.user_id=?", (user_id,), many=True)
    order = {n: i for i, n in enumerate(sections.DEFAULT_SECTIONS)}
    out = sorted(({"id": r["id"], "name": r["name"], "n": r["n"]} for r in rows if r["n"] > 0),
                 key=lambda s: (order.get(s["name"], 99), s["name"].lower()))
    free = _run("SELECT COUNT(*) AS n FROM custom_items WHERE user_id=? AND COALESCE(section_id,0)=0",
                (user_id,), one=True)["n"]
    if free:
        out.append({"id": 0, "name": sections.NO_SECTION, "n": free})
    return out


def section_name(user_id: int, section_id: int):
    """Название раздела (0 — «Без раздела»); None — такого раздела нет."""
    if not section_id:
        return sections.NO_SECTION
    r = _run("SELECT name FROM custom_sections WHERE id=? AND user_id=?", (section_id, user_id), one=True)
    return r["name"] if r else None


def list_section_items(user_id: int, section_id: int):
    return _run("SELECT * FROM custom_items WHERE user_id=? AND COALESCE(section_id,0)=? ORDER BY id",
                (user_id, section_id or 0), many=True)


def custom_theme_map(user_id: int) -> dict:
    """{'c12': 'Плитка'} — раздел каждой своей работы (без раздела — «Мои работы»), для списков в конструкторе."""
    rows = _run("SELECT c.id, s.name FROM custom_items c LEFT JOIN custom_sections s ON s.id=c.section_id "
                "WHERE c.user_id=?", (user_id,), many=True)
    return {f"c{r['id']}": (r["name"] or "Мои работы") for r in rows}


def drop_empty_sections(user_id: int | None = None) -> None:
    """Раздел, в котором не осталось услуг, исчезает."""
    where = "AND s.user_id=?" if user_id is not None else ""
    params = (user_id,) if user_id is not None else ()
    _run("DELETE FROM custom_sections WHERE id IN (SELECT s.id FROM custom_sections s WHERE NOT EXISTS "
         f"(SELECT 1 FROM custom_items c WHERE c.section_id=s.id) {where})", params)


def move_items(user_id: int, item_ids: list, section_id: int) -> int:
    """Переносит услуги мастера в раздел (0 — без раздела). Чужие номера игнорируются. Возвращает, сколько перенесено."""
    n = 0
    with _conn() as conn:
        for i in item_ids:
            n += conn.execute("UPDATE custom_items SET section_id=? WHERE id=? AND user_id=?",
                              (section_id or 0, int(i), user_id)).rowcount
    drop_empty_sections(user_id)
    return n


def merge_sections(user_id: int, src_id: int, dst_id: int) -> int:
    """«Соединить»: все услуги раздела src переходят в dst, пустой раздел исчезает. Возвращает число перенесённых."""
    if src_id == dst_id or (dst_id and section_name(user_id, dst_id) is None):
        return 0
    ids = [r["id"] for r in list_section_items(user_id, src_id)]
    return move_items(user_id, ids, dst_id)


def split_section(user_id: int, item_ids: list, new_name: str) -> tuple:
    """«Разделить»: выбранные услуги уходят в новый раздел с названием от мастера. Возвращает (номер раздела, сколько)."""
    name = sections.clean_name(new_name)
    if not name:
        return 0, 0
    with _conn() as conn:
        sid = _section_id(conn, user_id, name)
    return sid, move_items(user_id, item_ids, sid)


def section_id_by_name(user_id: int, name: str):
    """Номер раздела по названию (без учёта регистра и «ё»): 0 — «Без раздела», None — такого раздела нет."""
    key = sections.norm(name)
    if key == sections.norm(sections.NO_SECTION):
        return 0
    for s in _run("SELECT id, name FROM custom_sections WHERE user_id=?", (user_id,), many=True):
        if sections.norm(s["name"]) == key:
            return s["id"]
    return None


def section_exists(user_id: int, name: str) -> bool:
    key = sections.norm(name)
    return key == sections.norm(sections.NO_SECTION) or any(
        sections.norm(s["name"]) == key for s in _run("SELECT name FROM custom_sections WHERE user_id=?",
                                                      (user_id,), many=True))


def _remap_keys(node, mapping: dict):
    """Меняет в JSON-данных сметы ключи удалённых дублей (c12 → c7). Возвращает True, если что-то изменилось."""
    changed = False
    if isinstance(node, dict):
        for k, v in list(node.items()):
            if k == "key" and isinstance(v, str) and v in mapping:
                node[k] = mapping[v]
                changed = True
            elif isinstance(v, (dict, list)):
                changed |= _remap_keys(v, mapping)
    elif isinstance(node, list):
        for v in node:
            if isinstance(v, (dict, list)):
                changed |= _remap_keys(v, mapping)
    return changed


def _duplicate_map(user_id: int | None = None) -> tuple:
    """Находит точные копии своих работ (одинаковые название, единица и цена). Остаётся самая ранняя.
    Возвращает ({номер мастера: {'c<копия>': 'c<оставшаяся>'}}, сколько групп с тем же названием, но другой ценой)."""
    where, params = ("WHERE user_id=?", (user_id,)) if user_id is not None else ("", ())
    groups: dict = {}
    for r in _run(f"SELECT * FROM custom_items {where} ORDER BY id", params, many=True):
        groups.setdefault((r["user_id"], *_item_key(r["title"], r["unit"])), []).append(r)
    mapping_by_user: dict = {}
    other_price = 0
    for (uid, _t, _u), rows in groups.items():
        prices = {round(float(r["price"] or 0), 4) for r in rows}
        if len(prices) > 1:
            other_price += 1
        seen: dict = {}
        for r in rows:
            p = round(float(r["price"] or 0), 4)
            if p in seen:
                mapping_by_user.setdefault(uid, {})[f"c{r['id']}"] = f"c{seen[p]}"
            else:
                seen[p] = r["id"]
    return mapping_by_user, other_price


def count_duplicates(user_id: int) -> dict:
    """Только считает, ничего не удаляет: {'items': всего услуг, 'extra': лишних копий, 'same_name_other_price': групп с разной ценой}."""
    mapping, other = _duplicate_map(user_id)
    items = _run("SELECT COUNT(*) AS n FROM custom_items WHERE user_id=?", (user_id,), one=True)["n"]
    return {"items": items, "extra": len(mapping.get(user_id, {})), "same_name_other_price": other}


def dedupe_custom_items(user_id: int | None = None) -> dict:
    """Удаляет точные копии своих работ (одинаковые название, единица и цена): остаётся самая ранняя.
    Работы с тем же названием, но другой ценой не трогаются (только считаются). Открытые и сохранённые сметы,
    которые ссылались на удалённую копию, переключаются на оставшуюся.
    Возвращает {'removed': сколько удалено, 'same_name_other_price': сколько групп с разной ценой}."""
    mapping_by_user, other_price = _duplicate_map(user_id)
    removed = 0
    with _conn() as conn:
        for uid, mapping in mapping_by_user.items():
            for old in mapping:
                removed += conn.execute("DELETE FROM custom_items WHERE id=? AND user_id=?",
                                        (int(old[1:]), uid)).rowcount
            for table, col in (("drafts", "state"), ("estimates", "params"), ("estimates", "result")):
                for row in conn.execute(f"SELECT id, {col} FROM {table} WHERE user_id=?", (uid,)).fetchall():
                    try:
                        data = json.loads(row[col] or "null")
                    except ValueError:
                        continue
                    if _remap_keys(data, mapping):
                        conn.execute(f"UPDATE {table} SET {col}=? WHERE id=?",
                                     (json.dumps(data, ensure_ascii=False), row["id"]))
    drop_empty_sections(user_id)
    return {"removed": removed, "same_name_other_price": other_price}


def assign_sections(user_id: int | None = None) -> dict:
    """Раскладывает услуги, которые лежат «Без раздела», по разделам по названию (правила — в sections.py).
    Не уверены — услуга остаётся без раздела. Возвращает {'moved': {раздел: сколько}, 'left': сколько осталось}."""
    where, params = ("AND user_id=?", (user_id,)) if user_id is not None else ("", ())
    moved: dict = {}
    left = 0
    with _conn() as conn:
        for r in conn.execute(f"SELECT id, user_id, title FROM custom_items WHERE COALESCE(section_id,0)=0 {where}",
                              params).fetchall():
            name = sections.classify(r["title"])
            if not name:
                left += 1
                continue
            conn.execute("UPDATE custom_items SET section_id=? WHERE id=?",
                         (_section_id(conn, r["user_id"], name), r["id"]))
            moved[name] = moved.get(name, 0) + 1
    return {"moved": moved, "left": left}


def backup_file(label: str) -> Path | None:
    """Копия базы с датой в имени рядом с файлом базы (папка backups). Возвращает путь копии."""
    if not DB_PATH.exists():
        return None
    folder = DB_PATH.parent / "backups"
    folder.mkdir(exist_ok=True)
    target = folder / f"{label}_{now().strftime('%Y-%m-%d_%H%M%S')}.db"   # не «bot_*.db»: ночная чистка копий это имя не тронет
    src, dst = sqlite3.connect(DB_PATH), sqlite3.connect(target)
    try:
        src.backup(dst)
    finally:
        dst.close()
        src.close()
    return target


def sections_report() -> dict | None:
    """Итог разовой уборки в «Мои цены» (JSON в настройках) или None, если уборки ещё не было."""
    row = _run("SELECT value FROM settings WHERE key='sections_report'", one=True)
    return json.loads(row["value"]) if row and row["value"] else None


def take_sections_report() -> dict | None:
    """Отчёт об уборке, который ещё не отправляли владельцу (один раз): после вызова считается отправленным."""
    if not _run("SELECT 1 FROM settings WHERE key='sections_report_pending'", one=True):
        return None
    _run("DELETE FROM settings WHERE key='sections_report_pending'")
    return sections_report()


def migrate_sections(owner_id: int | None = None) -> dict | None:
    """Однократно (метка в настройках): копия базы, удаление точных дублей своих работ и раскладка по разделам.
    Сначала обрабатывается владелец (его цифры отдельно), потом остальные мастера. Итог кладётся в настройку
    sections_report (JSON), владельцу бот сообщит при запуске. Повторно не запускается."""
    if _run("SELECT 1 FROM settings WHERE key='sections_v1'", one=True):
        return None
    has_items = _run("SELECT COUNT(*) AS n FROM custom_items", one=True)["n"]
    path = backup_file("before_sections") if has_items else None
    mine = {"removed": 0, "same_name_other_price": 0, "moved": {}, "left": 0}
    if owner_id:
        dup, asg = dedupe_custom_items(owner_id), assign_sections(owner_id)
        mine = {"removed": dup["removed"], "same_name_other_price": dup["same_name_other_price"],
                "moved": asg["moved"], "left": asg["left"]}
    others = {"removed": 0, "moved": 0, "left": 0}   # остальные мастера (у владельца уже сделано)
    for r in _run("SELECT DISTINCT user_id FROM custom_items WHERE user_id<>?", (owner_id or 0,), many=True):
        dup, asg = dedupe_custom_items(r["user_id"]), assign_sections(r["user_id"])
        others["removed"] += dup["removed"]
        others["moved"] += sum(asg["moved"].values())
        others["left"] += asg["left"]
    report = {"owner": mine, "others": others, "backup": path.name if path else ""}
    _run("INSERT OR REPLACE INTO settings (key, value) VALUES ('sections_report', ?)",
         (json.dumps(report, ensure_ascii=False),))
    _run("INSERT OR REPLACE INTO settings (key, value) VALUES ('sections_report_pending', '1')")
    _run("INSERT INTO settings (key, value) VALUES ('sections_v1', '1')")
    return report


def get_custom_item(user_id: int, item_id: int):
    return _run("SELECT * FROM custom_items WHERE id=? AND user_id=?", (item_id, user_id), one=True)


def set_custom_price(user_id: int, item_id: int, price: float) -> None:
    _run("UPDATE custom_items SET price=? WHERE id=? AND user_id=?", (price, item_id, user_id))


def delete_custom_item(user_id: int, item_id: int) -> None:
    _run("DELETE FROM custom_items WHERE id=? AND user_id=?", (item_id, user_id))
    drop_empty_sections(user_id)


# --- Объекты ------------------------------------------------------------------
def create_object(user_id: int, name: str) -> int:
    return _run("INSERT INTO objects (user_id, name) VALUES (?,?)", (user_id, name))


def list_objects(user_id: int, status: str = "open"):
    """Объекты (status: open — в работе, done — завершённые) с числом смет и суммами.
    n_main/total_main — основные сметы, n_extra/total_extra — допработы."""
    return _run(
        "SELECT o.id, o.name, o.status, "
        "COUNT(e.id) AS n, COALESCE(SUM(e.total), 0) AS total, "
        "COALESCE(SUM(e.kind='extra'), 0) AS n_extra, "
        "COALESCE(SUM(CASE WHEN e.kind='extra' THEN e.total ELSE 0 END), 0) AS total_extra "
        "FROM objects o LEFT JOIN estimates e ON e.object_id=o.id "
        "WHERE o.user_id=? AND COALESCE(o.status,'open')=? GROUP BY o.id ORDER BY o.id DESC",
        (user_id, status),
        many=True,
    )


def set_object_status(object_id: int, status: str) -> None:
    _run("UPDATE objects SET status=? WHERE id=?", (status, object_id))


def get_object(user_id: int, object_id: int):
    return _run("SELECT * FROM objects WHERE id=? AND user_id=?", (object_id, user_id), one=True)


def rename_object(object_id: int, name: str) -> None:
    _run("UPDATE objects SET name=? WHERE id=?", (name, object_id))


def delete_object(object_id: int) -> None:
    _run("DELETE FROM estimates WHERE object_id=?", (object_id,))
    _run("DELETE FROM objects WHERE id=?", (object_id,))


# --- Сметы --------------------------------------------------------------------
ESTIMATE_STATUSES = ("open", "work", "done")   # Открыта · В работе · Завершена (архив)


def save_estimate(user_id: int, object_id: int, room: str, title: str, has_tile: bool,
                  params: dict, result: dict, estimate_id: int | None = None, kind: str = "main",
                  parent_id: int | None = None, note: str | None = None, status: str | None = None) -> int:
    """Создаёт смету или (если задан estimate_id) перезаписывает существующую.
    kind: main — основная смета, extra — допработа. parent_id — смета «В работе», к которой относится допработа
    (допработа наследует её статус). note — заметка (при правке None оставляет прежнюю). Статус при правке не меняется."""
    p = json.dumps(params, ensure_ascii=False)
    r = json.dumps(result, ensure_ascii=False)
    if estimate_id:
        _run(
            "UPDATE estimates SET object_id=?, title=?, has_tile=?, params=?, result=?, total=? WHERE id=? AND user_id=?",
            (object_id, title, int(has_tile), p, r, result["total"], estimate_id, user_id),
        )
        if note is not None:
            set_estimate_note(user_id, estimate_id, note)
        return estimate_id
    if status is None:
        parent = get_estimate(user_id, parent_id) if parent_id else None
        status = (parent["status"] if parent else None) or "open"
    return _run(
        "INSERT INTO estimates (object_id, user_id, room, title, has_tile, params, result, total, kind, "
        "parent_id, note, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
        (object_id, user_id, room, title, int(has_tile), p, r, result["total"], kind, parent_id, note or "", status),
    )


def list_estimates(user_id: int, object_id: int | None = None, tiler_only: bool = False,
                   status: str | None = None):
    """Сметы пользователя, новые сверху. status — только с этим статусом ('active' — открытые и в работе)."""
    sql = ("SELECT e.*, o.name AS object_name FROM estimates e JOIN objects o ON o.id=e.object_id "
           "WHERE e.user_id=?")
    args: list = [user_id]
    if object_id is not None:
        sql += " AND e.object_id=?"
        args.append(object_id)
    if tiler_only:
        sql += " AND e.has_tile=1"
    if status == "active":
        sql += " AND COALESCE(e.status,'open') IN ('open','work')"
    elif status:
        sql += " AND COALESCE(e.status,'open')=?"
        args.append(status)
    sql += " ORDER BY e.id DESC"
    return _run(sql, tuple(args), many=True)


def list_children(user_id: int, parent_id: int):
    """Допработы, добавленные к смете «В работе» (по порядку добавления)."""
    return _run("SELECT * FROM estimates WHERE user_id=? AND parent_id=? ORDER BY id", (user_id, parent_id), many=True)


def set_estimate_status(user_id: int, estimate_id: int, status: str) -> None:
    """Меняет статус сметы; её допработы получают тот же статус (завершили смету — допработы ушли в архив вместе с ней)."""
    if status not in ESTIMATE_STATUSES:
        return
    _run("UPDATE estimates SET status=? WHERE (id=? OR parent_id=?) AND user_id=?",
         (status, estimate_id, estimate_id, user_id))


def set_estimate_note(user_id: int, estimate_id: int, note: str) -> None:
    _run("UPDATE estimates SET note=? WHERE id=? AND user_id=?", (note, estimate_id, user_id))


def set_object_note(user_id: int, object_id: int, note: str) -> None:
    _run("UPDATE objects SET note=? WHERE id=? AND user_id=?", (note, object_id, user_id))


def count_estimates_by_status(user_id: int) -> dict:
    rows = _run("SELECT COALESCE(status,'open') AS s, COUNT(*) AS n FROM estimates WHERE user_id=? GROUP BY s",
                (user_id,), many=True)
    return {r["s"]: r["n"] for r in rows}


def get_estimate(user_id: int, estimate_id: int):
    return _run(
        "SELECT e.*, o.name AS object_name FROM estimates e JOIN objects o ON o.id=e.object_id "
        "WHERE e.id=? AND e.user_id=?",
        (estimate_id, user_id),
        one=True,
    )


def delete_estimate(user_id: int, estimate_id: int) -> None:
    _run("DELETE FROM estimates WHERE parent_id=? AND user_id=?", (estimate_id, user_id))   # допработы уходят со сметой
    _run("DELETE FROM estimates WHERE id=? AND user_id=?", (estimate_id, user_id))


# --- Тихий счётчик (для владельца) ---------------------------------------------------
def log_event(kind: str, key: str = "") -> None:
    """Записывает событие без номера человека: est_started, est_saved, work (название работы в key)."""
    _run("INSERT INTO stat_events (kind, key) VALUES (?,?)", (kind, key[:80]))


def stats_summary() -> dict:
    one = lambda sql, args=(): _run(sql, args, one=True)[0]
    return {
        "users": one("SELECT COUNT(*) FROM users"),
        "ready": one("SELECT COUNT(*) FROM users WHERE ready=1"),
        "waitlist": one("SELECT COUNT(*) FROM waitlist"),
        "joined": one("SELECT COUNT(*) FROM users WHERE joined IS NOT NULL"),
        "expired": one("SELECT COUNT(*) FROM users WHERE expires IS NOT NULL AND expires < ?",
                       (now().strftime(DATE_FMT),)),
        "invited": one("SELECT COUNT(*) FROM users WHERE invited_by IS NOT NULL AND joined IS NOT NULL"),
        "invited_counted": one("SELECT COUNT(*) FROM users WHERE invited_by IS NOT NULL AND first_calc IS NOT NULL"),
        "bonus_paid": one("SELECT COUNT(*) FROM users WHERE bonus_paid=1"),
        "bugs_new": one("SELECT COUNT(*) FROM feedback WHERE kind='bug' AND COALESCE(seen,0)=0"),
        "started": one("SELECT COUNT(*) FROM stat_events WHERE kind='est_started'"),
        "saved": one("SELECT COUNT(*) FROM stat_events WHERE kind='est_saved'"),
        "done_now": one("SELECT COUNT(*) FROM estimates WHERE status='done'"),
        "estimates_now": one("SELECT COUNT(*) FROM estimates"),
        "pending": one("SELECT COUNT(*) FROM (SELECT 1 FROM pool_pending GROUP BY norm, unit)"),
    }


def popular_works(limit: int = 15):
    return _run("SELECT key, COUNT(*) AS n FROM stat_events WHERE kind='work' GROUP BY key "
                "ORDER BY n DESC, key LIMIT ?", (limit,), many=True)


# --- Общий прайс из загруженных смет ---------------------------------------------------
def pool_add_price(title: str, unit: str, price: float, country: str, city: str, currency: str) -> None:
    _run("INSERT INTO pool_prices (title, unit, price, country, city, currency) VALUES (?,?,?,?,?,?)",
         (title, unit, price, country, city, currency))


def pool_prices(title: str, unit: str, currency: str) -> list:
    """Цены одной работы в одной единице и одной валюте (по разным единицам цены не сравниваем)."""
    rows = _run("SELECT price FROM pool_prices WHERE title=? AND unit=? AND currency=? ORDER BY price",
                (title, unit, currency), many=True)
    return [r["price"] for r in rows]


def pool_names():
    return _run("SELECT * FROM pool_names ORDER BY id", many=True)


def pool_add_name(title: str) -> int:
    row = _run("SELECT id FROM pool_names WHERE lower(title)=lower(?)", (title,), one=True)
    return row["id"] if row else _run("INSERT INTO pool_names (title) VALUES (?)", (title,))


def pending_add(title: str, norm: str, unit: str, price: float, country: str, city: str, currency: str) -> None:
    _run("INSERT INTO pool_pending (title, norm, unit, price, country, city, currency) VALUES (?,?,?,?,?,?,?)",
         (title, norm, unit, price, country, city, currency))


def pending_groups():
    """Названия на проверку: одна строка на (название, единица) с числом загрузок и вилкой цен. id — любая строка группы."""
    return _run("SELECT MIN(id) AS id, norm, unit, MIN(title) AS title, COUNT(*) AS n, MIN(price) AS pmin, "
                "MAX(price) AS pmax, AVG(price) AS pavg, currency FROM pool_pending "
                "GROUP BY norm, unit, currency ORDER BY n DESC, id", many=True)


def pending_rows(row_id: int) -> list:
    """Все загрузки той группы, к которой относится строка row_id."""
    one = _run("SELECT norm, unit, currency FROM pool_pending WHERE id=?", (row_id,), one=True)
    if not one:
        return []
    return _run("SELECT * FROM pool_pending WHERE norm=? AND unit=? AND currency=? ORDER BY id",
                (one["norm"], one["unit"], one["currency"]), many=True)


def pending_delete(row_id: int) -> None:
    one = _run("SELECT norm, unit, currency FROM pool_pending WHERE id=?", (row_id,), one=True)
    if one:
        _run("DELETE FROM pool_pending WHERE norm=? AND unit=? AND currency=?",
             (one["norm"], one["unit"], one["currency"]))


# --- Геометрия объекта (этап 1.5) ------------------------------------------------
# Паспорт объекта: комнаты, точки, стены, проёмы. Наполняется только новыми замерами;
# старые сметы и черновики (JSON в drafts/estimates) здесь не участвуют и не меняются.


def create_room(object_id: int, name: str, kind: str | None = None) -> int:
    """Комната паспорта объекта. Возвращает её номер."""
    return _run("INSERT INTO rooms (object_id, name, kind) VALUES (?,?,?)", (object_id, name, kind))


def get_room(room_id: int):
    return _run("SELECT * FROM rooms WHERE id=?", (room_id,), one=True)


def list_rooms(object_id: int):
    """Комнаты объекта в порядке добавления, с числом стен и проёмов."""
    return _run(
        "SELECT r.*, (SELECT COUNT(*) FROM walls w WHERE w.room_id=r.id) AS n_walls, "
        "(SELECT COUNT(*) FROM openings o WHERE o.room_id=r.id) AS n_openings "
        "FROM rooms r WHERE r.object_id=? ORDER BY r.id", (object_id,), many=True)


def set_room_measured(room_id: int, hei: float, input_mode: str, closed: bool,
                      closing_gap: float = 0.0) -> None:
    """Отметка, что контур комнаты введён и проверен (hei — высота, режим — rect|lengths|arrows)."""
    _run("UPDATE rooms SET hei=?, input_mode=?, closed=?, closing_gap=? WHERE id=?",
         (hei, input_mode, int(closed), closing_gap, room_id))


def rename_room(room_id: int, name: str) -> None:
    _run("UPDATE rooms SET name=? WHERE id=?", (name, room_id))


def delete_room_geometry(room_id: int) -> None:
    """Стирает контур комнаты (точки, стены, проёмы, короба) для повторного замера. Комната остаётся."""
    for table in ("openings", "duct_boxes", "walls", "points"):
        _run(f"DELETE FROM {table} WHERE room_id=?", (room_id,))


def delete_room(room_id: int) -> None:
    delete_room_geometry(room_id)
    _run("DELETE FROM rooms WHERE id=?", (room_id,))


def add_point(room_id: int, ord_: int, x: float | None = None, y: float | None = None) -> int:
    """Точка контура; порядок уникален в комнате (повторный вызов с тем же ord перезаписывает координаты)."""
    return _run(
        "INSERT INTO points (room_id, ord, x, y) VALUES (?,?,?,?) "
        "ON CONFLICT(room_id, ord) DO UPDATE SET x=excluded.x, y=excluded.y",
        (room_id, ord_, x, y))


def list_points(room_id: int):
    return _run("SELECT * FROM points WHERE room_id=? ORDER BY ord", (room_id,), many=True)


def add_wall(room_id: int, p_from: int, p_to: int, length: float,
             direction: int | None = None, kind: str = "bearing") -> int:
    """Стена от точки p_from к точке p_to (направление = направление обхода контура)."""
    return _run("INSERT INTO walls (room_id, p_from, p_to, length, direction, kind) VALUES (?,?,?,?,?,?)",
                (room_id, p_from, p_to, round(length, 2), direction, kind))


def set_wall_adj(wall_id: int, length_adj: float) -> None:
    """Длина после усреднения/подтяжки при замыкании контура (исходная length не трогается)."""
    _run("UPDATE walls SET length_adj=? WHERE id=?", (round(length_adj, 2), wall_id))


def list_walls(room_id: int):
    return _run("SELECT * FROM walls WHERE room_id=? ORDER BY id", (room_id,), many=True)


def add_opening(room_id: int, name: str, w: float, h: float, wall_id: int | None = None,
                offset: float = 0.0, open_: bool = False, sill_h: float | None = None) -> int:
    """Проём (дверь, окно, арка…). open_=True — открытый проход: плинтус в нём не считается."""
    return _run("INSERT INTO openings (wall_id, room_id, name, w, h, offset, open, sill_h) "
                "VALUES (?,?,?,?,?,?,?,?)",
                (wall_id, room_id, name[:30], round(w, 2), round(h, 2), round(offset, 2),
                 int(open_), sill_h))


def delete_opening(opening_id: int) -> None:
    _run("DELETE FROM openings WHERE id=?", (opening_id,))


def list_openings(room_id: int):
    return _run("SELECT * FROM openings WHERE room_id=? ORDER BY id", (room_id,), many=True)


def add_duct_box(room_id: int, point_id: int, orient: int, side_a: float, side_b: float,
                 depth: float) -> int:
    """Г-образный короб в углу комнаты (orient 1..4 — ┌ ┐ └ ┘)."""
    return _run("INSERT INTO duct_boxes (room_id, point_id, orient, side_a, side_b, depth) "
                "VALUES (?,?,?,?,?,?)",
                (room_id, point_id, orient, round(side_a, 2), round(side_b, 2), round(depth, 2)))


def list_duct_boxes(room_id: int):
    return _run("SELECT * FROM duct_boxes WHERE room_id=? ORDER BY id", (room_id,), many=True)


def room_graph(room_id: int) -> dict:
    """Вся геометрия комнаты одним словарём: комната, точки, стены, проёмы, короба."""
    return {
        "room": get_room(room_id),
        "points": list_points(room_id),
        "walls": list_walls(room_id),
        "openings": list_openings(room_id),
        "duct_boxes": list_duct_boxes(room_id),
    }
