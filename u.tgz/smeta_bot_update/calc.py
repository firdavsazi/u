"""Расчёт сметы: геометрия помещения, строки работ, итог, текст для чата.

Здесь нет ни Телеграма, ни базы — только чистые функции. Это позволяет
проверять расчёт отдельно от бота.
"""
import copy
from html import escape as _escape

import catalog

# Стандартный дверной проём в ванной и туалете, м (ширина, высота)
DOOR_STD_W, DOOR_STD_H = 0.7, 2.0
# В остальных комнатах дверь шире; окно по умолчанию. Размеры можно менять на экране замера
DOOR_ROOM_W, DOOR_ROOM_H = 0.9, 2.0
WINDOW_STD_W, WINDOW_STD_H = 1.3, 1.4

# Разделы итога в порядке вывода
SECTIONS = {
    "prep": "Демонтаж и подготовка",
    "eng": "Инженерные работы",
    "elec": "Электрика",
    "floor": "Пол",
    "walls": "Стены",
    "ceil": "Потолки",
    "tile": "Плитка",
    "doors": "Двери и окна",
    "drill": "Сверление",
    "mount": "Монтаж сантехники и мебели",
    "finish": "Отделка",
    "custom": "Добавленные работы",   # то, что человек добавил на итоговой странице
    "calc": "Работы",                 # расчёт из Excel или текста (калькулятор)
    "extra": "Допработы",             # строки допработы (объект → «Допработа»)
}

ROOM_TITLES = {
    "bath_full": "Ванная (совмещённый санузел)",
    "bath_only": "Ванная",
    "wc": "Туалет",
}

STAGE_TITLES = {"rough": "черновой этап", "finish": "чистовой этап", "all": "все работы"}

# Ключи прайса, относящиеся к укладке плитки (по ним смета считается «плиточной»)
TILE_LAYING_KEYS = {"tile_single", "tile_60", "tile_large", "tile_kab"}

# Виды ревизионных люков -> ключ цены в прайсе (свой вариант «custom» считается по цене из ответа)
HATCH_KEYS = {"magnet": "hatch", "hidden": "hatch_hidden"}

# Плинтус: вид -> из чего состоит (ключи прайса), по периметру целиком (ceil) или без дверного проёма (floor)
PLINTH_KINDS = {
    "ceil": (("plinth_ceiling",), "perim"),
    "ceil_paint": (("plinth_paint_install", "plinth_paint"), "perim"),
    "floor": (("plinth_mdf",), "plinth"),
    "floor_paint": (("plinth_paint_install", "plinth_paint"), "plinth"),
    "plastic": (("plinth_plastic",), "plinth"),
    "tile": (("plinth_tile",), "plinth"),
    "mdf": (("plinth_mdf",), "plinth"),   # так назывался напольный плинтус в старых сметах
}

# Материал плинтуса (plinth_type) для потолочного и напольного (plinth_place): ключи прайса
PLINTH_MATERIALS = {
    "ready": {"ceil": ("plinth_ceiling",), "floor": ("plinth_mdf",)},
    "paint": {"ceil": ("plinth_paint_install", "plinth_paint"), "floor": ("plinth_paint_install", "plinth_paint")},
    "plastic": {"ceil": ("plinth_plastic",), "floor": ("plinth_plastic",)},
    "tile": {"ceil": ("plinth_tile",), "floor": ("plinth_tile",)},
}


def plinth_lines(a: dict) -> tuple:
    """Что считать по плинтусу: (ключи прайса, основа длины 'perim'|'plinth', подпись к названию).

    Потолочный идёт по периметру целиком, напольный без дверного проёма. Старые сметы (без plinth_place) считаются,
    как раньше."""
    t, place = a.get("plinth_type", "plastic"), a.get("plinth_place")
    if place in ("ceil", "floor") and t in PLINTH_MATERIALS:
        suffix = " (потолочный)" if place == "ceil" and t == "paint" else ""
        return PLINTH_MATERIALS[t][place], ("perim" if place == "ceil" else "plinth"), suffix
    keys, base = PLINTH_KINDS.get(t, PLINTH_KINDS["plastic"])
    return keys, base, " (потолочный)" if t == "ceil_paint" else ""


# --- Форматирование ----------------------------------------------------------
def fnum(x: float) -> str:
    """1.5 -> '1,5'; 3.0 -> '3'; 16.05 -> '16,05'."""
    s = f"{x:.2f}".rstrip("0").rstrip(".")
    return (s or "0").replace(".", ",")


def fmoney(x: float, currency: str, *, pdf: bool = False) -> str:
    """12345 -> '12 345 ₽'."""
    sym = catalog.CURRENCIES[currency]["pdf" if pdf else "symbol"]
    return f"{round(x):,}".replace(",", " ") + " " + sym


# --- Геометрия ---------------------------------------------------------------
def geometry(a: dict) -> dict:
    """Площадь пола, периметр, площадь стен и длина плинтуса по ответам."""
    length, width, height = a["len"], a["wid"], a["hei"]
    floor = round(length * width, 2)
    perim = round(2 * (length + width), 2)
    door_w = door_h = 0.0
    if a.get("door") == "std":
        door_w, door_h = DOOR_STD_W, DOOR_STD_H
    elif a.get("door") == "own":
        door_w, door_h = a.get("door_w", 0), a.get("door_h", 0)
    door_area = round(door_w * door_h, 2)
    walls_gross = round(perim * height, 2)
    walls = max(round(walls_gross - door_area, 2), 0)
    plinth = max(round(perim - door_w, 2), 0)  # в проёме плинтуса нет
    return {
        "len": length, "wid": width, "hei": height,
        "floor": floor, "perim": perim, "walls_gross": walls_gross,
        "door_w": door_w, "door_h": door_h, "door_area": door_area,
        "walls": walls, "plinth": plinth,
    }


MAIN_PART_NAME = "Основная часть"


def mz_parts(mz: dict) -> list:
    """Части комнаты: первая — основная (длина, ширина, высота из замера), дальше добавленные кнопкой
    «Добавить часть комнаты». У добавленной части есть joint — длина общей границы (стыка) с основной частью:
    по ней комната открыта, стен на стыке нет. joint=None — берём меньшую сторону части (так стыкуются
    коридор «Г», ниша, эркер)."""
    parts = [{"name": mz.get("name0") or MAIN_PART_NAME, "len": mz.get("len"), "wid": mz.get("wid"),
              "hei": mz.get("hei"), "joint": 0.0}]
    for i, p in enumerate(mz.get("parts") or [], 2):
        parts.append({"name": p.get("name") or f"Часть {i}", "len": p.get("len"), "wid": p.get("wid"),
                      "hei": p.get("hei"), "joint": p.get("joint")})
    return parts


def mz_complete(mz: dict | None) -> bool:
    """Все размеры всех частей заданы (иначе считать геометрию рано)."""
    return bool(mz) and all(p[k] for p in mz_parts(mz) for k in ("len", "wid", "hei"))


def part_joint(p: dict) -> float:
    """Стык части с основной: заданный вручную или меньшая сторона; больше длинной стороны части быть не может."""
    longest = max(p["len"], p["wid"])
    j = min(p["len"], p["wid"]) if p.get("joint") is None else p["joint"]
    return round(min(max(j, 0.0), longest), 2)


def room_geometry(mz: dict, part: int | None = None) -> dict:
    """Геометрия комнаты из экрана замера (конструктор).

    mz: {'len', 'wid', 'hei', 'door': bool, 'door_w', 'door_h', 'win': bool, 'win_w', 'win_h',
         'extra': [{'name', 'w', 'h', 'part'}], 'parts': [{'name', 'len', 'wid', 'hei', 'joint'}]}.
    Площадь всех вычетов вычитается из стен. part=None — вся комната (пол и стены частей складываются, на стыках
    стен нет), part=0 — основная часть, 1 и дальше — добавленные (в смете у них свои работы).
    Дверь и окно относятся к основной части, свои вычеты — к той части, для которой их добавили."""
    parts = mz_parts(mz)
    joints = [0.0] + [part_joint(p) for p in parts[1:]]
    shared = sum(joints)                       # всё, что стыкуется с основной частью
    perims = [round(2 * (p["len"] + p["wid"]), 2) for p in parts]
    walls_len = [max(perims[0] - shared, 0.0)] + [max(perims[i] - joints[i], 0.0) for i in range(1, len(parts))]
    door_w = door_h = 0.0
    if mz.get("door"):
        door_w, door_h = mz["door_w"], mz["door_h"]
    deductions = []   # [(название, ширина, высота, часть)]
    if mz.get("door"):
        deductions.append(("дверь", door_w, door_h, 0))
    if mz.get("win"):
        deductions.append(("окно", mz["win_w"], mz["win_h"], 0))
    deductions += [(e["name"], e["w"], e["h"], e.get("part", 0)) for e in mz.get("extra", [])]

    def build(idx):
        sel = range(len(parts)) if idx is None else [idx]
        floor = round(sum(parts[i]["len"] * parts[i]["wid"] for i in sel), 2)
        perim = round(sum(perims[i] for i in sel) - (2 * shared if idx is None else (shared if idx == 0 else joints[idx])), 2)
        if len(parts) == 1:
            walls_gross = round(perims[0] * parts[0]["hei"], 2)   # одна комната — как раньше
        else:
            walls_gross = round(sum(walls_len[i] * parts[i]["hei"] for i in sel), 2)
        ded = [d for d in deductions if idx is None or d[3] == idx]
        ded_area = round(sum(w * h for _, w, h, _ in ded), 2)
        return floor, perim, walls_gross, ded, ded_area

    floor, perim, walls_gross, ded, ded_area = build(part)
    base = parts[0] if part in (None, 0) else parts[part]
    g = {
        "len": base["len"], "wid": base["wid"], "hei": base["hei"],
        "floor": floor, "ceil": floor, "perim": perim, "walls_gross": walls_gross,
        "door_w": door_w if part in (None, 0) else 0.0, "door_h": door_h, "door_area": ded_area, "ded_title": "вычеты",
        "walls": max(round(walls_gross - ded_area, 2), 0),
        "deductions": [(n, w, h) for n, w, h, _ in ded],
    }
    # открытый проход (арка, проём без двери): плинтуса в нём нет, как и в дверном проёме
    open_w = round(sum(e["w"] for e in mz.get("extra", [])
                       if e.get("open") and (part is None or e.get("part", 0) == part)), 2)
    g["open_w"] = open_w
    g["plinth"] = max(round(perim - g["door_w"] - open_w, 2), 0)
    if len(parts) > 1:
        g["parts"] = [{"name": p["name"], "len": p["len"], "wid": p["wid"], "hei": p["hei"],
                       "joint": (joints[i] if i else None)} for i, p in enumerate(parts)]
        if part is not None:
            g["part_name"] = parts[part]["name"]
    return g


def open_geometry(og: dict) -> dict | None:
    """Геометрия «Объекта без стен» (кусок 3) по ответам og: walls 'y'/'n' (есть ли несущие стены), contour — длины
    стен контура по порядку от входа, parts — длины перегородок, area — площадь пола, hei — высота, beams / cols —
    число балок и колонн, openings — проёмы [{'name', 'w', 'h'}].

    Стены (м²) = (контур + перегородки с двух сторон) × высота минус проёмы. Без несущих стен стен нет вообще:
    считается площадь пола, потолок и то, что на нём (балки, колонны). None — данных для расчёта ещё мало."""
    if not og or not og.get("area") or not og.get("hei"):
        return None
    walls_on = og.get("walls") == "y"
    contour = round(sum(og.get("contour") or []), 2) if walls_on else 0.0
    parts = round(sum(og.get("parts") or []), 2) if walls_on else 0.0
    area, hei = round(og["area"], 2), og["hei"]
    run = round(contour + 2 * parts, 2)                 # длина всех стен: контур и перегородки с двух сторон
    openings = og.get("openings") or []
    ded = [(o["name"], o["w"], o["h"]) for o in openings]
    ded_area = round(sum(w * h for _, w, h in ded), 2)
    walls_gross = round(run * hei, 2)
    return {"open": True, "walls_on": walls_on, "floor": area, "ceil": area, "hei": hei,
            "contour": contour, "partitions": parts, "perim": run, "walls_gross": walls_gross,
            "door_w": 0.0, "door_area": ded_area, "ded_title": "проёмы",
            "walls": max(round(walls_gross - ded_area, 2), 0),
            "plinth": max(round(run - sum(w for _, w, _ in ded), 2), 0),
            "beams": int(og.get("beams") or 0), "cols": int(og.get("cols") or 0), "deductions": ded}


def basis_qty(basis: str | None, g: dict) -> float:
    """Количество работы по замеру: пол, стены, потолок, периметр… Без правила — 1 (поправьте в итоге)."""
    if basis == "fw":
        return round(g["floor"] + g["walls"], 2)
    return g.get({"floor": "floor", "walls": "walls", "ceil": "ceil", "perim": "perim",
                  "plinth": "plinth"}.get(basis, ""), 1)


def finish_areas(a: dict, g: dict) -> dict:
    """Площади шпаклёвки и покраски стен ванной и «чужая» площадь, которую плитка не занимает.

    Спрашиваем «сколько стен» и (для шпаклёвки) «вся стена или только верх». Если ответов нет (старые сметы),
    красим и шпаклюем все стены, а из плитки ничего не вычитаем — как считалось раньше."""
    yes = lambda k: a.get(k) == "y"
    full = g["walls"]
    putty = paint = full
    if yes("putty") and "putty_walls" in a:
        share = a["putty_walls"] / 4
        if a.get("putty_scope") == "top":
            putty = round(max(g["hei"] - a.get("putty_h", 0), 0) * g["perim"] * share, 2)
        else:
            putty = round(full * share, 2)
    if yes("paint") and "paint_walls" in a:
        paint = round(full * a["paint_walls"] / 4, 2)
    # плитка не ложится на то, что шпаклюют и красят (шпаклёвка и покраска идут по одним стенам — берём большую)
    other = 0.0
    if yes("putty") and "putty_walls" in a:
        other = putty
    if yes("paint") and "paint_walls" in a:
        other = max(other, paint)
    return {"putty": putty, "paint": paint, "untiled": min(round(other, 2), full)}


def tile_area(a: dict, g: dict) -> float:
    """Площадь плитки по выбранной зоне. Если плитки нет — пол+стены (для грунта/затирки).

    Стены под плитку — это остаток после шпаклёвки и покраски: «стены» = остаток, «пол и стены» = остаток + пол."""
    left = round(g["walls"] - finish_areas(a, g)["untiled"], 2)
    if a.get("tile") == "y":
        zone = a.get("tile_zone")
        if zone == "floor":
            return g["floor"]
        if zone == "walls":
            return left
        if zone == "own":
            return round(a.get("tile_area", 0), 2)
        return round(g["floor"] + left, 2)
    return round(g["floor"] + g["walls"], 2)


# --- Расчёт одной комнаты ----------------------------------------------------
def compute_room(a: dict, kind: str, prices: dict) -> dict:
    """Возвращает {'name', 'geom', 'lines': [...], 'total'} для одной комнаты.

    Строка: {'section', 'key', 'title', 'qty', 'unit', 'price', 'sum'}.
    """
    g = geometry(a)
    lines: list[dict] = []
    missing: list[dict] = []   # работы, на которые не указана цена (в расчёт не входят)
    yes = lambda k: a.get(k) == "y"

    def add(key: str, qty: float, section: str, title: str | None = None,
            price: float | None = None, unit: str | None = None):
        """price/unit задают только для работ вне прайса (свой люк): у остальных они берутся из прайса."""
        qty = round(qty, 2)
        if qty <= 0:
            return
        item = catalog.ITEM_BY_KEY.get(key, {"title": title or key, "unit": unit or "шт"})
        price = prices.get(key, 0) if price is None else price
        name = title or item["title"]
        if price <= 0:  # цены нет — работу в расчёт не берём, но предупредим
            missing.append({"key": key, "title": name, "qty": qty, "unit": item["unit"]})
            return
        lines.append({
            "section": section, "key": key, "title": name,
            "qty": qty, "unit": item["unit"], "price": price, "sum": round(qty * price),
        })

    areas = finish_areas(a, g)

    # Подготовка
    if yes("demolition"):
        add("demolition", g["floor"] + g["walls"], "prep")
    if yes("wall_clean"):
        add("wall_clean", g["walls"], "prep")
    if yes("primer_plaster"):
        add("primer_plaster", g["walls"], "prep")
    if yes("plaster"):
        add("plaster", g["walls"], "prep")
        if yes("plaster_net"):  # армирование сеткой (стеклохолст под штукатурку не клеят)
            add("plaster_net", g["walls"], "prep")

    # Инженерные работы. Порядок монтажа воды: разводка → фильтры → счётчики → точки
    if yes("plumbing"):
        add("plumbing", 1, "eng")
        if yes("filter_cold"):
            add("filter_cold", 1, "eng")
        if yes("filter_hot"):
            add("filter_hot", 1, "eng")
        if a.get("meter") == "replace":
            add("meter_replace", a.get("meter_n", 0), "eng")
        elif a.get("meter") == "reinstall":
            add("meter_reinstall", a.get("meter_n", 0), "eng")
        add("water_point", len(a.get("points", [])) + a.get("pt_extra", 0), "eng")
    if yes("electric"):
        add("electric", 1, "eng")
    if yes("waterproof"):
        add("waterproof", 1, "eng")

    # Пол
    if yes("screed"):
        add("screed", g["floor"], "floor")
    if yes("primer_floor"):
        add("primer_floor", g["floor"], "floor")
    if yes("self_level"):
        add("self_level", g["floor"], "floor")

    # Плитка
    t_area = tile_area(a, g)
    if yes("primer_tile"):
        add("primer_tile", t_area, "tile")
    if yes("tile"):
        if a.get("tile_mode") == "types":
            add("tile_60", a.get("tile_a60", 0), "tile")
            add("tile_large", a.get("tile_alarge", 0), "tile")
            add("tile_kab", a.get("tile_akab", 0), "tile")
        else:
            add("tile_single", t_area, "tile", "Укладка плитки")
        add("tile_cut", a.get("tile_cut", 0), "tile")
        # Углы плитки: у короба, инсталляции, ниши и откосов (если они оформлены плиткой)
        sources = (("box", "короб", yes("box")), ("inst", "инсталляция", a.get("toilet_type") == "install"
                                                     and yes("toilet")),
                   ("niche", "ниша", yes("niche")), ("slopes", "откосы", yes("slopes")))
        for src, label, present in sources:
            kind_key = {"miter": ("miter", "tile"), "tile": ("corner_tile", "tile"),
                        "deco": ("corner_deco", "finish")}.get(a.get(f"cor_{src}"))
            if present and kind_key:
                key, section = kind_key
                add(key, a.get(f"cor_{src}_len", 0), section,
                    f"{catalog.ITEM_BY_KEY[key]['title']} ({label})")
    if yes("grout"):
        add("grout_epoxy" if a.get("grout_type") == "epoxy" else "grout", t_area, "tile")

    # Сверление
    if a.get("drill") == "one":
        add("drill_normal", a.get("drill_n", 0), "drill", "Сверление")
    elif a.get("drill") == "diam":
        add("drill_normal", a.get("dr_normal", 0), "drill")
        add("drill_socket", a.get("dr_socket", 0), "drill")
        add("drill_big", a.get("dr_big", 0), "drill")
        add("drill_small", a.get("dr_small", 0), "drill")

    # Монтаж сантехники и мебели
    if yes("box"):
        add("box", a.get("box_len", 0), "mount")
    if yes("tub"):
        add("tub", 1, "mount")
        if a.get("tub_screen") == "tile":
            add("screen_tile", 1, "mount")
        elif a.get("tub_screen") == "plastic":
            add("screen_plastic", 1, "mount")
    if yes("sink"):
        add("sink", 1, "mount")
        for furn in a.get("furn", []):
            add("furn_" + furn, 1, "mount")
    if yes("toilet"):
        add("toilet", 1, "mount")
        if a.get("toilet_type") == "install":
            add("install_frame", 1, "mount")
    # Ревизионные люки: вид + количество; одинаковые виды складываем в одну строку
    hatches: dict[str, float] = {}
    for src in ("box", "screen", "inst"):
        kind_ = a.get(f"hk_{src}")
        present = {"box": yes("box"),
                   "screen": yes("tub") and a.get("tub_screen") in ("tile", "plastic"),
                   "inst": yes("toilet") and a.get("toilet_type") == "install"}[src]
        if present and kind_ in HATCH_KEYS and a.get(f"hn_{src}", 0) > 0:
            hatches[HATCH_KEYS[kind_]] = hatches.get(HATCH_KEYS[kind_], 0) + a[f"hn_{src}"]
        elif present and kind_ == "custom" and a.get(f"hn_{src}", 0) > 0:  # свой вариант: вид и цена из ответов
            name = a.get(f"hname_{src}") or "свой вариант"
            add(f"hatch_custom_{src}", a[f"hn_{src}"], "mount", f"Ревизионный люк: {name}",
                price=a.get(f"hprice_{src}", 0), unit="шт")
    for key, qty in hatches.items():
        add(key, qty, "mount")

    # Отделка. Стеклохолст клеим только под шпаклёвку и покраску; считаем по площади тех стен, где они есть
    if yes("putty"):
        if yes("putty_glass"):
            add("glass_cloth", areas["putty"], "finish", "Стеклохолст (под шпаклёвку)")
        add("putty", areas["putty"], "finish")
    if yes("paint"):
        if yes("paint_glass"):
            add("glass_cloth", areas["paint"], "finish", "Стеклохолст (под покраску)")
        add("paint", areas["paint"], "finish")
    if yes("plinth"):
        keys, base, where = plinth_lines(a)
        for key in keys:
            add(key, g[base], "finish", catalog.ITEM_BY_KEY[key]["title"] + where)

    return {
        "name": ROOM_TITLES[kind], "kind": kind, "geom": g, "lines": lines, "missing": missing,
        "total": sum(l["sum"] for l in lines),
    }


# --- Расчёт всей сметы -------------------------------------------------------
def build_estimate(rooms: list[dict], stage: str, prices: dict, min_total: float,
                   manual: list[dict] | None = None, apply_min: bool = True) -> dict:
    """rooms: [{'kind': ..., 'a': {...ответы...}}, ...]. Применяет минимальный порог.

    manual — работы, которые человек добавил вручную на итоговой странице:
    [{'title', 'unit', 'qty', 'price'}]. Они встают в первую комнату.
    apply_min=False — без минимального выезда (для допработ)."""
    out = [compute_room(r["a"], r["kind"], prices) for r in rooms]
    for i, m in enumerate(manual or []):
        qty, price = round(m["qty"], 2), m["price"]
        if price <= 0:
            out[0]["missing"].append({"key": f"custom_{i}", "title": m["title"], "qty": qty, "unit": m["unit"]})
            continue
        out[0]["lines"].append({"section": "custom", "key": f"custom_{i}", "title": m["title"],
                                "qty": qty, "unit": m["unit"], "price": price, "sum": round(qty * price)})
        out[0]["total"] += round(qty * price)
    return _finish_result(out, stage, min_total if apply_min else 0)


def apply_adjust(result: dict, adj: dict | None, min_total: float, apply_min: bool = True) -> dict:
    """Наценка и скидка поверх готового расчёта (кусок 3).

    adj = {'markup': %, 'discount': %, 'discount_on': bool}. Наценка вшивается в цену каждой строки (клиент её не видит:
    в смете просто такая цена), скидка идёт отдельной строкой, её можно отключить. Минимальная сумма проверяется
    в самом конце, уже после скидки. Без наценки и скидки возвращается тот же результат, ничего не меняется."""
    adj = adj or {}
    mk = max(float(adj.get("markup") or 0), 0.0)
    ds = max(float(adj.get("discount") or 0), 0.0) if adj.get("discount_on", True) else 0.0
    if mk <= 0 and ds <= 0:
        return result
    out = copy.deepcopy(result)
    if mk > 0:
        f = 1 + mk / 100
        for room in out["rooms"]:
            for l in room["lines"]:
                l["price"] = round(l["price"] * f, 2)
                l["sum"] = round(l["qty"] * l["price"])
            room["total"] = sum(l["sum"] for l in room["lines"])
        out["tile_sum"] = sum(l["sum"] for r in out["rooms"] for l in r["lines"] if l["section"] == "tile")
        out["markup_pct"] = mk
    subtotal = sum(r["total"] for r in out["rooms"])
    discount = round(subtotal * ds / 100) if ds > 0 else 0
    after = subtotal - discount
    limit = min_total if apply_min else 0
    out["subtotal"] = subtotal
    out["discount"] = discount
    out["discount_pct"] = ds if discount else 0
    out["calc_total"] = after
    out["raised"] = 0 < after < limit
    out["total"] = limit if out["raised"] else after
    return out


def _finish_result(out: list[dict], stage: str, min_total: float) -> dict:
    calc_total = sum(r["total"] for r in out)
    raised = 0 < calc_total < min_total
    total = min_total if raised else calc_total
    has_tile = any(l["key"] in TILE_LAYING_KEYS for r in out for l in r["lines"])
    tile_sum = sum(l["sum"] for r in out for l in r["lines"] if l["section"] == "tile")
    missing = [m for r in out for m in r.get("missing", [])]
    return {
        "stage": stage, "rooms": out, "calc_total": calc_total, "min_total": min_total,
        "raised": raised, "total": total, "has_tile": has_tile, "tile_sum": tile_sum,
        "missing": missing,
    }


# Раздел прайса -> раздел сметы (для комнаты из конструктора). Свои работы идут в «Добавленные работы»
GROUP_SECTION = {"Подготовка": "prep", "Инженерка": "eng", "Пол": "floor", "Плитка": "tile",
                 "Сверление": "drill", "Монтаж": "mount", "Отделка": "finish", "Стены": "walls",
                 "Потолки": "ceil", "Двери и окна": "doors", "Электрика": "elec"}


def part_suffix(l: dict, geom: dict | None) -> str:
    """У работы, выбранной для одной части комнаты, в названии стоит эта часть: «Укладка ламината (Коридор)»."""
    p = l.get("part")
    if p is None or not geom or not geom.get("parts") or not 0 <= p < len(geom["parts"]):
        return ""
    return f" ({geom['parts'][p]['name']})"


def build_custom_room(name: str, icon: str, lines: list[dict], min_total: float, apply_min: bool = True,
                      geom: dict | None = None) -> dict:
    """Комната из конструктора: lines = [{'title', 'unit', 'qty', 'price', 'key', 'part'}], key — ключ прайса или None,
    part — номер части комнаты (None — вся комната).

    Работы из прайса встают в свои разделы (плитка остаётся «плиточной»), свои — в «Добавленные работы».
    Работы без цены в расчёт не входят, бот предупреждает об этом (у такой строки есть idx — номер в списке работ,
    по нему можно указать цену). geom — замер комнаты: он печатается в шапке сметы."""
    out_lines, missing = [], []
    for i, l in enumerate(lines):
        qty = round(l["qty"], 2)
        key = l.get("key") or f"x_{i}"
        item = catalog.ITEM_BY_KEY.get(key)
        title = l["title"] + part_suffix(l, geom)
        if l["price"] <= 0:
            missing.append({"key": key, "title": title, "qty": qty, "unit": l["unit"], "idx": i})
            continue
        out_lines.append({"section": GROUP_SECTION.get(item["group"], "custom") if item else l.get("section", "custom"),
                          "key": key, "title": title, "qty": qty, "unit": l["unit"],
                          "price": l["price"], "sum": round(qty * l["price"]), "idx": i})
    room = {"name": name, "kind": "custom", "icon": icon, "geom": geom, "lines": out_lines, "missing": missing,
            "total": sum(l["sum"] for l in out_lines)}
    return _finish_result([room], "custom", min_total if apply_min else 0)


def build_extra(name: str, lines: list[dict]) -> dict:
    """Результат допработы по строкам: lines = [{'title', 'unit', 'qty', 'price'}]. Без минимального выезда."""
    out_lines = [{"section": "extra", "key": f"x_{i}", "title": l["title"], "qty": round(l["qty"], 2),
                  "unit": l["unit"], "price": l["price"], "sum": round(round(l["qty"], 2) * l["price"])}
                 for i, l in enumerate(lines)]
    room = {"name": name, "kind": "extra", "geom": None, "lines": out_lines, "missing": [],
            "total": sum(l["sum"] for l in out_lines)}
    return _finish_result([room], "extra", 0)


# --- Текст сметы -------------------------------------------------------------
def geom_lines(g: dict, html: bool = True) -> list[str]:
    """Строки про размеры комнаты для сметы: одна комната — «4,5 × 3,2 × 2,7 м», с частями — по строке на часть."""
    t = _escape if html else str
    out = []
    if g.get("open"):   # объект без стен: пол, контур, перегородки, стены, балки и колонны
        out.append(f"Пол {fnum(g['floor'])} м² · высота {fnum(g['hei'])} м")
        if g["walls_on"]:
            ded = f", проёмы −{fnum(g['door_area'])} м²" if g["door_area"] else ""
            out.append(f"Контур {fnum(g['contour'])} м · перегородки {fnum(g['partitions'])} м · стены {fnum(g['walls'])} м²{ded}")
        else:
            out.append("Несущих стен нет")
        if g["beams"] or g["cols"]:
            out.append(f"Балок {g['beams']} · колонн {g['cols']}")
        return out
    if g.get("parts"):
        for p in g["parts"]:
            joint = f" (стык {fnum(p['joint'])} м)" if p.get("joint") else ""
            out.append(f"{t(p['name'])}: {fnum(p['len'])} × {fnum(p['wid'])} × {fnum(p['hei'])} м{joint}")
    else:
        out.append(f"{fnum(g['len'])} × {fnum(g['wid'])} × {fnum(g['hei'])} м")
    door = f", {g.get('ded_title', 'проём')} −{fnum(g['door_area'])} м²" if g["door_area"] else ""
    out.append(f"Пол {fnum(g['floor'])} м² · периметр {fnum(g['perim'])} м · стены {fnum(g['walls'])} м²{door}")
    return out


def min_label(result: dict) -> str:
    """Подпись к минимальной сумме: «минимальный выезд» или, если минимум считался по дням, «минимум за 2 дн.»."""
    days = result.get("min_days")
    return f"минимум за {fnum(days)} дн." if days else "минимальный выезд"


def missing_count(missing: list[dict]) -> int:
    """Сколько разных работ без цены (одинаковые строки считаем один раз)."""
    return len({m["title"] for m in missing})


def missing_warning(missing: list[dict]) -> str:
    """Строка над итогом: «Внимание: у 2 работ нет цены, итог неполный»."""
    n = missing_count(missing)
    return f"⚠️ Внимание: у {n} {'работы' if n % 10 == 1 and n % 100 != 11 else 'работ'} нет цены, итог неполный"


def combine_results(main: dict, extras: list[dict]) -> dict:
    """Основная смета и её допработы одним результатом (для PDF): допработы идут отдельными блоками, итог общий."""
    if not extras:
        return main
    out = dict(main)
    out["rooms"] = list(main["rooms"]) + [r for e in extras for r in e["rooms"]]
    out["total"] = main["total"] + sum(e["total"] for e in extras)
    out["missing"] = list(main.get("missing", [])) + [m for e in extras for m in e.get("missing", [])]
    out["extras_total"] = sum(e["total"] for e in extras)
    return out


def format_text(result: dict, currency: str, *, prices: bool = True, html: bool = True,
                pdf: bool = False) -> str:
    """Текст сметы с разбивкой по разделам. prices=False — без цен и сумм."""
    b = (lambda s: f"<b>{s}</b>") if html else (lambda s: s)
    t = _escape if html else str  # названия работ вводит человек: «<» и «&» не должны ломать разметку Телеграма
    money = lambda x: fmoney(x, currency, pdf=pdf)
    out: list[str] = []
    for room in result["rooms"]:
        g = room["geom"]
        icon = room.get("icon") or {"wc": "🚽", "extra": "🧰"}.get(room["kind"], "🛁")
        out.append(b(f"{icon} {t(room['name'])}"))
        if g:  # у допработы по строкам помещения нет
            out += geom_lines(g, html)
        if not room["lines"]:
            out.append("Работы не выбраны." if not room.get("missing") else "Нет работ с указанной ценой.")
        for sec_key, sec_title in SECTIONS.items():
            sec_lines = [l for l in room["lines"] if l["section"] == sec_key]
            if not sec_lines:
                continue
            out.append("")
            out.append(b(sec_title))
            for l in sec_lines:
                qty = f"{fnum(l['qty'])} {l['unit']}"
                if prices:
                    out.append(f"• {t(l['title'])}: {t(qty)} × {fnum(l['price'])} = {money(l['sum'])}")
                else:
                    out.append(f"• {t(l['title'])}: {t(qty)}")
            if prices:
                out.append(f"  Итого по разделу: {money(sum(l['sum'] for l in sec_lines))}")
        if prices and len(result["rooms"]) > 1:
            out.append("")
            out.append(b(f"Итого {t(room['name'].lower())}: {money(room['total'])}"))
        out.append("")
    if prices:
        if result.get("discount"):   # скидка отдельной строкой
            out.append(f"Скидка {fnum(result['discount_pct'])}%: −{money(result['discount'])}")
        if result["raised"]:
            out.append(f"Расчёт {fnum(result['calc_total'])}, {min_label(result)} {fnum(result['min_total'])}")
        if result.get("missing"):   # итог неполный: предупреждаем прямо над суммой
            out.append(missing_warning(result["missing"]))
        out.append(b(f"💰 ИТОГО: {money(result['total'])}"))
    if prices and result.get("missing"):
        out.append("")
        out.append(missing_text(result["missing"], html))
    return "\n".join(out).strip()


def missing_text(missing: list[dict], html: bool = True) -> str:
    """Предупреждение «Не указана цена: …» (повторы объединяем)."""
    merged: dict[str, dict] = {}
    for m in missing:
        if m["title"] in merged:
            merged[m["title"]]["qty"] += m["qty"]
        else:
            merged[m["title"]] = dict(m)
    t = _escape if html else str
    items = ", ".join(f"{t(m['title'])} ({fnum(m['qty'])} {t(m['unit'])})" for m in merged.values())
    return f"⚠️ На эти работы цена не указана, укажите свою: {items}. В итог они пока не вошли."


# --- Геометрия объекта: граф стен (этап 1.5) ------------------------------------
# Расчёты по контуру комнаты из таблиц rooms/points/walls/openings (см. db.room_graph).
# Правила замыкания — п.12.5 дополнения №2: <10 см подтянуть молча, 10–50 см усреднить,
# >50 см — указать подозреваемую стену. Пороги кандидаты, проверяются на живом замере.

CLOSE_PULL = 0.10     # до этого расхождения (м) контур подтягивается молча
CLOSE_AVG = 0.50      # до этого — усреднение по стенам; больше — просим перемерить


def polygon_area(points: list) -> float | None:
    """Площадь многоугольника по точкам контура (формула шнурования). Меньше трёх точек — None."""
    pts = [(p["x"], p["y"]) for p in points if p["x"] is not None and p["y"] is not None]
    if len(pts) < 3 or len(pts) != len(points):
        return None
    s = sum(pts[i][0] * pts[(i + 1) % len(pts)][1] - pts[(i + 1) % len(pts)][0] * pts[i][1]
            for i in range(len(pts)))
    return round(abs(s) / 2, 2)


def contour_gap(points: list) -> float | None:
    """Расстояние от конца последней стены до точки старта (расхождение контура), м.
    None — координат мало (режим «длины» без «стрелок»: замыкание не проверяется)."""
    pts = [(p["x"], p["y"]) for p in points if p["x"] is not None and p["y"] is not None]
    if len(pts) < 3 or len(pts) != len(points):
        return None
    dx, dy = pts[-1][0] - pts[0][0], pts[-1][1] - pts[0][1]
    return round((dx * dx + dy * dy) ** 0.5, 3)


def closing_verdict(gap: float) -> str:
    """Что делать с расхождением контура: 'pull' — подтянуть молча, 'avg' — усреднить с сообщением,
    'ask' — расхождение большое, указать подозреваемую стену и попросить перемерить."""
    if gap < CLOSE_PULL:
        return "pull"
    return "avg" if gap <= CLOSE_AVG else "ask"


def suspect_wall(walls: list) -> dict | None:
    """Подозреваемая стена при большом расхождении: самая длинная (на ней ошибка вероятнее)."""
    return max(walls, key=lambda w: w["length"], default=None)


def even_out_gap(walls: list, gap: float) -> list:
    """Усреднение расхождения: gap распределяется по стенам пропорционально длинам.
    Возвращает список (wall_id, скорректированная длина). Исходные длины не меняются."""
    total = sum(w["length"] for w in walls) or 1.0
    out = []
    for w in walls:
        adj = round(w["length"] - gap * w["length"] / total, 2)
        out.append((w["id"], max(adj, 0.01)))
    return out


def graph_geometry(graph: dict) -> dict | None:
    """Геометрия комнаты из графа стен (результат db.room_graph).

    Возвращает тот же словарь величин, что и open_geometry: floor, perim, walls, plinth,
    deductions и пр. Стены (м²) = Σ длин стен × высота − проёмы; перегородки (kind='partition')
    считаются с двух сторон. Площадь пола — по многоугольнику точек; если координат нет
    (режим «длины») — None, площадь спросят отдельно. None — данных мало (нет стен или высоты)."""
    room, walls = graph.get("room"), graph.get("walls") or []
    if not room or not walls or not room["hei"]:
        return None
    hei = room["hei"]
    run_bearing = sum((w["length_adj"] or w["length"]) for w in walls if w["kind"] != "partition")
    run_partition = sum((w["length_adj"] or w["length"]) for w in walls if w["kind"] == "partition")
    run = round(run_bearing + 2 * run_partition, 2)          # перегородки с двух сторон
    openings = graph.get("openings") or []
    ded = [(o["name"], o["w"], o["h"]) for o in openings]
    ded_area = round(sum(w * h for _, w, h in ded), 2)
    walls_gross = round(run * hei, 2)
    floor = polygon_area(graph.get("points") or [])
    return {
        "graph": True, "room_id": room["id"], "hei": hei,
        "floor": floor, "ceil": floor, "perim": run,
        "walls_gross": walls_gross, "door_area": ded_area, "ded_title": "проёмы",
        "walls": max(round(walls_gross - ded_area, 2), 0),
        "plinth": max(round(run - sum(w for _, w, _ in ded), 2), 0),   # как в open_geometry
        "door_w": 0.0, "deductions": ded,
        "closing_gap": room["closing_gap"] or 0.0,
    }
